# gqlgqn-sandbox

## What's this repository ?

gqlgenを試すためのリポジトリ。


## コマンド

## アプリケーション起動

```zsh
$ go run cmd/main.go 
```


### schemaからresolverの生成

```zsh
$ gqlgen generate --config tools/gqlgen/gqlgen.yml
```

### エンティティの生成

※事前にdockerでmysqlを立ち上げておくこと

```zsh
$ sqlboiler mysql -c tools/sqlboiler/sqlboiler.toml 
```
