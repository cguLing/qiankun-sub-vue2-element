#!/bin/zsh

gqlgen generate --config tools/gqlgen/gqlgen.yml
