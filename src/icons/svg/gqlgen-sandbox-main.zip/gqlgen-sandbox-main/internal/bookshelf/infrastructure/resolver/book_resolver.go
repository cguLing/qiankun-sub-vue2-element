package resolver

// This file will be automatically regenerated based on the schema, any resolver implementations
// will be copied through when generating and any unknown code will be moved to the end.

import (
	"context"
	"fmt"
	"github.com/taka521/gqlgen-sandbox/internal/bookshelf/controller"
	"github.com/taka521/gqlgen-sandbox/internal/bookshelf/domain/model"
	"strconv"
)

func (r *mutationResolver) CreateBook(ctx context.Context, input model.CreateBookInput) (*model.Book, error) {
	panic(fmt.Errorf("not implemented"))
}

func (r *mutationResolver) UpdateBook(ctx context.Context, input model.UpdateBookInput) (*model.Book, error) {
	panic(fmt.Errorf("not implemented"))
}

func (r *mutationResolver) DeleteBook(ctx context.Context, input model.DeleteBookInput) (*model.Book, error) {
	panic(fmt.Errorf("not implemented"))
}

func (r *queryResolver) Book(ctx context.Context, id string) (*model.Book, error) {
	bookId, _ := strconv.ParseInt(id, 10,64)
	return controller.InitBookController().Book(ctx, bookId)
}

func (r *queryResolver) Books(ctx context.Context, first *int, after *string) (*model.BookConnection, error) {
	panic(fmt.Errorf("not implemented"))
}
