package repository

import (
	"context"
	"github.com/taka521/gqlgen-sandbox/internal/bookshelf/domain/model"
	"github.com/taka521/gqlgen-sandbox/internal/bookshelf/domain/repository"
	"strconv"
	"time"
)

func GetBookRepository() repository.BookRepository {
	return &bookRepository{}
}

type bookRepository struct{}

func (b bookRepository) FindByID(ctx context.Context, bookId int64) (*model.Book, error) {
	genre := "ジャンル"
	now := time.Now()

	book := &model.Book{
		ID:         strconv.FormatInt(bookId, 10),
		Title:      "タイトル",
		Author:     "著者",
		Publisher:  "出版社",
		PurchaseAt: &now,
		ReadAt:     nil,
		Genre:      &genre,
		Evaluation: 10,
		Memo:       nil,
		CreatedAt:  &now,
		UpdatedAt:  &now,
	}

	return book, nil
}

func (b bookRepository) FindByUserID(ctx context.Context, userId int64) (*[]model.Book, error) {
	panic("implement me")
}

func (b bookRepository) Create(ctx context.Context, book interface{}) (*model.Book, error) {
	panic("implement me")
}

func (b bookRepository) Update(ctx context.Context, book interface{}) (*model.Book, error) {
	panic("implement me")
}

func (b bookRepository) Delete(ctx context.Context, bookId int64) (*model.Book, error) {
	panic("implement me")
}
