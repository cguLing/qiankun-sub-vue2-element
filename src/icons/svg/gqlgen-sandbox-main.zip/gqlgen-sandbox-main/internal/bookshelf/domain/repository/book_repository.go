package repository

import (
	"context"
	"github.com/taka521/gqlgen-sandbox/internal/bookshelf/domain/model"
)

type BookRepository interface {
	FindByID(ctx context.Context, bookId int64) (*model.Book, error)
	FindByUserID(ctx context.Context, userId int64) (*[]model.Book, error)
	Create(ctx context.Context, book interface{}) (*model.Book, error)
	Update(ctx context.Context, book interface{}) (*model.Book, error)
	Delete(ctx context.Context, bookId int64) (*model.Book, error)
}
