package service

import (
	"context"
	"github.com/taka521/gqlgen-sandbox/internal/bookshelf/domain/model"
	"github.com/taka521/gqlgen-sandbox/internal/bookshelf/domain/repository"
)

type BookService interface {
	GetBook(ctx context.Context, bookId int64) (*model.Book, error)
	GetBooks(ctx context.Context, userId int64) (*[]model.Book, error)
	Create(ctx context.Context, book interface{}) (*model.Book, error)
	Update(ctx context.Context, book interface{}) (*model.Book, error)
	Delete(ctx context.Context, bookId int64) (*model.Book, error)
}

func GetBookService(
	bookRepository repository.BookRepository,
) BookService {
	return &bookService{bookRepository: bookRepository}
}

type bookService struct {
	bookRepository repository.BookRepository
}

func (b bookService) GetBook(ctx context.Context, bookId int64) (*model.Book, error) {
	return b.bookRepository.FindByID(ctx, bookId)
}

func (b bookService) GetBooks(ctx context.Context, userId int64) (*[]model.Book, error) {
	panic("implement me")
}

func (b bookService) Create(ctx context.Context, book interface{}) (*model.Book, error) {
	panic("implement me")
}

func (b bookService) Update(ctx context.Context, book interface{}) (*model.Book, error) {
	panic("implement me")
}

func (b bookService) Delete(ctx context.Context, bookId int64) (*model.Book, error) {
	panic("implement me")
}
