//+build wireinject

package controller

import (
	"github.com/google/wire"
	"github.com/taka521/gqlgen-sandbox/internal/bookshelf/domain/service"
	"github.com/taka521/gqlgen-sandbox/internal/bookshelf/infrastructure/repository"
)

func InitBookController() BookController {
	wire.Build(Controllers)
	return nil
}


var Controllers = wire.NewSet(
	GetBookController,
	services,
)

var services = wire.NewSet(
	service.GetBookService,
	repositories,
)

var repositories = wire.NewSet(
	repository.GetBookRepository,
)
