package controller

import (
	"context"
	"github.com/taka521/gqlgen-sandbox/internal/bookshelf/domain/model"
	"github.com/taka521/gqlgen-sandbox/internal/bookshelf/domain/service"
)

type BookController interface {
	Book(ctx context.Context, bookId int64) (*model.Book, error)
}

type bookController struct {
	bookService service.BookService
}

func GetBookController(bookService service.BookService) BookController {
	return &bookController{bookService: bookService}
}

func (b bookController) Book(ctx context.Context, bookId int64) (*model.Book, error) {
	return b.bookService.GetBook(ctx, bookId)
}
