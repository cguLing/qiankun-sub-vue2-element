package gqlgen

import (
	"time"

	"github.com/99designs/gqlgen/graphql"
	"github.com/pkg/errors"
	"github.com/volatiletech/null"
)

func UnmarshalNullableDateTime(v interface{}) (null.Time, error) {
	switch v := v.(type) {
	case nil:
		return null.TimeFromPtr(nil), nil
	case string:
		pl, err := time.ParseInLocation(time.RFC3339, v, time.Local)
		return null.TimeFrom(pl), err
	default:
		return null.TimeFromPtr(nil), errors.Errorf("%T is not a NullableDateTime", v)
	}
}

func MarshalNullableDateTime(v null.Time) graphql.Marshaler {
	if v.Valid {
		return graphql.MarshalTime(v.Time)
	}
	return graphql.Null
}

