package gqlgen

import (
	"time"

	"github.com/99designs/gqlgen/graphql"
	"github.com/pkg/errors"
	"github.com/volatiletech/null"
)

func UnmarshalNullableDate(v interface{}) (null.Time, error) {
	switch v := v.(type) {
	case nil:
		return null.TimeFromPtr(nil), nil
	case string:
		pl, err := time.ParseInLocation("2006-01-02", v, time.Local)
		return null.TimeFrom(pl), err
	default:
		return null.TimeFromPtr(nil), errors.Errorf("%T is not a NullableDate", v)
	}
}

func MarshalNullableDate(v null.Time) graphql.Marshaler {
	if v.Valid {
		return graphql.MarshalTime(v.Time)
	}
	return graphql.Null
}
