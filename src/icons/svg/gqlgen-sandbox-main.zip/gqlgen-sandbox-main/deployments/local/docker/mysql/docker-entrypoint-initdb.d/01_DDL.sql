CREATE TABLE IF NOT EXISTS user
(
    user_id       BIGINT AUTO_INCREMENT COMMENT 'ユーザーID'
        PRIMARY KEY,
    name          VARCHAR(255)                        NOT NULL COMMENT 'ユーザー名',
    email         TEXT                                NOT NULL COMMENT 'メールアドレス',
    password_hash VARCHAR(60)                         NOT NULL COMMENT 'パスワードハッシュ',
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL COMMENT '作成日時',
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL COMMENT '更新日時'
)
    COMMENT 'ユーザー';

CREATE TABLE IF NOT EXISTS book
(
    book_id     BIGINT UNSIGNED AUTO_INCREMENT COMMENT '書籍ID'
        PRIMARY KEY,
    user_id     BIGINT                                     NOT NULL COMMENT 'ユーザーID',
    title       VARCHAR(255)                               NOT NULL COMMENT 'タイトル',
    author      VARCHAR(255)                               NOT NULL COMMENT '著者',
    publisher   VARCHAR(255)                               NOT NULL COMMENT '著者',
    purchase_at DATE                                       NULL COMMENT '購入日',
    read_at     DATE                                       NULL COMMENT '読了日',
    genre       VARCHAR(255)                               NULL COMMENT 'ジャンル',
    evaluation  TINYINT UNSIGNED DEFAULT '0'               NOT NULL COMMENT '評価',
    memo        TEXT                                       NULL COMMENT 'メモ',
    created_at  TIMESTAMP        DEFAULT CURRENT_TIMESTAMP NOT NULL COMMENT '作成日',
    updated_at  TIMESTAMP        DEFAULT CURRENT_TIMESTAMP NOT NULL COMMENT '更新日',
    CONSTRAINT book_user_user_id_fk
        FOREIGN KEY (user_id) REFERENCES user (user_id)
)
    COMMENT '書籍';

