-- user
INSERT INTO bookshelf.user (user_id, name, email, password_hash, created_at, updated_at) VALUES (1, 'テスト1', 'test1@example.com', '$2a$08$rkzhSAEdubD5qjFLE/vR9up50d/xAhi3MosOggQXO1SAQP4Jg.eQ.', '2020-10-27 16:02:23', '2020-10-27 16:02:23');
INSERT INTO bookshelf.user (user_id, name, email, password_hash, created_at, updated_at) VALUES (2, 'テスト2', 'test2@example.com', '$2a$08$rkzhSAEdubD5qjFLE/vR9up50d/xAhi3MosOggQXO1SAQP4Jg.eQ.', '2020-10-27 16:02:55', '2020-10-27 16:02:55');

-- book
INSERT INTO bookshelf.book (book_id, user_id, title, author, publisher, purchase_at, read_at, genre, evaluation, memo, created_at, updated_at) VALUES (1, 1, 'イギリス海岸', '宮沢賢治', '筑摩書房', null, null, '純文学', 0, null, '2020-10-27 16:05:45', '2020-10-27 16:05:45');
INSERT INTO bookshelf.book (book_id, user_id, title, author, publisher, purchase_at, read_at, genre, evaluation, memo, created_at, updated_at) VALUES (2, 2, 'ほうき一本', '宮本 百合子', '新日本出版社', null, null, '純文学', 0, null, '2020-10-27 16:07:59', '2020-10-27 16:07:59');
INSERT INTO bookshelf.book (book_id, user_id, title, author, publisher, purchase_at, read_at, genre, evaluation, memo, created_at, updated_at) VALUES (3, 2, '報酬', '織田 作之助', '文泉堂出版', null, null, '文学', 0, null, '2020-10-27 16:09:15', '2020-10-27 16:09:15');

