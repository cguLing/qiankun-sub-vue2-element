# 启动开发服务

## 准备工作

```js
// 安装依赖包
npm install
```

```js
// 配置ldap信息
cp user.info.template.js user.info.js
```

**修改user.info.js里面的关于你的 LDAP 信息，用于认证内部resource manager服务**


## 开发（3种编译模式）

```js
// 1.本地开发：
npm run dev

// 2.编译无压缩开发到cms版本,并上线到cms：
npm run cms // 打包文件
gulp publish.cms // 上传到cms

// 3.编译无压缩开发版本（测试服使用）：
1. npm run build // 打包文件
2. (需连vpn)gulp publish.inner // 将文件上传到cdn
3. 查看提示的cdn html地址已存在（约5分钟后），即可push代码到dev分支

// 4.编译压缩线上版本（正式服使用）：
1. npm run build.release
2. (需连vpn)gulp publish.release
3. 必须查看提示的cdn html地址已存在（约5分钟后），即可push代码到dev分支
4. push成功后，满意的话，要打tag，方便回滚

// 关于回滚
从master找到对应的tag，checkout下来，重新push
```

# 执行测试用例


# 其他
* hosts文件中增加`127.0.0.1 home.youdao.com`

* 浏览器输入地址`http://home.youdao.com`可见所有编译资源；

* ~~node_modules自己更改了html-to-text模块所以提交到仓库中~~

* gulp3和node12并不兼容，建议使用低版本node

# 跨域
由于数据服务跨域，建议开启chrome的跨域设置：
```
// mac os 命令行执行
//方式一（貌似无效
open -a Google\ Chrome --args --disable-web-security --user-data-dir

//方式二
open -n /Applications/Google\ Chrome.app/ --args --disable-web-security --user-data-dir=/Users/你的电脑名字/MyChromeDevUserData/

//windows
关闭所有的chrome浏览器
新建一个chrome快捷方式，右键“属性”，“快捷方式”选项卡里选择“目标”，添加 --args --disable-web-security --user-data-dir=C:\MyChromeDevUserData
通过快捷方式打开谷歌浏览器
```


# 上线步骤
* 提交打包后的资源到cdn目录：https://corp.youdao.com/svn/ydstatic/dict/writecorrect
* cdn提交更新shared请求: http://corp.youdao.com/IT/updateshared/
* 提交html文件到: https://dev.corp.youdao.com/svn/outfox/products/desktop/cidian_root/milestones/6.0/grammar/
* 上线Ticket参考： http://ticket.corp.youdao.com/ticketMain!prepareConTicket.action?id=5e71b4bfed505ab2b5ff3a1f&type=7
* 线上访问地址： http://cidian.youdao.com/grammar/index.html#/index