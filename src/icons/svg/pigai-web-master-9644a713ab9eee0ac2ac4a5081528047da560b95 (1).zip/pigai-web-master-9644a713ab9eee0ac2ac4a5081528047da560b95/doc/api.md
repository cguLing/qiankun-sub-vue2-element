# 设计文档
https://www.figma.com/file/QtQoUbbQU3KIN0rJQsPDnc/%E8%8B%B1%E6%96%87%E5%86%99%E4%BD%9C%E6%89%B9%E6%94%B9191119?node-id=0%3A1

# 产品prd
https://note.youdao.com/ynoteshare1/index.html?id=91255920fe1c3027fcf1a9dfce0af9f2&type=note

# 产品计划
http://note.youdao.com/noteshare?id=ca7c5146a31979c3d3433cccf64a4444&sub=96F0C7070E414FE8A01D47074C385DFB

# 服务器接口文档
https://gitlab.corp.youdao.com/fukai/pigaiweb/blob/master/README.md