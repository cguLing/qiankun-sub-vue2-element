# 技术选型
* vue2
* vue-router3
* vuex3
* webpack4
* xss https://github.com/leizongmin/js-xss/blob/master/README.zh.md
* html-to-text https://github.com/werk85/node-html-to-text
* selection-range https://github.com/bmcmahen/selection-range