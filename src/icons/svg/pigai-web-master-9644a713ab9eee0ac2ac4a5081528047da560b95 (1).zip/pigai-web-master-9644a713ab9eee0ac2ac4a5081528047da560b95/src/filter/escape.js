export default function(str){
  str = str == null ? '' : ''+str;
  //console.trace(str);
  return str
    .replace(/</g , '&lt;')
    .replace(/>/g , '&gt;');
}