import Vue from 'vue';
Vue.filter('langCN',function(lang){
  switch(lang){
    case 'fr':
      return '法';

    case 'ko':
      return '韩';

    case 'jap':
    case 'ja':
      return '日';

    case 'de':
      return '德';

    case 'ru':
      return '俄';

    case 'pt':
      return '葡';

    case 'es':
      return '西';

    default:
      return '英';
  }
})