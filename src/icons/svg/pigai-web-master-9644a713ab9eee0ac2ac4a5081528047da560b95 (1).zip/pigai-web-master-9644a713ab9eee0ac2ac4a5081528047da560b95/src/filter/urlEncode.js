import Vue from 'vue';
Vue.filter('urlEncode',function(url){
  url = encodeURIComponent(url);
  return url;
})