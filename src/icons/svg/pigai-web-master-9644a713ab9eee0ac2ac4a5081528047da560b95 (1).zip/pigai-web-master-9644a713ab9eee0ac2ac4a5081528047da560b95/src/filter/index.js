import Vue from 'vue';
import escape from './escape.js';
import './dataClean.js';
import './dictResultEncode.js';
import './urlFilter.js'
import './langCN.js';
import './urlEncode.js';
import './suggest.js';


//longman参考跳转处理
Vue.filter('reflink' , function(str){
  str = escape(str);
  //删除以<i></i>标签及及其内容
  str = str
          .replace(/&lt;(.*)\/i&gt; /g , '');
  return str;
});

//网络释义去掉'<'之后的数据
Vue.filter('webTranClean',function(str){
  str = escape(str);
  if(str.indexOf('PS:') > -1){
    str = '';
  }
  str = str.split('&lt;' , 1);
  return str;
});

//json序列化
Vue.filter('stringify' , function(obj){
  return JSON.stringify(obj);
});

Vue.filter('parseStr' , function(obj){
  return String(obj);
});

//vue对象转化为原生js
Vue.filter('vue2js' , function(obj){
  return  JSON.parse(JSON.stringify(obj))
})

//数字转化为26个字母
Vue.filter('num2letter', function(num){
  var result = '';
  result = generateSmall()[num * 1]
  return result;
})

//生成小写26个字母
function generateSmall() {
  var str = [];
  for (var i = 97; i < 123; i++) {
    str.push(String.fromCharCode(i));
  }
  return str;
}

//判断对象类型
Vue.filter('objectType', function(obj){
  var result = Object.prototype.toString.call(obj);
  var type = '';
  switch (result) {
    case '[object Array]':
      type = 'Array';
      break;
    case '[object Object]':
      type = 'Object';
      break;
    case '[object String]':
      type = 'String';
      break;
  }
  return type;
})

//判断Object类型
Vue.filter('isObject', function(obj){
  var result = Object.prototype.toString.call(obj);
  var type = '[object Object]';
  if(result === type){
    return true
  }else{
    return false;
  }  
})

//判断Array类型
Vue.filter('isArray', function(obj){
  var result = Object.prototype.toString.call(obj);
  var type = '[object Array]';
  if(result === type){
    return true
  }else{
    return false;
  }  
})

//判断String类型
Vue.filter('isString', function(obj){
  var result = Object.prototype.toString.call(obj);
  var type = '[object String]';
  if(result === type){
    return true
  }else{
    return false;
  }  
})

