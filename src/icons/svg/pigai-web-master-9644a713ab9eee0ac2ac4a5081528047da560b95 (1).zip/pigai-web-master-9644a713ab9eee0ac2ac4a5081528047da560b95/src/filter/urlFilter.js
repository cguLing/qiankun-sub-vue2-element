import Vue from 'vue';
Vue.filter('sentUrl',function(url){
  if(/^http[s]?\:\/\//.test(url)){
    var p = url.indexOf('://') + 3;
    url = url.substring(p, url.indexOf('/' , p));
  }
  return url;
})