import Vue from 'vue';
Vue.filter('highlight', function (item , keyword) {
  return item.word.replace(new RegExp('(' + keyword + ')' ,'i') , '<em>$1</em>');
});