import Vue from 'vue';
import escape from './escape.js';

Vue.filter('dataClean',function(str){
  str = escape(str);
  str = str
        .replace(/&nbsp;/g , '')
        .replace(/^&lt;br&gt;/g , '')
        .replace(/&lt;br&gt;/g , '<br>');
  return str;
});