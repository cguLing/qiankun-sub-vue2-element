import Vue from 'vue';
import escape from './escape.js';
Vue.filter('dictResultEncode' , function(str){
  str = escape(str);

  //以下标签是合法的标签
  str = str
          .replace(/&lt;br&gt;/ig , '')
          .replace(/&lt;strong&gt;/ig , '<strong>')
          .replace(/&lt;\/strong&gt;/ig , '</strong>')
          .replace(/&lt;sup&gt;/ig , '<sup>')
          .replace(/&lt;\/sup&gt;/ig , '</sup>')
          .replace(/&lt;em&gt;/ig , '<em>')
          .replace(/&lt;\/em&gt;/ig , '</em>')
          .replace(/&lt;([bBsi])&gt;/ig , '<$1>')
          .replace(/&lt;\/([bBsi])&gt;/ig , '</$1>')
          .replace(/&lt;i(.*)&gt;/ig , '<i>')
          .replace(/&lt;var&gt;/ig , '')
          .replace(/&lt;\/var&gt;/ig , '')
          .replace(/\$/g , '');
  return str;
});