/* 项目启动 */
import Vue from 'vue';
import router from './router';
import store from './store';
import utils from '@/commons/utils';
import Toast from '@/components/toast/index.js';
import Loading from '@/components/loading/index.js';
import axios from 'axios';
import App from './App'
import './filter/index';
import infiniteScroll from 'vue-infinite-scroll'
Vue.use(Toast);  //全局tip插件
Vue.use(Loading); //全局loading插件
Vue.use(infiniteScroll) // 滚动加载插件

Vue.prototype.$http = axios; //数据请求方法
Vue.prototype.$utils = utils; //工具方法

new Vue({
  router,
  store,
  render: h => h(App),
  mounted() {


    //$Vue挂在window对象
    window.$Vue = self;


    //document.dispatchEvent(new Event('render-event'))
  }
}).$mount('#app');
