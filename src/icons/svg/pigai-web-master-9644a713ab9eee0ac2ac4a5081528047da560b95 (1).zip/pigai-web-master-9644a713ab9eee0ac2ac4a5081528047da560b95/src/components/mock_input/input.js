/*eslint-disable */

var search_keyword;
var seq = 0;

ydk.setKeyword = function(params){
  search_keyword = params.keyword;
  $('#mock_input').val(params.keyword);
  params.lang && $('#mock_select').val(params.lang);
  if(params.langDst){
    $('#mock_select').hide();
    $('#mock_select1').show();      
    $('#mock_select1').val(params.lang+'2'+params.langDst);
  }else{
    $('#mock_select').show();
    $('#mock_select1').hide();
  } 
  onKeywordChanged({
    from : 'ydk',
    keyword : params.keyword,
    lang : params.lang || '',
    langDst : params.langDst || '',
    data : [],
    seq : seq++
  })
};

ydk.getKeyword = function(params){
  setTimeout(function(){
    params.success({
      keyword: $('#mock_input').val(),
      lang : $('#mock_select').val(),
      langDst : $('#mock_select1').hide()
    })
  },50);
};

var onNativeKeyDown = function(key) {
  ydk._simulateNative('onNativeKeyDown' , {
    code : 1000,
    key : key,
  } , function(res){
    if (key == 'enter') {
    }
  })
}

var onKeywordChanged = function(opt){
  ydk._simulateNative('onKeywordChanged' ,{
    code : 1000,
    from : opt.from || 'input',
    seq : opt.seq,
    keyword : opt.keyword,
    lang : opt.lang,
    langDst : opt.langDst || '',
    data : opt.data
  } , function(res){
  })
};

export var change = function(val , lang , langDst ,keycode){
  switch(keycode){
    case 38:
      onNativeKeyDown('up');
      return;
    //down
    case 40:
      onNativeKeyDown('down');
      return;
    //enter
    case 13:
      onNativeKeyDown('enter');
      //return;
  }

  if(search_keyword == val){
    return;
  }

  var _seq = seq++;

  if(!val){
    onKeywordChanged({
      keyword : '' ,
      lang : lang,
      langDst : langDst,
      data : [] , 
      seq : _seq
    });
    return;
  }


  $.ajax({
    url : 'http://dict.youdao.com/suggest?type=DESKDICT&num=5&ver=2.0&format=json',
    data : {
      q : val,
      lang : lang
    },
    dataType : 'xml',
    success : function(xml){
      var data = [];
      $("item", xml).each(function(index , item){
        var obj = {};
        obj.trans = $('explain' , item).text();
        obj.word = $('title' , item).text();
        data.push(obj);
      });

      onKeywordChanged({
        keyword : val ,
        lang : lang,
        langDst : langDst,
        data : data , 
        seq : _seq
      });
    }
  })
};


export var submit  = function(keyword , lang , langDst){
  ydk._simulateNative('onKeywordSubmit' , {
    code : 1000,
    errMsg : '',
    from : 'input',
    seq : seq++,
    keyword : keyword,
    lang  : lang || 'eng',
    langDst : langDst || '',
    target : '',
    type : '',
  } , function(res){
      
  })
};