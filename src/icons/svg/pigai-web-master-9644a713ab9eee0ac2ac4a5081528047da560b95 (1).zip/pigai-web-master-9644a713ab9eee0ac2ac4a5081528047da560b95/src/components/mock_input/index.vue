<template>
    <div class="mock-container" v-if="showInput">
        <select v-show="!isTarget" @change="changeQuery" id="mock_select" class="mock-select">
          <option value="en">英汉</option>
          <option value="ja">日汉</option>
          <option value="fr">法汉</option>
          <option value="ko">韩汉</option>
          <option value="de">德汉</option>
          <option value="ru">俄汉</option>
          <option value="es">西汉</option>
          <option value="pt">葡汉</option>
          <option value="auto">自动</option>          
        </select>
        <input type="button" v-show="!isTarget" value="指定语种" id="mock_forward"  @click="isTarget = !isTarget">
        <select v-show="isTarget" @change="changeQuery" id="mock_select1" class="mock-select">
          <option value="">请选择语言</option>
          <option value="zh-CHS2en" lang="zh-CHS" langDst="en">中->英</option>
          <option value="zh-CHT2fr" lang="zh-CHT" langDst="fr">中(繁)->法</option>
          <option value="zh-CHS2ja" lang="zh-CHS" langDst="ja">中->日</option>
          <option value="ja2zh-CHS" lang="ja" langDst="zh-CHS">日->中</option>
          <option value="zh-CHS2uk" lang="zh-CHS" langDst="uk">中->乌克兰</option>
          <option value="zh-CHS2ar" lang="zh-CHS" langDst="ar">中->阿拉伯</option>
          <option value="zh-CHS2km" lang="zh-CHS" langDst="km">中->高棉</option>
          <option value="en2ja" lang="en" langDst="ja">英->日</option>
          <option value="en2vi" lang="en" langDst="vi">英->越</option>         
        </select>        
        <input type="button" value="后退" id="mock_back" @click="goBack"> 
        <input type="button" value="前进" id="mock_forward" @click="goNext">
        <input  id='mock_input' placeholder="输入关键字" autocomplete="off" @keyup="fastQuery">
        <button id='mock_button' type="submit" @click="query">查询</button>
        <button id='mock_history_button' @click="showHistory">历史记录</button>
        <button @click="showInput = !showInput">隐藏</button>
    </div>
</template>

<script>
import './mock.js';
import * as keywordNative from './input.js';

export default {
  data() {
    return {
      showInput: true,
      isTarget: false
    };
  },
  methods: {
    changeQuery: function() {
      var keyword = document.getElementById('mock_input').value;
      var lang = document.getElementById('mock_select').value;
      var langDst = document.getElementById('mock_select1').value;

      if (langDst) {
        lang = langDst.substr(0, langDst.indexOf('2'));
        langDst = langDst.substr(langDst.indexOf('2') + 1);
      }

      keywordNative.change(keyword, lang, langDst, event.keyCode);
      this.$store.dispatch('setKeyWord', keyword);
      this.$store.dispatch('setLang', lang);
      this.$store.dispatch('setDstLang', langDst);
    },
    fastQuery: function() {
      var keyword = document.getElementById('mock_input').value;
      var lang = document.getElementById('mock_select').value;
      var langDst = document.getElementById('mock_select1').value;

      if (langDst) {
        lang = langDst.substr(0, langDst.indexOf('2'));
        langDst = langDst.substr(langDst.indexOf('2') + 1);
      }

      keywordNative.change(keyword, lang, langDst, event.keyCode);
      this.$store.dispatch('setKeyWord', keyword);
      this.$store.dispatch('setLang', lang);
      this.$store.dispatch('setDstLang', langDst);
    },
    query: function() {
      var keyword = document.getElementById('mock_input').value;
      var lang = document.getElementById('mock_select').value;
      var langDst = document.getElementById('mock_select1').value;

      if (langDst) {
        lang = langDst.substr(0, langDst.indexOf('2'));
        langDst = langDst.substr(langDst.indexOf('2') + 1);
      }
      ydk.setKeyword({
        keyword: keyword,
        lang: lang,
        langDst: langDst
      });

      keywordNative.submit(keyword, lang, langDst);
      this.$store.dispatch('setKeyWord', keyword);
      this.$store.dispatch('setLang', lang);
      this.$store.dispatch('setDstLang', langDst);
    },
    goBack: function() {
      this.$utils.prevAndNext(this, 'prev');
    },
    goNext: function() {
      this.$utils.prevAndNext(this, 'next');
    },
    showHistory: function() {
      var is_show_history = this.$store.state.dict.is_show_history;
      this.$store.dispatch('setDictHistory', !is_show_history);
    }
  }
};
</script>

<style scoped lang="scss">
@import "./index";
</style>