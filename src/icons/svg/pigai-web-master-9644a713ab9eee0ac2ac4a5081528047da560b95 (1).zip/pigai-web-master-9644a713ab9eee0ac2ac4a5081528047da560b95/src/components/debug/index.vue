<template>
  <div>
    <router-link to="/ydk" class="_dev_flag flag_right">{{ date }}</router-link>
  </div>
</template>
<script>
import config from 'config';
import VConsole from 'vconsole';

let vConsole = null;

export default {
  data: function () {
    return {
      date: new Date(config.version).format('yyyy-MM-dd HH:mm:ss'),
    };
  },
  mounted() {
    //调试面板
    vConsole = new VConsole();
  },
  destroyed() {
    vConsole.destroy();
  },
};
</script>
<style lang="scss" scoped>
._dev_flag {
  position: fixed;
  top: 0;
  right: 0;
  background: #000;
  color: #fff;
  font-size: 12px;
  padding: 0 5px;
  z-index: 10000000;
}

.flag_left {
  left: 0;
  right: initial;
}
.flag_right {
  right: 0;
  left: initial;
}
</style>