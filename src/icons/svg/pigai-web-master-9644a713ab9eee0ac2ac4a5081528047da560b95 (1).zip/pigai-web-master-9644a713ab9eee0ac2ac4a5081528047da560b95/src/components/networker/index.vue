<template>
<div id="networkerComponents">
  <div class="content">
   <img src="./imgs/networker_pic_NoNetwork.png" class="picTips" />
   <p class="txtTips">暂无网络连接</p>
  </div>
</div>  
</template>
<script>
export default{}  
</script>
<style lang="scss">
#networkerComponents{
  position: relative;
  width:100%;
  height:100%;
  .content{
     position: absolute;
     top: 50%;
     left: 50%;
     transform: translate(-50% , -50%);
     width: 225px;
     height: 165px;
      .picTips{
        display:block;
        width: 225px;
        height:129px;
      }
      .txtTips{
        text-align:center;
        font-size: 15px;
        color: #333333;
        padding-top:16px;  
      }     
  }  
}  
</style>