<template>
    <transition name="fade">      
      <div class="f-dialog-confirm" v-if="visible">
        <div class="mask" v-show="mask"></div>
        <div class="container" :style="{width: width}">
          <div class="header">
            <span>{{title}}</span>
            <a href="javascript:;" v-if="isShowCloseBtn" @click="cancel" class="icon icon-close close"></a>
          </div>
          <div class="content">
            <slot name="content"></slot>
          </div>
          <div class="footer">
            <slot name="footer">
              <a href="javascript:;" @click="sure" class="g-btn-red btn-ok">{{okText}}</a>
              <a href="javascript:;" @click="cancel" class="g-btn-normal btn-cancel">{{cancelText}}</a>
            </slot>  
          </div>          
        </div>
      </div>
    </transition>  
</template>

<script>
export default {
  name: 'Confirm',
  props: {
    width: {
      type: String,
      default: '300px'
    },
    title: {
      type: String,
      default: '信息'
    },
    okText : {
      type: String,
      default: '确定'
    },
    cancelText : {
      type: String,
      default: '取消'
    },
    mask : {
      default: true
    },        
    visible: {
      default: false
    },
    isShowCloseBtn: {
      default: true
    }
  },
  methods: {
    cancel () {
      this.$emit('cancel');
    },
    sure () {
      this.$emit('ok');
    }
  },
  mounted (){
  
  }  
}  
</script>

<style scoped lang="scss">
.f-dialog-confirm{
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  text-align: center;
  z-index: 99;
  &:before{
    content: '';
    height: 100%;
    width: 0;
    font-size: 0;
    line-height: 0;
    display: inline-block;
    vertical-align: middle;
  }    
}
.mask{
  width: 100%;
  height: 100%;
  position: absolute;
  top:0;
  left: 0;
  background: rgba(0 ,0 ,0 ,.3);
  z-index: 1;
}
.container{
  vertical-align: middle;
  display: inline-block;
  background: #FFFFFF;
  border: 1px solid #E6E6E6;
  box-shadow: 0 0 8px 0 rgba(98,100,102,0.20);
  border-radius: 2px;
  position: relative;
  padding-bottom: 0px;
  z-index: 2;
  .header{
    height: 40px;
    line-height: 40px;
    background: #FAFAFA;
    position: relative;
    text-align: left;
    font-size: 13px;
    border-bottom: 1px solid #f0f0f0;    
    span{
      color: #666666;
      padding:15px 0px 0px 20px;     
    }
    .close{
      right: 20px;
      top: 10px;
      position: absolute;
      font-size: 16px;
      color: #999999;     
    }
  }
  .content{
    min-height: 60px;
    text-align: left;
    padding: 0px 20px 0px 20px;  
  }
  .footer{
    text-align: right;
    padding: 10px 20px 20px 0px;
    a{
      width: 84px;
      line-height: 30px;
      height: 30px;
      display: inline-block;      
    }
    a:nth-child(1){
      margin-right: 5px;
    }
    .btn-cancel{
      padding: 0;
      text-align: center;
      line-height: 28px;
    }
  }   
}
.fade-enter-active, .fade-leave-active {
  transition: opacity .5s
}
/* .fade-leave-active in below version 2.1.8 */ 
.fade-enter, .fade-leave-to{
  opacity: 0
} 
</style>