<template>
  
</template>
<script>
/**
 * vue的自动发音组件
 *
 * 例子:
 * <autovoicer :speech="" :ukspeech="" :usspeech=""></autovoicer>
 */
import * as settinger from 'modules/dict_setting';
import config from 'config';

var playVoice = url => {
  if (config.platform !== 'uwp') {
    top.ydk.playNativeVoice({
      localId: 'http://dict.youdao.com/dictvoice?audio=' + url
    });
  } else {
    ydk.playVoice({
      localId: 'http://dict.youdao.com/dictvoice?audio=' + url, // 音频文件的 url
      currentTime: 0
    });
  }
  console.log('自动发音:url:', url);
};

var play = _.debounce(function() {
  var self = this;
  settinger.get(setting => {
    console.log('自动发音:enable:', self.enable);
    var options = setting.content;
    if (typeof self.enable == 'boolean') {
      if (!self.enable) {
        return;
      }
    } else if (!options.auto_pronounce) {
      return;
    }

    var url =
      (options.pronounce_type == 'us' ? self.usspeech : self.ukspeech) ||
      self.speech;

    if (self.usspeech && !self.ukspeech) {
      url = self.usspeech;
    }

    if (!self.usspeech && self.ukspeech) {
      url = self.ukspeech;
    }

    if (!self.usspeech && !self.ukspeech) {
      url = self.speech;
    }

    if (!url) return;

    playVoice(url);
  });
}, 500);

export default {
  props: {
    enable: [Boolean],
    speech: String,
    ukspeech: String,
    usspeech: String,
    seq: Number
  },
  watch: {
    // watch 这里有问题呢
    enable: play,
    speech: play,
    ukspeech: play,
    usspeech: play,
    seq: play
  },
  mounted: play
};
</script>