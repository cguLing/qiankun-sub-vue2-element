import * as settinger from 'modules/dict_setting';
import config from 'config';

var playVoice = (url) => {
  if (config.platform !== 'uwp') {
    top.ydk.playNativeVoice({
      localId: 'http://dict.youdao.com/dictvoice?audio=' + url
    })
  } else {
    ydk.playVoice({
      localId: 'http://dict.youdao.com/dictvoice?audio=' + url, // 音频文件的 url
      currentTime: 0
    });
  }
  console.log('自动发音:url:', url)
}

export default function (params = {
  enable: true,
  usspeech: '',
  ukspeech: '',
  speech: ''
}) {
  var enable = params.enable;
  var usspeech = params.usspeech;
  var ukspeech = params.ukspeech;
  var speech = params.speech;

  settinger.get((setting) => {
    var options = setting.content;
    if (typeof (enable) == 'boolean') {
      if (!enable) {
        return;
      }
    } else if (!options.auto_pronounce) {
      return;
    }

    var url = (
        options.pronounce_type == 'us' ?
        usspeech :
        ukspeech
      ) ||
      speech;

    if (usspeech && !ukspeech) {
      url = usspeech;
    }

    if (!usspeech && ukspeech) {
      url = ukspeech;
    }

    if (!usspeech && !ukspeech) {
      url = speech;
    }

    if (!url) return;

    playVoice(url);

  })
};
