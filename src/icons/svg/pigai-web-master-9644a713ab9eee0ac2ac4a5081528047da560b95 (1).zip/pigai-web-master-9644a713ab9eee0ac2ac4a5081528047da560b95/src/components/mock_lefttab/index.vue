<template>
    <div class="left">
        <div class="tabs">
          <div class="tab" @click="goPage('dict')" :class="{active : active == 'dict'}"><em class="icon icon-search-dict"></em>查词翻译</div>
          <div class="tab" @click="goPage('translate')" :class="{active : active == 'translate'}"><em class="icon icon-search-dict"></em>翻译</div>
          <div class="tab" @click="goPage('ke')" :class="{active : active == 'ke'}"><em class="icon icon-ke"></em>精品课</div>
          <div class="tab" @click="goPage('fanyi')" :class="{active : active == 'fanyi'}"><em class="icon icon-fanyi2"></em>人工翻译</div>
          <div class="tab" @click="goPage('doctran')" :class="{active : active == 'doctran'}"><em class="icon icon-note"></em>文档翻译</div>
          <!-- 单词本 -->
          <div class="tab" @click="goPage('mock_wordbook')" :class="{active : active == 'mock_wordbook'}"><em class="icon icon-note"></em>单词本</div>
        </div>
        
        <ul class="opt">
          <li><label><input type="checkbox" class="g-checkbox">取词</label></li>
          <li><label><input type="checkbox" class="g-checkbox">划词</label></li>
        </ul>
    </div>
</template>

<script>
import * as methods from './methods';
export default {
  data : function(){
    return {
      active : this.$store.state.common.activeKey || '',
    }
  },
  watch : {
    '$route' : function(to , from){
      var fromKey = from.name;
      var toKey = to.name;
      if(!toKey) this.active = 'dict';
      if(toKey && (fromKey != toKey)){
        this.active = toKey;
      }        
    }
  }, 
  methods : methods,
  mounted : function(){
  }
}
</script>

<style scoped lang="scss">
 @import './index';
</style>
