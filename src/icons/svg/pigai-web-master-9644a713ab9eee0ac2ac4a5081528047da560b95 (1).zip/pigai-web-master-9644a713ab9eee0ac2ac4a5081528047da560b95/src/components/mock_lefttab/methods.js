export function goPage(activePage) {
  var self = this;

  self.active = activePage;
  self.$store.dispatch('setTab', self.active);
  if(activePage == 'wordbook_card'){
    self.$router.push({ path : '/wordbook_card' , query: { category : '*' , order : 'timenew' }});
  }else if(activePage == 'wordbook_detail'){
    self.$router.push({ path : '/wordbook_detail' , query : { keyword : 'good' , lang : 'en'} });
  }else if(activePage == 'wordbook_edit'){
    self.$router.push({ path : '/wordbook_edit' , query : { keyword : 'good' , lang : 'en'} });
  }else if(activePage == 'wordbook_review'){
    self.$router.push({ path : '/wordbook_review' , query : { disorder : false , disorderBtnClicked : false, category : '*'} });
  }else if(activePage == 'wordbook_noaddition'){
    self.$router.push({ path : '/wordbook_noaddition' , query : { category : '*'} });
  }else{
    self.$router.push('/'+self.active);
  }
}