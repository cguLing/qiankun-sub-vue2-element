/* 路由配置全写这里 */
import Vue from 'vue'
import VueRouter from 'vue-router'
import utils from '@/commons/utils';
Vue.use(VueRouter);


const Index = r => require.ensure([], () => r(require('../pages/index/index')), 'index');
const Ydk = r => require.ensure([], () => r(require('../pages/ydk/index')), 'ydk');
const Fail = r => require.ensure([], () => r(require('../pages/fail/index')), 'fail');
const Home = r => require.ensure([], () => r(require('../pages/home/index')), 'home');

let router = new VueRouter({
  mode: 'hash',
  base: __dirname,
  routes: [      
    //地址为空时跳转首页
    {
      path: '',
      redirect: '/home'
    },

    //批改首页
    {
      name: 'index',
      path: '/index/:uniqueKey?',
      component: Index
    },
    //用户主页，显示历史批改记录等信息
    {
      name: 'home',
      path: '/home',
      component: Home
    },
    //无网络错误失败的页面
    {
      name: 'fail',
      path: '/fail',
      component: Fail
    },

    //ydk测试页面
    {
      name: 'ydk',
      path: '/ydk',
      component: Ydk
    }]
})

// router.beforeEach((to, from, next) => {
//   // ...

//   utils.checkLogin()
//   next()
// })

export default router