// TODO: 使用2.1的翻译接口，替换后的句子可以单独双击选中
import * as api from './api';
// import select from 'selection-range'
//显示
export function show(params) {
  this.style.left = (params.left || 0) + 'px';
  this.style.top = (params.top || 0) + 'px';
  this.sentId = params.sentId;
  this.rawSent = ''
  this.isEditAble = false;
  this.isShowSuggest = false;
  this.InitTranslate(params.rawSent, 'en', 'zh-CHS')
  this.isShow = true;
}

export function hide() {
  this.isShow = false;
}

export function replace() {
  let targetList = document.querySelectorAll(`[data-id="${this.sentId}"]`);
  targetList[0].innerHTML = '<span>' + this.suggest + '</span>'
  this.$emit('update', this.sentId)
  this.hide()
  ydk.rlog({
    action: 'check_translate_replace'
  })
}

// 展开
export function showSuggest() {
  this.isEditAble = true;
  // this.getEditTranslate()
  let target = document.querySelectorAll(`[data-id="${this.sentId}"]`)[0]
  this.suggest = target.innerText
  this.isShowSuggest = true;
  let input = document.getElementById('raw-area')
  requestAnimationFrame(()=>{
    let len  = input.value.length
    input.focus()
    input.setSelectionRange(len, len)
  })
  ydk.rlog({
    action: 'check_translate_edite'
  })
}

//handleInput
export function handleInput(e) {
  this.rawSent = e.target.innerText;
}

export function InitTranslate(keyword, from, to) {
  let params = {
    data: {
      keyword,
      from,
      to
    }
  }
  api.cryptoNet(params).then(res => {
    this.rawSent = res.data.translateResult[0]
  });
}

export function getEditTranslate() {
  let params = {
    data: {
      keyword: this.rawSent.trim(),
      from: 'zh-CHS',
      to: 'en'
    }
  }
  if (params.data.keyword === '') {
    this.suggest = ''
    return
  } else {
    api.cryptoNet(params).then(res => {
      this.suggest = res.data.translateResult[0]
    });
  }
}

export function resetPostion(top){
  // this.style.left = (params.left || 0) + 'px';
  this.style.top = (top || 0) + 'px';
  this.isShow = true
}

//设置光标到最后
export const keepLastIndex = function () {
  let self = this;
  let obj = $(self.$el).find('.editorComponent');
  obj.focus();
  var range = window.getSelection(); //创建range
  range.selectAllChildren(obj[0]); //range 选择obj下所有子内容
  range.collapseToEnd(); //光标移至最后
}

export const clear = function(){
  this.$emit('clear')
  this.isShow = false
}