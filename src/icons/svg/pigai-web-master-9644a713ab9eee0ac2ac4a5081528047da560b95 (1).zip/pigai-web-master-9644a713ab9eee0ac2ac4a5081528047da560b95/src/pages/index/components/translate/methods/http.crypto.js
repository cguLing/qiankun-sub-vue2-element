// 翻译加密处理
window.Buffer = window.Buffer || require('buffer').Buffer;
import crypto from 'crypto'
import Config from 'config'
import axios from 'axios'
import qs from 'qs'
import { Buffer } from 'buffer';


const {
  pigaiHost,
  signWhiteList,
  secretWhiteList,
  fanyiSecretKey,
  secretIv,
  algorithm,
  // secretId
} = Config

/**
 * 签名名单检测
 * @param {*} url
 */
function checkSignWhiteList(url) {
  // const { pathname } = new URL(url)
  return signWhiteList.indexOf(url) > -1
}


/**
 * 加密名单检测
 * @param {*} url
 */
function checkDecodeWhiteList(url) {
  // const { pathname } = new URL(url)
  return secretWhiteList.indexOf(url) > -1
}


/**
 * md5加密
 * @param {String} str md5
 * @param {*} decode
 */
function md5(str, decode) {
  return crypto
    .createHash('md5')
    .update(str)
    .digest(decode)
}

/**
 * 数据解密（弃用）
 * @param {*} data
 */
function decodeData(data) {
  if (!data) {
    return null
  }

  const key = Buffer.alloc(16, md5(fanyiSecretKey)) // 16位密钥 默认 'utf-8'

  const iv = Buffer.alloc(16, md5(secretIv)) // 16位向量

  const decipher = crypto.createDecipheriv(algorithm, key, iv)

  let decrypted = decipher.update(data, 'base64', 'utf-8') // 原数据 'base64' 解密后数据 ’utf-8‘
  decrypted += decipher.final('utf-8')


  return decrypted
}

/**
 * 生成签名 文档：
 * https://gitlab.corp.youdao.com/translator-dev/smtfront/blob/master/docs/API.md
 * sign是加密结果，加密规则为：client的取值 + i(翻译文本) + salt(随机数) + 私钥 ==> 取md5的值
 * @param {*} data 
 */
function genSign(data) {
  var signString = `${data.client}${data.i}${data.salt}${fanyiSecretKey}`;
  return md5(signString, 'hex');
}


/**
 * 开发模式下加解密请求实例
 */
const http = axios.create({
  method: 'post', // 默认值
  baseURL: '//' + translateHost,
  timeout: 30000,
  withCredentials: true, // 是否携带cookie信息
  responseType: 'json', // 默认值是json
  maxContentLength: 2000, // http响应内容的最大长度
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded'
  },
  validateStatus: function (status) {
    return status >= 200 && status < 300 // default
  },
  transformRequest: [
    function (data) {
      return qs.stringify(data)
    }
  ],
  transformResponse: []
})


http.interceptors.request.use(
  function (config) {
    const { url, data, params, method } = config // 这里axios有错误： url在方法执行后会变成 baseURL + url
    if (checkSignWhiteList(url)) {
      let signData = {}
      switch (method) {
        case 'get':
          signData = params
          break
        case 'post':
          signData = data
          break
      }
      Object.assign(signData, {
        sign: genSign(signData)
      })
    }
    return config
  },
  function (error) {
    Promise.reject(error)
  }
)

http.interceptors.response.use(
  function (response) {
    const config = response.config
    const url = config.url
    if (checkDecodeWhiteList(url)) {
      const { data } = response
      const d = decodeData(data.data)
      data.data = JSON.parse(JSON.parse(d));
    }
    // console.log('返回数据：', response.data)
    return response
  },
  function (error) {
    Promise.reject(error)
  }
)

export default http