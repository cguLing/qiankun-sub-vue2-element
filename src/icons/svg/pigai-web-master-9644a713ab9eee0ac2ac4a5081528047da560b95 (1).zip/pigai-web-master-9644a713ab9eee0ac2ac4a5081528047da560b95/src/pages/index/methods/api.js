import $Http from '@/service/httpPigai.js';
export const getHistory = (params) => {
  const url = '/dictserver/writing/correct/getHistory'
  return $Http({
    method: 'GET',
    url,
    params
  })
}

export const getUserNickname = () => {
  const url = '/profile/nickname/my'
  return $Http({
    method: 'GET',
    url
  })
}

export const logout = () => {
  const url = 'login/acc/se/reset'
  return $Http({
    method: 'POST',
    url,
    data: {
      product: 'DICT',
      app: 'web',
      keyfrom: 'pigai.web'
    }
  })
}
