/* eslint-disable */
import API from '@/api/api';
import filter from './filter.js'
import generateEssayHtml from './generateEssayHtml'
import select from 'selection-range'
import Store from 'commons/localStorage.js';
import SessionStore from 'commons/sessionStorage.js';
import Config from 'config';
import $HttpPigai from '@/service/httpPigai.js'
import $HttpTranslate from '@/service/httpTranslate.js'
import * as api from './api.js'
// import {
//   set
// } from 'lodash';
// import {
//   clear
// } from '../components/editDiv/methods.js';

let currentSelectedErrorTarget = null; // 当前选择高亮的错误节点dom

//历史操作数据
const History = {
  essayHtml: '',
  isIgnored: false,
  isAccepted: false,
  fixedStartPos: '',
  fixedEndPos: '',
  rawSentsFeedback: []
};

//由于存在忽略操作，服务器要知道前端的批改行为
//规则： 接受和忽略要记录、 如果修改（新增、删除操作）了该句子则不用记录
// let rawSentsWithErrPos = {}
// let userActionSeq = {}

/**
 * 批改post请求接口（上线使用）
 */
const submit = data => {
  // let url = '/pigai/v/sign_action';
  let url = '/dictserver/writing/correct/submit'
  return $HttpPigai({
    method: 'POST',
    url,
    data,
  });
}
/**
 * 保存草稿post请求接口（上线使用）
 */
const save = data => {
  let url = '/dictserver/writing/correct/saveDraft'
  return $HttpPigai({
    method: 'POST',
    url,
    data,
  });
}

const translate = text => {
  let url = '/translate';
  return $HttpTranslate({
    method: 'POST',
    url,
    data: {
      i: text, // 翻译文本
      from: 'en', // 原语言
      to: 'zh-CHS', // 目标语言
      client: 'pigaiweb', // 用于身份验证，和私钥配对
      salt: new Date().getTime(), // 随机数
      version: '2.1', // 翻译格式版本，2.1版本可以实现句子对齐
      keyfrom: 'pigai.web', // 额外参数
    },
  })
}
/**
 * 获取英文写作数据（post接口，需签名、需跨域）
 * @param {*} options showEssayFeedback 是否展示批改结果
 */
export async function pigaiPost(options = {
  showEssayFeedback: true
}) {
  let self = this;
  self.isSendingPigaiRequest = true;
  if (options.showEssayFeedback) {
    self.isloading = true;
  }
  const param = options.data;

  // 提交请求
  submit(
    param
  ).then((res) => {
    let result = res ? res.data : {}
    // if (Utils.isIE11()) {
    //   // ie11需要再解析一次json
    //   result = JSON.parse(result);
    // }

    self.isloading = false;
    self.isSendingPigaiRequest = false;
    // console.log('code:', result.code)
    //赋值原始错误数据
    if (result.code === 0) {
      self.errorType = 0
      if (options.showEssayFeedback && result.data.essayFeedback && result.data.essayFeedback.sentsFeedback && options.showEssayFeedback) {
        // 请求成功，并且批改结果、并且允许展示结果
        let rawSentsFeedback = filter.genRawSentsFeedback(result.data.essayFeedback.sentsFeedback);
        self.$store.dispatch('setFeedbackData', result.data.essayFeedback.sentsFeedback)
        self.$store.dispatch('setRawSentsFeedback', rawSentsFeedback);
        // self.$store.dispatch('setRawSentsIncludeFeedback', rawSentsFeedback);
        // console.log('getFeedbackData:', this.$store.getters.getFeedbackData)
        self.updateTypeAndessayHtml(self.inputText, self.rawSentsFeedback, {
          currentType: self.currentType
        });

        //保留原始段落信息
        self.rawSentsWithErrPos = filter.genModfiySentsFeedback(result.data.essayFeedback.sentsFeedback);

        self.$nextTick(() => {
          // 设置第一个错误详情展开
          // self.setFirstErrorActive();

          //设置光标位置
          let editor = $(self.$el).find('.editorComponent');
          // console.log(cursorPos)
          // cursorPos.start= 44
          // cursorPos.end =44
          // console.log(editor[0])
          if (cursorPos) {
            select(editor[0], cursorPos);
            // editor[0].setSelectionRange(cursorPos.start,cursorPos.end)
          }
        });

        //设置编辑区域提示
        if (self.rawSentsFeedback.length > 0 && !Store.get('is_click_bubble_edit')) {
          self.showEditBubbleTips = true;
        }

        //设置翻译对照提示
        // if (!Store.get("is_click_bubble_trans")) {
        //   self.showTransBubbleTips = true;
        // }

        //允许点击翻译对照按钮
        this.isShowCompare = true
        this.userActions = []
        this.$store.dispatch('setUniqueKey', result.data.uniqueKey)
      }
    }
    // 抱歉，我们的批改长度目前是5000字符以内
    else if (result.code === 1002) {
      self.errorType = 2
    }
    // 太短
    else if (result.code === 1003) {
      self.errorType = 3
    }
    // 抱歉，我们暂时只支持英文批改
    else if (result.code === 1004) {
      self.errorType = 4
    }
    // 抱歉，遇到一点问题，请稍候重试
    else {
      self.errorType = 1
    }
    // 请求成功了，但是批改出错，报错
    // self.errorMsg = result.error;
    // self.clearResult();
    // self.$toast.show({
    //   type: 'error',
    //   text: `${result.error}`
    // })
  }, (error) => {
    // 请求没成功，报错
    self.isloading = false;
    self.isSendingPigaiRequest = false;
    self.errorType = 5
  })
}

//清空结果
export function clearResult() {
  let self = this;
  // self.data.currentTypeInfos = [];
  self.$store.dispatch('setTitle', '')
  self.$store.dispatch('setInputText', '')
  self.$store.dispatch('setCurrentType', 1)
  self.$store.dispatch('setFeedbackData', '')
  self.data.allTypeInfos = [];
  self.receiveText = ''
  self.rawSentsWithErrPos.sents = []
  self.isPigaiStartted = false
  // self.data.errorTypeInfos = [];
  // self.data.irregularTypeInfos = [];
  // self.$store.dispatch('setRawSentsFeedback', []);
  // self.$store.dispatch('setRawSentsIncludeFeedback', []);
  // self.updateTypeAndessayHtml(self.inputText, []);
  //设置光标位置
  self.$nextTick(function () {
    let editor = $(self.$el).find('.editorComponent');
    if (cursorPos) {
      select(editor[0], cursorPos);
    }
  });
}

/**
 * 发送批改请求
 * @param {*} options  showEssayFeedback 是否展示批改结果
 */
export function sendPigaiRequest(options = {
  showEssayFeedback: true
}) {
  let self = this;
  if (self.isSendingPigaiRequest) {
    return
  }
  //无内容
  if (self.inputText.length <= 0) {
    self.data.currentTypeInfos = [];
    self.data.allTypeInfos = [];
    self.data.errorTypeInfos = [];
    self.data.irregularTypeInfos = [];
    self.$store.dispatch('setRawSentsFeedback', []);
    self.$store.dispatch('setRawSentsIncludeFeedback', []);
    self.errorType = 0
    self.isPigaiStartted = false
    return;
  }

  //超出字数限制
  if (self.inputText.length > self.maxLimitnNum) {
    // self.$toast.show({
    //   type: 'error',
    //   text: `超出最大文字${self.maxLimitnNum}限制`
    // })
    // self.errorMsg = `超出最大文字${self.maxLimitnNum}限制`;
    // self.clearResult();
    this.errorType = 2
    return;
  }
  let text = self.inputText
  // console.log('preText', text)
  // translate(text).then((res) => {
  //   text = res.data.translateResult[0]
  //   console.log(text)
  let data = {
    isActionCacheMode: true,
    userActionSeq: JSON.stringify(self.userActionSeq),
    title: self.title || 'untitled',
    text: text,
    stLevel: 0,
    keyfrom: 'web1.0',
  };
  if (self.uniqueKey !== '') {
    data.lastUniqueKey = self.uniqueKey
  }
  // console.log('data', data)

  self.pigaiPost({
    data: data,
    showEssayFeedback: options.showEssayFeedback
  });
  // })
}

// 发送保存草稿的请求
export function sendSaveDraftRequset() {
  let self = this
  if (self.inputText === '') {
    return
  } else {
    let data = {
      title: self.title || 'untitled',
      text: self.inputText,
      stLevel: 0,
      keyfrom: 'web1.0',
    };
    if (self.uniqueKey !== '') {
      data.uniqueKey = self.uniqueKey
    }
    // console.log('saveData', data)
    save(data).then(res => {
      console.log(res.data)
    })
  }
}


/**
 * 手动批改
 */
export function manualCorrecting(isAuto = false) {
  // 清除自动保存草稿的计时器
  this.InputcleartTimer && clearTimeout(this.InputcleartTimer)
  // console.log('manualCorrecting')
  this.isPigaiStartted = true
  this.sendPigaiRequest();
  if (!isAuto) {
    ydk.rlog({
      action: 'check_byhand'
    })
  }
}

//监听EditDiv组件内容变化
let isInputStart = true;
// let InputcleartTimer = null;
let currentInputText = ''; //当前输入的文本
let startPosition = null; //鼠标开始位置
let endPosition = null; //鼠标结束位置
let cursorPos = null; //鼠标相关信息
export function onEditComponentInput(inputText) {
  const delayTime = 2000; //延迟2s发送请求
  inputText = inputText.trimStart()
  // console.log("inputText", inputText)
  let self = this;
  this.$store.dispatch('setInputText', inputText);
  this.InputcleartTimer && clearTimeout(this.InputcleartTimer)
  this.InputcleartTimer = setTimeout(function () {
    // self.sendSaveDraftRequset()
    let editor = $(self.$el).find('.editorComponent');
    startPosition = self.$utils.getDivCursortPosition(editor[0]);
    endPosition = self.$utils.getDivCursortPosition(editor[0]);
    cursorPos = select(editor[0]);
    // self.manualCorrecting()
    self.isPigaiStartted = true;
    self.sendPigaiRequest();
  }, delayTime)
}

export function onTitleInput(inputText) {
  const delayTime = 2000; //延迟2s发送请求
  let self = this;
  this.$store.dispatch('setInputText', inputText);
  this.InputcleartTimer && clearTimeout(this.InputcleartTimer)
  this.InputcleartTimer = setTimeout(function () {
    // self.sendSaveDraftRequset()
    // let editor = $(self.$el).find('.editorComponent');
    // startPosition = self.$utils.getDivCursortPosition(editor[0]);
    // endPosition = self.$utils.getDivCursortPosition(editor[0]);
    // cursorPos = select(editor[0]);
    // self.manualCorrecting()
    // self.sendPigaiRequest();
    self.sendPigaiRequest({
      showEssayFeedback: false
    });
  }, delayTime)
}
// export function onEditComponentInput(val) {
//   let self = this;
//   let editor = $(self.$el).find('.editorComponent');
//   let inputValue = val;

//   self.errorMsg = '';
//   self.inputing = true;
//   self.textFrom = 'input';
//   tempP.remove();
//   self.$store.dispatch('setInputText', inputValue);


//   //清除正在输入错误提示
//   self.clearCurrentError();

//   if (isInputStart) {
//     startPosition = self.$utils.getDivCursortPosition(editor[0]);
//     isInputStart = false;
//   }
// }

// 监听EditDiv组件focus


export function onEdiComponentFocus(inputText) {
  this.showEditEmptyGuide = false;
}

//更新当前错误类型以生成html
export function updateTypeAndessayHtml(input, includeOperationErrPostInfo, options) {
  let self = this;
  // console.log('updateTypeAndessayHtml-input',input)
  //合并参数
  options = Object.assign({
    currentType: self.currentType, //当前选中的错误类型
    isChangeEditText: true //是否更新输入框的内容
  }, options);

  self.data.allTypeInfos = filter.genAllErrorPostInfo(self.rawSentsFeedback);
  // self.data.allTypeInfos = self.data.allTypeInfos.filter((e) => {
  //   return self.userActions.find(action => action.errorId !== e.errorId) !== undefined
  // })
  // console.log('allTypeInfos',self.data.allTypeInfos)
  // self.data.errorTypeInfos = filter.genTypeErrorPostInfo(self.rawSentsFeedback);
  // self.data.irregularTypeInfos = filter.genTypeIrregularPostInfo(self.rawSentsFeedback);
  // self.data.currentTypeInfos = self.data.allTypeInfos;
  if (options.currentType == 1) self.data.currentTypeInfos = self.data.allTypeInfos;
  if (options.currentType == 2) self.data.currentTypeInfos = self.errorTypeInfos;
  if (options.currentType == 3) self.data.currentTypeInfos = self.irregularTypeInfos;
  if (options.isChangeEditText) {
    let curEssayHtml = self.essayHtml;
    // self.essayHtml = generateEssayHtml.genEssayHtml(input, includeOperationErrPostInfo, options);
    // console.log(generateEssayHtml.genEssaySentHtml(input,this.$store.getters.getFeedbackData,options));
    self.essayHtml = generateEssayHtml.genEssaySentHtml(input, this.$store.getters.getFeedbackData, options);
    //2次内容一样 防止子组件不更新
    if (curEssayHtml === self.essayHtml) {
      self.$refs.editdivRef.updateInput(self.essayHtml);
    }
  }
  // console.log(self.$refs.editdivRef)
  // self.$refs.tipsRef.clickTip(options.currentType)
  self.$nextTick(function () {
    //p标签只有一个span子元素且为空, 为了让计算鼠标位置更加精确
    let editor = $(self.$el).find('.editorComponent');
    let pDom = editor.children('p');
    pDom.each(function (index, element) {
      let spanDom = $(this).find('span');
      if (spanDom.length == 1 && spanDom.text().length <= 0) {
        spanDom.text(' ');
      }
    })
    if (self.$refs.tipsRef) {
      self.$refs.tipsRef.activeIndex = options.currentType
    }
    self.showEditErrorType(options.currentType)
    //获取输入框内容
    let inputText = self.$refs.editdivRef.getEditVal();
    self.$store.dispatch('setInputText', inputText);
    self.$store.dispatch('setCurrentType', options.currentType);
  });
}


/**
 * 修改语法错误
 * @param {*} fixedStartPos 
 * @param {*} fixedEndPos 
 * @param {*} correctChunk 
 * @param {*} isSendLog  是否发送日志
 */
export function selectCurrentError(fixedStartPos, fixedEndPos, correctChunk, isSendLog = true, errorId) {
  let self = this;
  this.addAction('accepted', errorId)
  let editor = $(self.$el).find('.editorComponent');
  let spanDOM = editor.find('span');

  // let rawSentsFeedback = self.rawSentsFeedback;

  // let filterErrorPostInfos = filter.filterErrorPostInfo(rawSentsFeedback, {
  //   fixedStartPos: fixedStartPos,
  //   fixedEndPos: fixedEndPos
  // });

  // let includeOperationErrPostInfo = filterErrorPostInfos.includeOperationErrPostInfo;
  // let exceptOperationErrPostInfo = filterErrorPostInfos.exceptOperationErrPostInfo;

  // self.$store.dispatch('setFixedPos', {
  //   'fixedStartPos': fixedStartPos,
  //   'fixedEndPos': fixedEndPos
  // });
  // self.$store.dispatch('setRawSentsFeedback', exceptOperationErrPostInfo);
  // self.$store.dispatch('setRawSentsIncludeFeedback', includeOperationErrPostInfo);

  //更新历史结果
  // History.essayHtml = editor.html();
  // History.fixedStartPos = fixedStartPos;
  // History.fixedEndPos = fixedEndPos;
  // History.isAccepted = true;
  // History.isIgnored = false;
  // History.rawSentsFeedback = rawSentsFeedback;

  //替换正常文本
  spanDOM.each(function () {
    let _errorId = $(this).attr('data-errId')
    // let _fixedStartPos = $(this).attr('data-fixedStartPos');
    // let _fixedEndPos = $(this).attr('data-fixedEndPos');
    if (errorId == _errorId) {
      $(this).text(correctChunk);
      $(this).attr('class', '');
    }
  })

  // self.updateTypeAndessayHtml(self.inputText, includeOperationErrPostInfo, {
  //   currentType: self.currentType,
  //   isChangeEditText: false
  // });

  self.essayHtml = editor.html();
  let inputText = self.$refs.editdivRef.getEditVal();
  self.$store.dispatch('setInputText', inputText);
  self.receiveText = inputText;
  //操作错误信息
  // Modfiy.sentsFeedback = filter.genModfiySentsFeedback(Modfiy.sentsFeedback, {
  //   fixedStartPos: fixedStartPos,
  //   fixedEndPos: fixedEndPos,
  //   isAccepted: true,
  //   isIgnored: false
  // });

  // 设置缓存
  // self.setInputTextToLocalStorage(self.$refs.editdivRef.getEditVal());
  // self.setModifyDataToLocalStorage(Modfiy.sentsFeedback);

  self.showUndo();
  self.hidePopUp();
  // 设置第一个错误详情展开
  self.$nextTick(() => {
    _.delay(() => {
      self.setFirstErrorActive();
    }, 100)
  });

  isSendLog && ydk.rlog({
    action: 'check_accept',
    type: 'rightpanel'
  })
}


/**
 *  忽略语法错误
 * @param {*} fixedStartPos 
 * @param {*} fixedEndPos 
 * @param {*} isSendLog  是否发送日志
 */
export function ignoreCurrentError(fixedStartPos, fixedEndPos, isSendLog = true, errorId) {
  let self = this;
  this.addAction('ignored', errorId)

  // let rawSentsFeedback = self.rawSentsFeedback;
  // let filterErrorPostInfos = filter.filterErrorPostInfo(rawSentsFeedback, {
  //   operation: 'ignore',
  //   fixedStartPos: fixedStartPos,
  //   fixedEndPos: fixedEndPos
  // });
  // let includeOperationErrPostInfo = filterErrorPostInfos.includeOperationErrPostInfo;
  // let exceptOperationErrPostInfo = filterErrorPostInfos.exceptOperationErrPostInfo;

  // self.$store.dispatch('setFixedPos', {
  //   'fixedStartPos': fixedStartPos,
  //   'fixedEndPos': fixedEndPos
  // });
  // self.$store.dispatch('setRawSentsFeedback', exceptOperationErrPostInfo);
  // self.$store.dispatch('setRawSentsIncludeFeedback', includeOperationErrPostInfo);

  //更新历史结果
  // History.essayHtml = editor.html();
  // History.fixedStartPos = fixedStartPos;
  // History.fixedEndPos = fixedEndPos;
  // History.isAccepted = false;
  // History.isIgnored = true;
  // History.rawSentsFeedback = rawSentsFeedback;

  let editor = $(self.$el).find('.editorComponent');
  let spanDOM = editor.find('span');
  //替换正常文本
  spanDOM.each(function () {
    let _errorId = $(this).attr('data-errId')
    if (errorId == _errorId) {
      $(this).attr('class', '');
    }
  })

  // self.updateTypeAndessayHtml(self.inputText, includeOperationErrPostInfo, {
  //   isChangeEditText: false
  // });

  self.essayHtml = editor.html();
  let inputText = self.$refs.editdivRef.getEditVal();
  self.$store.dispatch('setInputText', inputText);
  self.receiveText = inputText;
  //操作错误信息
  // Modfiy.sentsFeedback = filter.genModfiySentsFeedback(Modfiy.sentsFeedback, {
  //   fixedStartPos: fixedStartPos,
  //   fixedEndPos: fixedEndPos,
  //   isAccepted: false,
  //   isIgnored: true
  // });

  self.showUndo();
  self.hidePopUp();

  // 设置第一个错误详情展开
  self.$nextTick(() => {
    _.delay(() => {
      self.setFirstErrorActive();
    }, 200)
  });


  isSendLog && ydk.rlog({
    action: 'check_dismiss',
    type: 'rightpanel'
  })
}

export function addAction(type, errorId) {
  this.userActions.push({
    type: type,
    errorId
  })
  this.updateWithUserActions()
  this.rawSentsWithErrPos.sents.map(sent => {
    sent.errorPosInfos.map((err, i) => {
      if (err.errorId === errorId) {
        if (type === 'ignored') {
          err.isIgnored = true
        } else if (type === 'accepted') {
          err.isAccepted = true
        }
      }
    })
  })
}


export function updateWithUserActions() {
  let userActions = this.userActions
  this.data.allTypeInfos = this.data.allTypeInfos.filter(info => {
    return userActions.find(action => action.errorId === info.errorId) === undefined
  })
  if (this.currentType == 1) this.data.currentTypeInfos = this.data.allTypeInfos;
  if (this.currentType == 2) this.data.currentTypeInfos = this.errorTypeInfos;
  if (this.currentType == 3) this.data.currentTypeInfos = this.irregularTypeInfos;
}



//复制
export function copy() {
  let self = this;
  let text = self.$refs.editdivRef.getEditVal();


  // ydk.copyToClipboard({
  //   content: text
  // });

  self.Clipboard.copy(text, () => {
    self.$toast.show({
      text: '复制成功'
    });
  });

}

//显示Undo
let undoClearTimer = null;
export function showUndo() {
  let self = this;
  self.accepted = true;
  // IE11会丢失焦点
  if (self.$utils.isIE11()) {
    window.focus()
  }
  undoClearTimer && clearTimeout(undoClearTimer);
  undoClearTimer = setTimeout(function () {
    self.hideUndo();
    clearTimeout(undoClearTimer);
  }, 10 * 1000);
}

//隐藏Undo
export function hideUndo() {
  let self = this;
  self.accepted = false;
}

//监听undo组件撤销操作
export function onPrev() {
  let self = this;
  // 获取上一次用户操作
  let lastAction = this.userActions.pop()
  // 恢复上次userActionSeq中的记录
  this.rawSentsWithErrPos.sents.map(sent => {
    sent.errorPosInfos.map((err, i) => {
      if (err.errorId === lastAction.errorId) {
        if (lastAction.type === 'ignored') {
          err.isIgnored = false
        } else if (lastAction.type === 'accepted') {
          err.isAccepted = false
        }
      }
    })
  })
  // 更新错误信息
  this.data.allTypeInfos = filter.genAllErrorPostInfo(self.rawSentsFeedback);
  this.updateWithUserActions()
  let editor = $(self.$el).find('.editorComponent');
  let spanDOM = editor.find('span');
  //替换正常文本
  spanDOM.each(function () {
    let _errorId = $(this).attr('data-errId')
    if (lastAction.errorId == _errorId) {
      if (lastAction.type === 'accepted') {
        $(this).text(decodeURIComponent($(this).attr('data-orgChunk')));
      }
      $(this).attr('class', `underline ${$(this).attr('data-errortype')}`);
    }
  })
  self.essayHtml = editor.html();
  let inputText = this.$refs.editdivRef.getEditVal();
  this.$store.dispatch('setInputText', inputText);
  self.receiveText = inputText;
  // let inputText = self.history.inputText;
  // let rawSentsIncludeFeedback = self.history.rawSentsIncludeFeedback;
  // let rawSentsFeedback = self.history.rawSentsFeedback;
  // let currentType = self.history.currentType;
  // if (inputText && rawSentsFeedback && rawSentsIncludeFeedback && currentType) {
  //   self.$store.dispatch('setCurrentType', currentType);
  //   self.$store.dispatch('setInputText', inputText);
  //   self.$store.dispatch('setRawSentsFeedback', History.rawSentsFeedback);
  //   self.$store.dispatch('setRawSentsIncludeFeedback', rawSentsIncludeFeedback);
  //   self.updateTypeAndessayHtml(self.inputText, self.rawSentsIncludeFeedback, {
  //     currentType: self.currentType,
  //     isChangeEditText: false
  //   });
  //   self.essayHtml = History.essayHtml;
  //   $('.tipsArea .tipsSort > dd').eq(self.currentType - 1).addClass('active').siblings('dd').removeClass('active');
  //   self.$store.dispatch('clearHistory'); //清空历史记录
  // 修改回这个记录
  // var genModfiyData = filter.genModfiySentsFeedback(Modfiy.sentsFeedback, {
  //   fixedStartPos: History.fixedStartPos,
  //   fixedEndPos: History.fixedEndPos,
  //   isAccepted: false,
  //   isIgnored: false
  // });

  // 设置缓存
  // self.setInputTextToLocalStorage(inputText);
  // self.setModifyDataToLocalStorage(genModfiyData);

  // self.$nextTick(() => {
  //   // todo：高亮这个记录
  //   _.delay(() => {
  //     self.setErrorActiveByPosition(History.fixedStartPos, History.fixedEndPos)
  //   }, 200);
  // })

  // } else {
  //   self.$toast.show({
  //     text: '请先批改再撤回',
  //     type: 'warn'
  //   })
  // }

  self.hideUndo();

  //log
  ydk.rlog({
    action: 'check_undo'
  })

}

//显示popup
export function showPopUp(params) {
  let self = this;
  self.$refs.popupRef.show({
    left: params.left,
    top: params.top,
    orgChunk: params.orgChunk,
    correctChunk: params.correctChunk,
    fixedStartPos: params.fixedStartPos,
    fixedEndPos: params.fixedEndPos,
    errorId: params.errorId
  });

  // 记录当前选择的错误节点
  currentSelectedErrorTarget = params.target;
}

//隐藏popup
export function hidePopUp() {
  let self = this;
  self.$refs.popupRef.hide()
  // 删除当前记录的错误节点
  currentSelectedErrorTarget = null;
}


//替换正确的文本
export function onPopUpComponentCorrect(value) {
  let self = this;
  let fixedStartPos = value.fixedStartPos;
  let fixedEndPos = value.fixedEndPos;
  let correctChunk = value.correctChunk;
  let errorId = value.errorId
  self.selectCurrentError(fixedStartPos, fixedEndPos, correctChunk, false, errorId);
  self.showUndo();
  ydk.rlog({
    action: 'check_accept',
    type: 'underlinemenu'
  })
}


//忽略正确的文本
export function onPopUpComponentIgnore(value) {
  let self = this;
  let fixedStartPos = value.fixedStartPos;
  let fixedEndPos = value.fixedEndPos;
  let errorId = value.errorId
  self.ignoreCurrentError(fixedStartPos, fixedEndPos, false, errorId);
  self.showUndo();

  ydk.rlog({
    action: 'check_dismiss',
    type: 'underlinemenu'
  })
}

/**
 * 同步两边操作视图信息 
 * @param {*} fixedStartPos 
 * @param {*} fixedEndPos 
 * @param {*} type  edit=点击编辑区域错误   suggest=点击错误列表
 * @param {*} scroll  是否自动滚动，默认是
 */
export function synchronizeView(fixedStartPos, fixedEndPos, type = 'edit', scroll = true, errorId) {
  let editWrap = $('.editorWrap');
  let suggestArea = $('.suggestArea');
  let aLi = suggestArea.find('.suggestItems > li');
  let aSpan = editWrap.find('.editorComponent span.underline');

  let li_targetDom = null;
  let span_targetDom = null;
  aLi.each(function () {
    let _errorId = $(this).attr('data-errId');
    $(this).removeClass('active')
    if (errorId == _errorId) {
      li_targetDom = $(this);
      li_targetDom.addClass('active');
    }
  });
  aSpan.each(function () {
    let _errorId = $(this).attr('data-errId');
    $(this).removeClass('active');
    if (errorId == _errorId) {
      span_targetDom = $(this);
      span_targetDom.addClass('active');
    }
  })
  let targetDom = null
  if (type == 'edit') {
    targetDom = li_targetDom
  } else if (type == 'suggest') {
    targetDom = span_targetDom
  }
  scroll && targetDom && targetDom[0].scrollIntoView();
}

let translatePopupTatget = null
//初始化注册相关事件
export function initEvent() {
  let self = this;

  let editor = $(self.$el).find('.editorComponent');

  //点击编辑错误区域
  editor.off('click').on('click', function (e) {
    let target = e.target;
    let tagName = target.tagName;
    let className = target.classList;

    //选中错误的span标签
    if (tagName.toLowerCase() == 'span' && (className.contains('irregularLine') || className.contains('errorLine'))) {
      self.setPopupByTarget(target, true, e);

      //log
      ydk.rlog({
        action: 'check_undermenu'
      })
    }
    //更新光标位置
    cursorPos = select(editor[0]);

    // 去除高亮句子
    let hightlightSent = document.getElementsByClassName('hightlight')
    for (let i = 0; i < hightlightSent.length; i++) {
      hightlightSent[i].classList.remove('hightlight')
    }

  });
  // 隐藏对照翻译
  $(document)
    //   .off("click")
    .on("mousedown", function (e) {
      if (self.$refs.translatePopupRef) {
        let _con = $(".translate-main");
        if (!_con.is(e.target) && _con.has(e.target).length === 0) {
          self.$refs.translatePopupRef.hide();
          translatePopupTatget = null
        }
      }
    });
  // 双击高亮 弹出翻译
  editor
    .off('dblclick')
    .on('dblclick', function (e) {
      // 去除选中
      if (window.getSelection) {
        window.getSelection().removeAllRanges();
      } else if (document.selection) {
        document.selection.empty();
      }
      // 去除其他高亮句子
      let hightlightSent = document.getElementsByClassName('hightlight')
      for (let i = 0; i < hightlightSent.length; i++) {
        hightlightSent[i].classList.remove('hightlight')
      }
      // 给点击句子增加高亮属性
      let target = e.target.parentNode;
      translatePopupTatget = target
      let tagName = target.tagName;
      let className = target.classList;
      if (tagName.toLowerCase() == 'span' && className.contains('sentence')) {
        // console.log('tartget',target.textContent)
        target.classList.add('hightlight')
        if (navigator.onLine) {
          self.setTranslatePopup(target)
        } else {
          self.$toast.show({
            type: 'fail',
            text: '当前网络不可用，请检查您的网络设置'
          })
        }
      }
      cursorPos = select(editor[0]);
    })

  document.addEventListener('click', () => {
    self.dorpdownActive = false
    self.isShowWriteOffDetail = false
  })

  window.onbeforeunload = function (e) {
    return '';
  }
  // 滚动编辑器
  // $(".scrollArea").on('scroll', _.debounce(() => {
  //self.hideActiveAndPopup();
  // if(self.$refs.popupRef.isShow){
  // self.reCaculatePopup();
  // }
  // }, 10));

  // 窗口大小变化
  window.onresize = _.debounce(() => {
    //self.hideActiveAndPopup();
    self.reCaculatePopup();
    self.$refs.editdivRef.isShowPigaiHit = false;
  }, 10);

  // 设置焦点
  cursorPos = null
  editor[0].focus()
  // 初始化复制方法
  // self.initClipboard();
}
export function reCaculateTranslatePopup() {
  if (!translatePopupTatget) return
  let rect = translatePopupTatget.getBoundingClientRect()
  let top = rect.top + rect.height
  let bottom = rect.bottom
  // let translatePopup = $('.translate-main')[0]
  // let rect2 = translatePopup.getBoundingClientRect()
  if (top < 29 || document.body.clientHeight - rect.top < 190) {
    this.$refs.translatePopupRef.hide()
    return
  }
  window.requestAnimationFrame(() => {
    this.$refs.translatePopupRef.resetPostion(top)
  })
}

export function cleartranslatePopupTatget() {
  translatePopupTatget = null
}

export function editAreaScroll() {
  let self = this
  self.reCaculatePopup()
  self.reCaculateTranslatePopup()
}

export function setTranslatePopup(target) {
  let self = this
  let sentId = target.getAttribute('data-id')
  let rectList = target.getBoundingClientRect()
  console.log(target.getBoundingClientRect())
  // console.log({
  //   sentId,
  //   left:rectList[0].left,
  //   top: rectList[0].top + rectList[0].height
  // })
  // console.log(this.$refs)
  self.$refs.translatePopupRef.show({
    sentId,
    rawSent: target.innerText,
    left: rectList.left,
    top: rectList.top + rectList.height
  })
  ydk.rlog({
    action: 'check_translate_bys'
  })
}
// 设置第一个type的选项展开，同时高亮
export function setFirstErrorActive() {
  if (this.data.currentTypeInfos.length == 0) return
  this.$refs.suggestRef.setFirstActive()
  // let self = this;
  // if (self.data.currentTypeInfos.length == 0) return;
  // let suggestArea = $('.suggestArea');
  // let firstLi = suggestArea.find('.suggestItems > li:first-child');

  // let fixedStartPos = firstLi.attr('data-fixedStartPos');
  // let fixedEndPos = firstLi.attr('data-fixedEndPos');
  // firstLi.addClass('active').siblings('li').removeClass('active');
  // synchronizeView(fixedStartPos, fixedEndPos, 'suggest', scroll);
}

// 根据position高亮
export function setErrorActiveByPosition(fixedStartPos, fixedEndPos) {
  let self = this;
  if (self.data.currentTypeInfos.length == 0) return;
  let targetDom = null;
  let editWrap = $('.editorWrap');
  let aSpan = editWrap.find('.editorComponent span.underline');
  // 高亮左边编辑框的高亮
  aSpan.each(function () {
    let _fixedStartPos = $(this).attr('data-fixedstartpos');
    let _fixedEndPos = $(this).attr('data-fixedendpos');
    $(this).removeClass('active');
    if (fixedStartPos == _fixedStartPos && fixedEndPos == _fixedEndPos) {
      targetDom = $(this);
      targetDom.addClass('active');
    }
  })

  // 同步右边
  synchronizeView(fixedStartPos, fixedEndPos, 'edit')
}

// 初始化缓存里面的数据
export function initLocalStorageInputText() {

  let self = this;
  const inputTextFromLocalStroage = self.getInputTextFromLocalStorage();

  if (inputTextFromLocalStroage) {
    _.delay(() => {
      self.receiveText = inputTextFromLocalStroage;
      self.$store.dispatch("setInputText", inputTextFromLocalStroage); //设置默认的inputText
      self.$store.dispatch("setCurrentType", 1); //设置默认的tab
      self.sendPigaiRequest({
        showEssayFeedback: true
      });
    }, 200);
  } else {
    self.showEditEmptyGuide = true;
  }
}

export function initLocalStorageModifyData() {
  let self = this;
  var dataFromStorage = self.getModifyDataFromLocalStorage();
  if (dataFromStorage) {
    Modfiy.sentsFeedback = dataFromStorage;
  }
}

// 从缓存获取数据(新需求是，刷新页面保存当前数据，新开一个tab数据清空，因此由localstorage改成sessionstorage)
export function getInputTextFromLocalStorage() {
  return SessionStore.get('input_text');
}

// 添加数据到缓存(新需求是，刷新页面保存当前数据，新开一个tab数据清空，因此由localstorage改成sessionstorage)
export function setInputTextToLocalStorage(inputValue) {
  SessionStore.set('input_text', inputValue)
}

// 从缓存获取修改数据(新需求是，刷新页面保存当前数据，新开一个tab数据清空，因此由localstorage改成sessionstorage)
export function getModifyDataFromLocalStorage() {
  var data = SessionStore.get('modify_data');
  if (data) return JSON.parse(data);
  return null;
}

// 添加修改数据到缓存(新需求是，刷新页面保存当前数据，新开一个tab数据清空，因此由localstorage改成sessionstorage)
export function setModifyDataToLocalStorage(data) {
  if (!data) return;
  SessionStore.set('modify_data', JSON.stringify(data));
}


// 重新计算popup位置
export function reCaculatePopup() {
  let self = this;
  const popupTarget = $('.popUpWrap');
  if (popupTarget && currentSelectedErrorTarget) {
    window.requestAnimationFrame(() => {
      self.setPopupByTarget(currentSelectedErrorTarget)
    });
  }
}

/**
 * 设置popup的当前位置
 * target 所附着的target
 * sync 是否要同步右边的详情滚动
 * evt 是否有点击事件（有的话需要根据点击的位置智能计算位置，其实针对部分情况下在换行位置的。。）
 */
export function setPopupByTarget(target, sync = false, evt = null) {
  let self = this;
  let $this = $(target);
  let editor = $(self.$el).find('.editorComponent');
  // 极端条件，错误提示在换行位置，比对鼠标位置和错误提示的dom所在行的高度比对
  let rectList = target.getClientRects();
  let left = rectList[0].left || $this.offset().left;
  let top = rectList[0].top || $this.offset().top;
  let height = rectList[0].height || $this.height();

  if (evt != null) {
    // 如果有点击事件，要根据鼠标点击的最近的那个元素着点
    const x = evt.pageX;
    const y = evt.pageY;
    for (var i = 0; i < rectList.length; i = i + 1) {
      const x1 = rectList[i].left;
      const x2 = rectList[i].right;
      if (x >= x1 && x <= x2) {
        top = rectList[i].top;
        left = rectList[i].left;
      }
    }
  }

  let editorScrollTop = editor.offset().top;
  let editorScrollLeft = editor.offset().left;
  let editorScrollHeight = editor.prop('scrollHeight');

  let clinetH = $(window).height();
  let orgChunk = decodeURIComponent($this.attr('data-orgChunk'));
  let correctChunk = decodeURIComponent($this.attr('data-correctChunk'));
  let fixedStartPos = $this.attr('data-fixedStartPos');
  let fixedEndPos = $this.attr('data-fixedEndPos');
  let errorId = $this.attr('data-errid');
  $this.addClass('active').siblings('span.underline').removeClass('active')
    .parent().siblings().find('span.underline').removeClass('active');

  //判断是否超越了边界
  let showPopUpHeight = 80;
  let showPopUpLeft = left;
  let showPopUpTop = top + height;
  // 点击位置在浏览器下方，避免看不到，把popup调到上方
  if (top > clinetH - 84 || top < 0) {
    self.$refs.popupRef.hide()
    return
  }
  if ((top) >= (clinetH - showPopUpHeight - 84)) {
    showPopUpTop = top - 60;
  }

  // // 修改popup定位后，需要重新计算所在位置，根据当前页面的滚动
  // showPopUpLeft -= editorScrollLeft;
  // showPopUpTop -= editorScrollTop;

  self.showPopUp({
    left: showPopUpLeft,
    top: showPopUpTop,
    orgChunk: orgChunk,
    correctChunk: correctChunk,
    fixedStartPos: fixedStartPos,
    fixedEndPos: fixedEndPos,
    errorId: errorId,
    target,
  });

  sync && synchronizeView(fixedStartPos, fixedEndPos, 'edit', true, errorId);
}

// 隐藏高亮和错误提示框
export function hideActiveAndPopup() {
  let self = this;
  let editor = $(self.$el).find('.editorComponent');

  editor.find('span.underline').removeClass('active');
  self.hidePopUp();
}



//设置编辑框错误类型和修改建议
export function showEditErrorType(type) {
  let self = this;
  let editor = $(self.$el).find('.editorComponent');
  let spanDom = editor.find('span.underline');
  this.updateWithUserActions()
  // self.data.allTypeInfos = filter.genAllErrorPostInfo(self.rawSentsFeedback);
  // self.data.errorTypeInfos = filter.genTypeErrorPostInfo(self.rawSentsFeedback);
  // self.data.irregularTypeInfos = filter.genTypeIrregularPostInfo(self.rawSentsFeedback);
  // if (type == 1) self.data.currentTypeInfos = self.data.allTypeInfos;
  // if (type == 2) self.data.currentTypeInfos = self.errorTypeInfos;
  // if (type == 3) self.data.currentTypeInfos = self.irregularTypeInfos;

  for (let i = 0; i < spanDom.length; i++) {
    let currSpan = spanDom.eq(i);
    let classType = currSpan.attr('data-errortype');
    currSpan.removeClass('errorLine irregularLine');
    if (type == 1) {
      if (classType == 'errorLine') currSpan.addClass('errorLine');
      if (classType == 'irregularLine') currSpan.addClass('irregularLine');
    } else if (type == 2) {
      if (classType == 'errorLine') currSpan.addClass('errorLine');
    } else if (type == 3) {
      if (classType == 'irregularLine') currSpan.addClass('irregularLine');
    }
  }

  // 设置第一个错误详情展开
  self.$nextTick(() => {
    _.delay(() => {
      self.setFirstErrorActive();
    }, 200)
  });

}

//清除错误类型提示
export function clearCurrentError() {
  let self = this;
  let editor = $(self.$el).find('.editorComponent');
  let spanDom = editor.find('span.underline');
  let spanActiveDom = editor.find('span.active');

  //更新光标
  cursorPos = select(editor[0]);
  let end = cursorPos.end;


  spanDom.each(function () {
    let _fixedStartPos = parseInt($(this).attr('data-fixedStartPos'));
    let _fixedEndPos = parseInt($(this).attr('data-fixedEndPos')) + 1;
    if (end >= _fixedStartPos && end <= _fixedEndPos) {
      $(this).removeClass('errorLine irregularLine');
    }
  });

  self.hidePopUp();
}

//关闭编辑区域提示
export function closeBubble_edit() {
  this.showEditBubbleTips = false;
  Store.set('is_click_bubble_edit', true);
}

// 点击返回官网按钮
export function backToPigaiOfficial() {
  location.href = 'http://pigai_test.inner.youdao.com/index.html';
  // ydk.rlog({
  //   action : 'click_backToPigaiOfficial'
  // });
}

/**
 * 复制功能
 */
export function initClipboard() {
  var self = this;
  self.Clipboard = {};
  var textArea,
    copy;

  //创建文本元素
  function createTextArea(text) {
    textArea = document.createElement('textArea');
    textArea.value = text;
    document.body.appendChild(textArea);
  }
  //选择内容
  function selectText() {
    var range,
      selection;

    textArea.select();
  }

  //复制到剪贴板
  function copyToClipboard(cb) {
    try {
      if (document.execCommand("Copy")) {
        cb();
      } else {
        self.$toast.show({
          text: '复制失败，请手动复制'
        })
      }
    } catch (err) {
      self.$toast.show({
        text: '复制失败，请手动复制'
      })
    }
    document.body.removeChild(textArea);
  }

  self.Clipboard.copy = function (text, cb) {
    createTextArea(text);
    selectText();
    copyToClipboard(cb);
  };
}

// 清除选中的target
export function onAutoClearSelectedErrorTarget() {
  currentSelectedErrorTarget = null;
}


export function getHistory() {
  let self = this
  let params = {}
  if (this.uniqueKey !== '') {
    params.uniqueKey = this.uniqueKey
  }
  api.getHistory(params).then((res) => {
    let result = res.data
    // 非草稿展示之前的批改结果
    if (result.code === 0) {
      if (result.data.essayFeedback && result.data.essayFeedback.sentsFeedback) {
        self.isPigaiStartted = true
        let rawSentsFeedback = filter.genRawSentsFeedback(result.data.essayFeedback.sentsFeedback);
        self.$store.dispatch('setFeedbackData', result.data.essayFeedback.sentsFeedback)
        self.$store.dispatch('setRawSentsFeedback', rawSentsFeedback);
        // self.$store.dispatch('setRawSentsIncludeFeedback', rawSentsFeedback);
        self.updateTypeAndessayHtml(result.data.rawEssay, self.rawSentsFeedback, {
          currentType: self.currentType
        });

        //保留原始段落信息
        self.rawSentsWithErrPos = filter.genModfiySentsFeedback(result.data.essayFeedback.sentsFeedback);

        self.$nextTick(() => {
          self.$refs.editdivRef.keepLastIndex()
        })
        //   //设置光标位置
        // console.log(cursorPos)

        //   let editor = $(self.$el).find('.editorComponent');
        //   if (cursorPos) {
        //     select(editor[0], cursorPos);
        //   }
        // });
        //设置编辑区域提示
        if (self.rawSentsFeedback.length > 0 && !Store.get('is_click_bubble_edit')) {
          self.showEditBubbleTips = true;
        }
        //允许点击翻译对照按钮
        this.isShowCompare = true
        this.userActions = []
        this.$store.dispatch('setUniqueKey', result.data.uniqueKey)
      }
      this.$store.dispatch('setTitle', res.data.data.title || '未知标题-From移动端');
      this.$store.dispatch('setInputText', res.data.data.rawEssay);
      this.receiveText = res.data.data.rawEssay
      this.$refs.editdivRef.innerText = res.data.data.rawEssay
      // this.manualCorrecting()

    }
  })

}

// 打开插件下载页面
export function toDownload() {
  window.open('../download.html')
}

// 打开意见反馈页面
export function toFeedback() {
  window.open('../feedback.html')
}

// 获取用户信息
export function getUserInfo() {
  api.getUserNickname().then(res => {
    // this.$store.dispatch('setUsername', res.data.nickname);
    // this.username = res.data.nickname
    if (res.data.error === 0) {
      this.$store.dispatch('setUsername', res.data.nickname)
    } else {
      const loginURL = 'https://c.youdao.com/common-login-web/index.html?redirect_url='
      window.location.href = loginURL + encodeURIComponent(document.URL)
    }
  })
}

// 返回批改历史页面
export function backToHome() {
  if (!navigator.onLine) {
    this.$toast.show({
      type: 'fail',
      text: '保存失败，请稍后重试。'
    })
  }
  this.InputcleartTimer && clearTimeout(this.InputcleartTimer);
  if (!this.isSendingPigaiRequest) {
    this.sendPigaiRequest({
      showEssayFeedback: false,
    });
  }
  this.isBackHomeClicked = true
  if (this.isSendingPigaiRequest === false && this.isBackHomeClicked && this.errorType !== 5) {
    this.$router.push({
      path: "home",
      query: {
        from: 'detail'
      }
    });
  }
}

// 退出登录
export function logout() {
  api.logout().then(() => {
    sessionStorage.clear()
    window.location.href = '../index.html'
  })
}

// 下拉
export function dorpdown() {
  this.dorpdownActive = !this.dorpdownActive
}

// updateText
export function updateText(sentenceId) {
  // 更新内容
  let inputText = this.$refs.editdivRef.getEditVal();
  let editor = $(this.$el).find('.editorComponent');
  this.essayHtml = editor.html();
  this.$store.dispatch('setInputText', inputText);
  this.receiveText = inputText;
  // 更新右侧建议，删除不存在的建议
  this.data.allTypeInfos = this.data.allTypeInfos.filter(info => {
    let reg = new RegExp('^' + sentenceId)
    return !info.errorId.match(reg)
  })
  if (this.currentType == 1) this.data.currentTypeInfos = this.data.allTypeInfos;
  if (this.currentType == 2) this.data.currentTypeInfos = this.errorTypeInfos;
  if (this.currentType == 3) this.data.currentTypeInfos = this.irregularTypeInfos;
  this.$nextTick(() => {
    this.setFirstErrorActive();
  });
  if (cursorPos) {
    select(editor[0], cursorPos);
  }
  translatePopupTatget = null
}

export function compareTranslate() {
  let text = ''
  let finished = false
  let startIndex = 0
  let temp = {}
  if (this.inputText.length <= 0) {
    return
  } else if (this.inputText.length <= 5000) {
    text = this.inputText
    finished = true
  } else {
    text = this.inputText.substring(startIndex, startIndex + 5000)
  }
  translate(text).then(res => {
    // 取出最后一个
    this.comparingTranslateResult = res.data.translateResult
    this.translateHtml = generateEssayHtml.genTranslateHtml(this.comparingTranslateResult)
    // 如果没结束就再发一次
    if (!finished) {
      temp = res.data.translateResult[res.data.translateResult.length - 1].pop()
      startIndex = text.lastIndexOf(temp.src)
      if (this.inputText.length <= startIndex + 5000) {
        text = this.inputText.substring(startIndex)
        finished = true
      } else {
        text = this.inputText.substring(startIndex, startIndex + 5000)
      }
      translate(text).then(res => {
        this.comparingTranslateResult[this.comparingTranslateResult.length - 1] = this.comparingTranslateResult[this.comparingTranslateResult.length - 1].concat(res.data.translateResult[0])
        this.comparingTranslateResult = this.comparingTranslateResult.concat(res.data.translateResult.slice(1))
        this.translateHtml = generateEssayHtml.genTranslateHtml(this.comparingTranslateResult)
        // 最后可能剩下的再发一次
        if (!finished) {
          console.log(res.data.translateResult[res.data.translateResult.length - 1])
          temp = res.data.translateResult[res.data.translateResult.length - 1].pop()
          startIndex = text.lastIndexOf(temp.src) + startIndex
          if (this.inputText.length <= startIndex + 5000) {
            text = text = this.inputText.substring(startIndex)
            finished = true
          } else {
            text = this.inputText.substring(startIndex, startIndex + 5000)
          }
          translate(text).then(res => {
            this.comparingTranslateResult[this.comparingTranslateResult.length - 1] = this.comparingTranslateResult[this.comparingTranslateResult.length - 1].concat(res.data.translateResult[0])
            this.comparingTranslateResult = this.comparingTranslateResult.concat(res.data.translateResult.slice(1))
            this.translateHtml = generateEssayHtml.genTranslateHtml(this.comparingTranslateResult)
          })
        }
      })
    }
  })
  // else {
  //   this.comparingTranslateResult = res.data.translateResult
  //   this.translateHtml = generateEssayHtml.genTranslateHtml(this.comparingTranslateResult)
  // }
  ydk.rlog({
    action: 'check_translate'
  })
}

export function clickGuide() {
  Store.set('is_click_guide', true)
  this.showGuide = false
  // let editor = $(this.$el).find('.editorComponent');
  // editor[0].focus()
  this.$refs.editdivRef.keepLastIndex()
}

export function writeOff(){
  this.isShowWriteOffDetail = true
}