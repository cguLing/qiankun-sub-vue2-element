/**
 * 简易的虚拟dom
 */

export default {
  /**
     * nodes => html
     */
  render (node) {
    return Array.isArray(node)
      ? node.map(v => this.renderNode(v)).join('')
      : this.renderNode(node)
  },
  /**
     * node => html
     */
  renderNode (node) {
    let res = `<${node.type} ${this.genNodeAttr(node.attr)}>`
    if (Array.isArray(node.children)) {
      res += node.children.map(v => this.renderNode(v)).join('')
    } else {
      res += `${node.children}`
    }
    return res + `</${node.type}>`
  },
  /**
     * 生成 node的属性
     */
  genNodeAttr (attr) {
    return attr
      ? Object.keys(attr)
        .map(k => `${k}="${attr[k]}"`)
        .join(' ')
      : ''
  },
  /**
     * 生成node
     * @param {String} type 标签名
     * @param {Array|String} children 子节点
     * @param {Object} 节点属性
     */
  createNode (type, children, attr) {
    return {
      type: type,
      attr,
      children: children
    }
  }
}
