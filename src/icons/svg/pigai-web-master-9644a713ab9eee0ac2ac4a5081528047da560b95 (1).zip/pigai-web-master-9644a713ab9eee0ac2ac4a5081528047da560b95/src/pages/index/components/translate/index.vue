<template>
  <transition name="slide-fade">
    <div id="translateWrap">
      <div class="flexBox">
        <div class="source scroll_wrap">
          <div class="input" id="js_fanyi_input">
            <template v-for="(item, parentIndex) in data.result.translateResult">
              <span
                class="src"
                v-for="(item, index) in item"
                :key="parentIndex+'-'+index"
                :data-group="parentIndex+'-'+index"
              >{{item['src']}}</span>
              <br />
            </template>
          </div>
        </div>
        <div class="target scroll_wrap">
          <div class="output" id="js_fanyi_output">
            <template v-if="isMaxLimitnNums">
              <div class="errorTips">
                <i class="icon icon-warn"></i>
                <span>对不起，实在太长啦，让我喘口气</span>
              </div>
            </template>
            <template v-else>
              <template v-if="!data.result.error_msg">
                <div class="resultOutput">
                  <template v-if="showStepTrans">
                    <ul v-for="(row , i) in data.result.translateResult" :key="row+'-'+i">
                      <li v-if="i < 1 && $options.filters.isString(row)">
                        <p class="src" :data-group="i+'-'+0">{{row}}</p>
                      </li>
                      <li v-else v-for="(ret , j) in row" :key="ret+'-'+j">
                        <p
                          class="src"
                          :data-section="i"
                          :data-sentence="j"
                          :data-group="i+'-'+j"
                        >{{ret.src}}</p>
                        <p
                          class="tgt"
                          :data-section="i"
                          :data-sentence="j"
                          :data-group="i+'-'+j"
                        >{{ret.tgt}}</p>
                      </li>
                    </ul>
                  </template>
                  <template v-if="!showStepTrans">
                    <p
                      v-for="(row , i) in data.result.translateResult"
                      :data-section="i"
                      :key="row+'-'+i"
                      class="tgt"
                    >
                      <span v-if="i < 1 && $options.filters.isString(row)">{{row}}</span>
                      <span
                        class="tgt"
                        :data-section="i"
                        :data-sentence="j"
                        :data-group="i+'-'+j"
                        :key="i+'-'+j"
                        v-else
                        v-for="(ret , j) in row"
                      >{{ret.tgt}}</span>
                    </p>
                  </template>
                </div>
              </template>
              <template v-if="data.result.error_msg">
                <div class="errorTips">
                  <i class="icon icon-warn"></i>
                  <span>{{data.result.error_msg}}</span>
                </div>
              </template>
            </template>
          </div>
        </div>
      </div>
      <div class="transComparison" @click="hideTrans">
        <span>关闭对照</span>
        <i class="icon-right icon icon-ic_triangle"></i>
      </div>
    </div>
  </transition>
</template>

<script>
import * as methods from './methods/index';
import Config from 'config';
export default {
  props: {
    inputText: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      //输入信息
      source: {
        inputText: this.inputText,
        from: 'en',
        to: 'zh-CHS'
      },
      //输出信息
      data: {
        result: {}
      },
      nums: 0, //当前的字数
      maxLimitnNums: 5000, //最大翻译字数
      isMaxLimitnNums: false, //是否超出字数限制
      showStepTrans: false //译文是否对照
    };
  },
  methods: methods,
  created() {
    this.$loading.show();
    if (Config.platform == 'win') {
      this.search();
    }
  },
  mounted() {
    let self = this;
    self.highlight();
  }
};
</script>

<style lang="scss" scoped>
@import "./index";
</style>