<template>
  <div class="undo-wrap">
    <a href="javascript:;" @click="undo">点击撤回</a>
    <!-- &nbsp;或&nbsp;直接 {{isMac() ? 'control+z':'alt+z'}} 进行撤回 -->
    <i
      class="icon icon-close"
      @click="hideUndo"
    ></i>
  </div>
</template>

<script>
import * as keypresser from "@/modules/keypresser/index";
export default {
  methods: {
    hideUndo() {
      this.$parent.hideUndo();
    },
    undo() {
      this.$emit("undo");
    },

    isMac() {
      /**
       * 判断是否Mac
       */
      var appVersion = window.navigator.appVersion.toLowerCase() || "";
      return /mac/i.test(appVersion);
    },
  },
  // mounted() {
  //   let self = this;
  //   //监听键盘
  //   if (this.isMac()) {
  //     keypresser.watch("CTRL+Z", function (keys, e) {
  //       e.preventDefault();
  //       self.$emit("undo");
  //     });
  //   } else {
  //     keypresser.watch("ALT+Z", function (keys, e) {
  //       e.preventDefault();
  //       self.$emit("undo");
  //     });
  //   }
  // },
};
</script>

<style scoped lang="scss">
@import "./index";
</style>