import $Http from '@/service/httpTranslate';
// 加密网络翻译
// 加密文档：https://gitlab.corp.youdao.com/translator-dev/smtfront/blob/master/docs/API.md
export function cryptoNet(params) {
  let url = '/translate';
  return $Http({
    method: 'POST',
    url,
    data: {
      i: params.data.keyword, // 翻译文本
      from: params.data.from, // 原语言
      to: params.data.to, // 目标语言
      client: 'pigaiweb', // 用于身份验证，和私钥配对
      salt: new Date().getTime(), // 随机数
      version: '2.0', // 翻译格式版本，2.1版本可以实现句子对齐
      keyfrom: 'pigai.web', // 额外参数
    },
  })
}
