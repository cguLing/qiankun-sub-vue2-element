<template>
  <div id="index-page">
    <div class="user-guide" v-if="showGuide">
      <div class="guideContent">
        <div class="guideBtn" @click="clickGuide">知道了</div>
      </div>
    </div>
    <!--头部logo栏目-->
    <div class="header-container">
      <div class="back-container" @click="backToHome">
        <i class="back"></i>
        <div class="back-text">返回</div>
      </div>
      <div class="info-container">
        <!-- <i class="download" @click="toDownload"></i>
        <span @click="toDownload">下载</span> -->
        <i class="personal" @click.stop="dorpdown"></i>
        <span class="user" @click.stop="dorpdown">{{ username }}</span>
        <i class="arrow-down" @click.stop="dorpdown"></i>
        <div class="dropdown" v-show="dorpdownActive">
          <div class="dropdown-item" @click="backToHome">批改记录</div>
          <div class="dropdown-item" @click="logout">退出登录</div>
          <div class="dropdown-item" @click.stop="writeOff">账户注销</div>
          <div
            class="writeOffDetail"
            v-show="isShowWriteOffDetail"
            @click.stop=""
          >
            <p>您可以通过发送注销邮件至客服邮箱</p>
            <p>
              <a href="mailto:youdaowriting@corp.youdao.com"
                >youdaowriting@corp.youdao.com</a
              >
            </p>
            <p>以完成账户的注销。</p>
          </div>
        </div>
      </div>
    </div>
    <div class="wrap">
      <!-- 临时存放的标签 -->
      <p
        class="deskdictReceiveText"
        style="display: none"
        v-html="receiveText"
      ></p>

      <!-- 批改区域 -->
      <template>
        <EditDiv
          ref="editdivRef"
          :canEdit="canEdit"
          :maxLimitnNum="maxLimitnNum"
          :receiveText="receiveText"
          :html="essayHtml"
          :isModfiy="isModfiy"
          :translateHtml="translateHtml"
          :isShowCompare="isShowCompare"
          @inputFocus="onEdiComponentFocus"
          @submit="manualCorrecting"
          @editinput="onEditComponentInput"
          @titleinput="onTitleInput"
          @clear="clearResult"
          @compareTranslate="compareTranslate"
          @editScroll="editAreaScroll"
        ></EditDiv>
      </template>

      <!-- 修改操作 -->
      <template>
        <PopUp
          ref="popupRef"
          @correctAction="onPopUpComponentCorrect"
          @ignoreAction="onPopUpComponentIgnore"
          @clear="onAutoClearSelectedErrorTarget"
        ></PopUp>
      </template>

      <!-- 修改建议 -->

      <template>
        <!-- 避免无网提示图片不显示 -->
        <img src="./images/pic_language_wrong.png" v-show="false" />
        <div class="right-part" v-if="isloading">
          <div class="loading">
            <div class="loading-pic"></div>
            <div class="loading-msg">正在批改中...</div>
          </div>
        </div>
        <div class="right-part" v-else-if="errorType !== 0">
          <div class="wrong">
            <div class="pic"></div>
            <div v-if="errorType === 2" class="msg">
              抱歉，我们的批改长度目前是{{ maxLimitnNum }}字符以内
            </div>
            <div v-else-if="errorType === 3" class="msg">抱歉，文章太短</div>
            <div v-else-if="errorType === 4" class="msg">
              抱歉，我们暂时只支持英文批改
            </div>
            <div v-else-if="errorType === 1" class="msg">
              抱歉，遇到一点问题，请稍候重试
            </div>
            <div v-else-if="errorType === 5" class="msg">
              当前网络不可用，请检查您的网络设置
            </div>
          </div>
        </div>
        <div class="right-part" v-else-if="!isPigaiStartted">
          <div class="start">
            <div class="emptyImage"></div>
            <div class="emptyTitle">智能识别47种错误类型</div>
            <div class="emptySummary">
              包含拼写<i>|</i>语法<i>|</i>标点符号<i>|</i>词级润色等
            </div>
          </div>
        </div>
        <div class="right-part" v-else-if="data.allTypeInfos.length === 0">
          <div class="allright">
            <div class="pic"></div>
            <div class="msg">您的写作一点错误没有~</div>
          </div>
        </div>
        <template v-else>
          <!-- 展示文章错误 -->
          <Suggest
            ref="suggestRef"
            :currentTypeInfos="data.currentTypeInfos"
            @selectError="selectCurrentError"
            @ignoreError="ignoreCurrentError"
            @sync="synchronizeView"
          ></Suggest>
          <!-- 错误类型 -->
          <Tips
            ref="tipsRef"
            :allTypeInfos="data.allTypeInfos"
            :errorTypeInfos="errorTypeInfos"
            :irregularTypeInfos="irregularTypeInfos"
            @showEditErrorType="showEditErrorType"
          ></Tips>
        </template>
      </template>
      <template>
        <TranslatePopup
          ref="translatePopupRef"
          @update="updateText"
          @clear="cleartranslatePopupTatget"
        ></TranslatePopup>
      </template>
      <!-- 撤销 -->
      <template v-if="accepted == true">
        <Undo ref="undoRef" @undo="onPrev"></Undo>
      </template>
    </div>
    <div class="uesr_feedback" @click="toFeedback">
      <i class="feedback_icon"></i>
      <div>意见反馈</div>
    </div>
  </div>
</template>

<script>
import * as methods from "./methods/index.js";
import * as filters from "./filters.js";
import PopUp from "./components/popup";
import EditEmptyGuide from "./components/editDiv/guide";
import EditDiv from "./components/editDiv";
import Tips from "./components/tips";
import Suggest from "./components/suggest";
import TranslatePopup from "./components/translatePopup";
// import Config from "config";
import { mapState } from "vuex";
import LocalStore from "commons/localStorage.js";
import Store from "commons/sessionStorage.js";

//懒加载模块
const Undo = () => import(/* webpackChunkName: "Undo" */ "./components/undo");
const BubbleTips = () =>
  import(/* webpackChunkName: "BubbleTips" */ "./components/bubbleTips");
// const TranslatePopup = () =>
//   import(
//     /* webpackChunkName: "TranslatePopup" */ "./components/translatePopup"
//   );
export default {
  data() {
    return {
      canEdit: true, //输入框是否能编辑
      receiveText: "", //外部接受的文本
      inputing: false, //是否正在输入中
      isloading: false, //正在请求批改接口
      accepted: false, //用户是否接受批改
      data: {
        currentTypeInfos: [], //当前选中的类型
        allTypeInfos: [], //全部类型
        errorTypeInfos: [], //错误类型
        irregularTypeInfos: [], //不规范类型
      },
      errorMsg: "", //服务器错误信息
      maxLimitnNum: 10000, //最大限制字符
      essayHtml: "", //生成的html
      showGuide: !LocalStore.get("is_click_guide"), //新手指引
      // showGuide:true,
      showEditEmptyGuide: false, // 页面空数据提示
      showEditBubbleTips: false, //编辑区域提示
      showTransBubbleTips: false, //翻译对照提示
      isModfiy: false, //首次进入是否要批改
      dorpdownActive: false, //下拉默认不显示
      userActions: [], //用户进行的忽略和替换操作
      isPigaiStartted: false, //是否批改过
      isShowCompare: false, // 是否显示对照翻译
      comparingTranslateResult: "", //对照翻译的结果
      translateHtml: "", //对照翻译生成的HTML
      errorType: 0, //服务器返回的错误类型
      rawSentsWithErrPos: {
        sents: [],
      }, //原始的句子和错误位置
      InputcleartTimer: null, //自动批改的计时器
      isSendingPigaiRequest: false, //是否正在发送批改请求
      isBackHomeClicked: false, //用户是否点了返回按钮
      isShowWriteOffDetail: false,
    };
  },
  beforeCreate() {
    this.$utils.checkLogin();
  },
  created() {
    $("#loading").remove();
    console.log("init");
    this.clearResult();
    // 获取用户名，获取历史
    // this.getUserInfo()
    if (this.uniqueKey === "") {
      let uniquekey = Store.get("uniqueKey");
      if (uniquekey) {
        this.$store.dispatch("setUniqueKey", uniquekey);
      }
    }
    if (this.uniqueKey !== "") {
      Store.set("uniqueKey", this.uniqueKey);
      this.getHistory();
    }

    if (this.username === "") {
      let username = Store.get("username");
      if (username) {
        this.$store.dispatch("setUsername", username);
      } else {
        this.getUserInfo();
      }
    }
  },
  methods: methods,
  filters: filters,
  computed: {
    ...mapState({
      title: (state) => state.essay.title, // 文章标题
      inputText: (state) => state.essay.inputText, // 输入框文本内容
      currentType: (state) => state.essay.currentType, //当前选择的类型， 1： 全部， 2：错误， 3：不规范
      rawSentsFeedback: (state) => state.essay.rawSentsFeedback, //服务器返回的原始错误数据
      rawSentsIncludeFeedback: (state) => state.essay.rawSentsIncludeFeedback, //保留用户操作的错误数据
      history: (state) => state.essay.history, //历史记录,
      uniqueKey: (state) => state.global.uniqueKey, // 标识批改的key
      username: (state) => state.global.username, //用户昵称
    }),
    errorTypeInfos: function () {
      return this.data.allTypeInfos.filter(
        (info) => info.type === "typo" || info.type === "grammar"
      );
    },
    irregularTypeInfos: function () {
      return this.data.allTypeInfos.filter((info) => info.type === "refactor");
    },
    userActionSeq: function () {
      let errorSents = this.rawSentsWithErrPos.sents.filter(
        (sent) => sent.errorPosInfos.length !== 0
      );
      errorSents.map((sent) => {
        sent.errorPosInfos.map((err) => {
          return {
            isAccepted: err.isAccepted,
            isIgnored: err.isIgnored,
          };
        });
      });
      return { sents: errorSents };
    },
  },
  components: {
    Undo,
    PopUp,
    EditDiv,
    BubbleTips,
    EditEmptyGuide,
    Tips,
    Suggest,
    TranslatePopup,
  },
  mounted() {
    let self = this;
    //初始化事件
    self.initEvent();
    // console.log("mounted");
    // ydk.rlog({
    //   show: "page_check",
    // });
  },
  destroyed() {
    window.onbeforeunload = null;
  },
  watch: {
    // 保证只有在批改请求发送完成之后才会返回
    isSendingPigaiRequest: function (val) {
      if (val === false && this.isBackHomeClicked) {
        if (this.errorType !== 5) {
          this.$router.push({
            path: "home",
            query: {
              from: "detail",
            },
          });
        } else {
          this.$toast.show({
            type: "fail",
            text: "保存失败，请稍后重试。",
          });
        }
      }
    },
  },
  // beforeRouteEnter(to, from, next) {
  //   // ydk.rlog({
  //   //   show: "page_check",
  //   // });
  //   // setTimeout(()=>{
  //   //   next()
  //   // },100)
  //   next((vm) => {
  //     ydk.rlog({
  //       show: "page_check",
  //     });
  //   });
  // },
};
</script>

<style lang="scss">
@import "./index.scss";
</style>