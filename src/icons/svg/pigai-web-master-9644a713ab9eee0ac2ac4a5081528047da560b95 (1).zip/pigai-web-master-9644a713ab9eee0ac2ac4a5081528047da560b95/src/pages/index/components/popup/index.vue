<template>
  <transition>
    <div class="popUpWrap" v-show="isShow">
      <ul>
        <li
          class="correctInfo"
          @click="correctAction"
        >{{correctChunk?('替换为'+correctChunk):('删除掉'+orgChunk)}}</li>
        <li @click="ignoreAction">忽略</li>
      </ul>
    </div>
  </transition>
</template>

<script>
import * as methods from "./methods";
export default {
  name: "PopUp",
  data() {
    return {
      isShow: false,
      orgChunk: "",
      correctChunk: "",
      fixedStartPos: "",
      fixedEndPos: "",
      errorId: "",
    };
  },
  methods: methods,
  mounted() {
    let self = this;
    $(document)
      // .off("click")
      .on("click", function (e) {
        var _con = $(".popUpWrap ,.editorComponent span.underline");
        var _con1 = $(".suggestItems >li");
        if (!_con.is(e.target) && _con.has(e.target).length === 0) {
          if (!_con1.is(e.target) && _con1.has(e.target).length === 0) {
            $(".editorComponent span.underline").removeClass("active");
          }
          self.hide();
          self.$emit("clear");
        }
      });
  },
};
</script>
<style lang="scss" scoped>
@import "./index";
</style>