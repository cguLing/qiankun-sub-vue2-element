import htmlToText from 'html-to-text'
import xss from 'xss'
import Utils from '../../../../commons/utils';


export const editorInput = function (e) {
  e.preventDefault();
  let self = this;
  if (self.isIE11) return; // ie11不能检测input事件
  let editDom = self.$refs.editorRef;
  let inputText = editDom.innerHTML;

  //html2text
  inputText = htmlToText.fromString(inputText, {
    isInPre: true, //保留所有空格
    preserveNewlines: true, //如果为true，则不会删除这些换行符\n。
    wordwrap: null, // 遇换行符换行 不根据字数换行
    singleNewLineParagraphs: true, // 一行
  });

  //过滤html
  inputText = filterHTML(inputText);

  //同步当前字符
  self.currentNum = inputText.length;

  this.$store.dispatch('setInputText', inputText);
  self.$emit("editinput", inputText);
}

export const titleInput = function (e) {
  e.preventDefault();
  let self = this;
  if (self.isIE11) return; // ie11不能检测input事件
  let editDom = self.$refs.editorRef;
  let inputText = editDom.innerHTML;

  //html2text
  inputText = htmlToText.fromString(inputText, {
    isInPre: true, //保留所有空格
    preserveNewlines: true, //如果为true，则不会删除这些换行符\n。
    wordwrap: null, // 遇换行符换行 不根据字数换行
    singleNewLineParagraphs: true, // 一行
  });

  //过滤html
  inputText = filterHTML(inputText);

  //同步当前字符
  self.currentNum = inputText.length;

  self.$emit("titleinput", inputText);
}

//过滤html, 防止xss攻击、 去掉无法识别的字符
function filterHTML(str, options = {}) {
  var filterUnicodeStr = Utils.filterUcode(str);
  return xss(filterUnicodeStr, options);
}

export const titleKeyup = function (e) {
  // 回车不保存
  if (e.keyCode == 13) return;
  let self = this;
  if (!self.isIE11) return;

  let editDom = self.$refs.editorRef;
  let inputText = editDom.innerHTML;

  //html2text
  inputText = htmlToText.fromString(inputText, {
    isInPre: true, //保留所有空格
    preserveNewlines: true, //如果为true，则不会删除这些换行符\n。
    wordwrap: null, // 遇换行符换行 不根据字数换行
    singleNewLineParagraphs: true // 一行
  });

  //过滤html
  inputText = filterHTML(inputText);

  //同步当前字符
  self.currentNum = inputText.length;

  self.$emit("titleinput", inputText);
}

export const editorKeydown = function (event) {
  // window.document.execCommand('insertHTML', false, "\n");
  document.execCommand('insertLineBreak', false, null);
  // event.preventDefault();
  // console.log('down')
}

export const editorKeyup = function (event) {
  let self = this;
  if (!self.isIE11) return;
  console.log('up')
  let editDom = self.$refs.editorRef;
  let inputText = editDom.innerHTML;

  //html2text
  inputText = htmlToText.fromString(inputText, {
    isInPre: true, //保留所有空格
    preserveNewlines: true, //如果为true，则不会删除这些换行符\n。
    wordwrap: null, // 遇换行符换行 不根据字数换行
    singleNewLineParagraphs: true // 一行
  });

  //过滤html
  inputText = filterHTML(inputText);

  //同步当前字符
  self.currentNum = inputText.length;

  self.$emit("editinput", inputText);
}


export const editorFocus = function () {
  let self = this;
  // 通知父节点删除指导气泡
  self.$emit("inputFocus");
  _.delay(() => {
    self.focus = true;
  }, 2000);

}

export const editorBlur = function () {
  let self = this;
  self.focus = false;
  if (self.currentNum <= 0) {
    self.innerText = ''; //避免没删除干净
  }
}

export const editorPaste = function (e) {
  e.preventDefault();
  console.log('paste')
  var text = null,
    textRange, sel;
  if (window.clipboardData) {
    // IE
    text = window.clipboardData.getData('text');
  } else {
    text = (e.originalEvent || e).clipboardData.getData('text/plain');
  }
  if (document.body.createTextRange) {
    if (document.selection) {
      textRange = document.selection.createRange();
    } else if (window.getSelection) {
      sel = window.getSelection();
      var range = sel.getRangeAt(0);

      // 创建临时元素，使得TextRange可以移动到正确的位置
      var tempEl = document.createElement("span");
      tempEl.innerHTML = "&#FEFF;";
      range.deleteContents();
      range.insertNode(tempEl);
      textRange = document.body.createTextRange();
      textRange.moveToElementText(tempEl);
      tempEl.parentNode.removeChild(tempEl);
    }
    textRange.text = text;
    textRange.collapse(false);
    textRange.select();
  } else {
    // Chrome之类浏览器
    document.execCommand("insertText", false, text);
  }
  // console.log('pastetext', text)
  if (!text) {
    this.isShowEmptyPrompt = true
    setTimeout(() => {
      this.isShowEmptyPrompt = false
    }, 3000)
  }
  // this.$emit('submit')
}

//获取输入框内容
export const getEditVal = function () {
  let self = this;
  let editDom = self.$refs.editorRef;
  let inputText = editDom.innerHTML;
  //html2text
  inputText = htmlToText.fromString(inputText, {
    isInPre: true, //保留所有空格
    preserveNewlines: true, //如果为true，则不会删除这些换行符\n。
    wordwrap: null, // 遇换行符换行 不根据字数换行
    singleNewLineParagraphs: true // 一行
  });

  //过滤html
  inputText = filterHTML(inputText);

  return inputText;
}

//更新输入框内容
export const updateInput = function (html) {
  let self = this;
  self.innerText = html;
  $(self.$el).find('.editorComponent').html(self.innerText);
}

//开启调试模式
let clickTime = 0;
let debug = false;
export const toggleDebug = function () {
  const flag = 5;
  const self = this;
  if (++clickTime < flag) return;
  clickTime = 0;
  debug = !debug;
  self.$store.dispatch('setDebugger', debug);
  self.$toast.show({
    text: 'DEBUG模式' + (debug ? '开启' : '关闭') + '成功',
    time: 1.5,
    type: 'success'
  });
}


//设置光标到最后
export const keepLastIndex = function () {
  let self = this;
  let obj = $(self.$el).find('.editorComponent');
  obj.focus();
  var range = window.getSelection(); //创建range
  range.selectAllChildren(obj[0]); //range 选择obj下所有子内容
  range.collapseToEnd(); //光标移至最后
}


// 对照翻译
export const compareTranslate = function () {
  if (this.comparing === false) {
    if (!navigator.onLine) {
      this.$toast.show({
        type: 'fail',
        text: '当前网络不可用，请检查您的网络设置'
      })
      return
    }
    this.$emit('compareTranslate')
  }
  this.comparing = !this.comparing
}


// 提交批改
export const submit = function () {
  // this.isShowPigaiHit = false
  this.$emit('submit')
}

// export const showcontextmenu = function(e){
//   e.preventDefault()
// }

// 清空
export const clear = function () {
  this.$store.dispatch('setUniqueKey', '')
  this.$emit('clear')
}

export const isMac = function () {
  /**
   * 判断是否Mac
   */
  var appVersion = window.navigator.appVersion.toLowerCase() || "";
  return /mac/i.test(appVersion);
}

let showPigaiHitTimer = null
export const showPigaiHit = function () {
  showPigaiHitTimer && clearTimeout(showPigaiHitTimer)
  showPigaiHitTimer = setTimeout(() => {
    this.isShowPigaiHit = true
  }, 2000)
}

export const hidePigaiHit = function () {
  showPigaiHitTimer && clearTimeout(showPigaiHitTimer)
  this.isShowPigaiHit = false
}

export const scroll = function () {
  this.$emit('editScroll')
}

// 复制处理,避免换行符丢失
export const editorCopy = function (e) {
  let self = this;
  let clipboardData = (e.clipboardData || window.clipboardData);
  if (self.isIE11) {
    clipboardData.setData('Text', window.getSelection().toString());
  } else {
    clipboardData.setData('text/plain', window.getSelection().toString());
  }
  e.preventDefault()
}