export function translate(res) {
  var data = res.data || {};
  var error_msg;
  var isHasResult = true;

  //判断是否有数据
  if (data.translateResult &&
    data.translateResult[0]
    //&& window.$Vue.$options.filters.isArray(data.translateResult[0])
    &&
    data.translateResult[0][0] &&
    !data.translateResult[0][0]['tgt']) {
    isHasResult = false;
  }

  //检测失败
  if (data.type == 'unsupported') {
    error_msg = '对不起，我不认识你的语言';
  }

  switch (data.errorCode) {
    case 2:
      error_msg = '对不起，请重试';
      break;
    case 10:
    case 20:
      error_msg = '对不起，实在太长啦，让我喘口气';
      break;
    case 30:
      error_msg = '对不起，我绞尽脑汁了';
      break;
    case 40:
      error_msg = '对不起，我正在学习该语种中';
      break;
  }

  if (!isHasResult) {
    if (data.isDog && data.online != false) {
      error_msg = '你输入太过频繁，请先休息一会儿！';
    }
    if (data.isCat && data.online != false) {
      error_msg = '您的网络暂时不可用或受限，请检查您的网络设置';
    }
    if (data.online == false) {
      error_msg = '当前网络不可用，请检查您的网络状态';
    }
  }

  if (error_msg) {
    return {
      error_code: data.errorCode,
      error_msg: error_msg
    }
  } else {
    data.isHasResult = isHasResult;
    return data;
  }
}
