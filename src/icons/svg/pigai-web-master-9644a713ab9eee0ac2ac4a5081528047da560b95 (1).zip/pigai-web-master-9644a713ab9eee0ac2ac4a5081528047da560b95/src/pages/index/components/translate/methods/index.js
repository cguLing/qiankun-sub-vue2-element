import * as api from '../api';
import * as filter from '../filter';

const keyfrom = 'deskdict.main';

//翻译
export function search() {
  let self = this;
  let params = {};
  let keyword = self.source.inputText.trim();

  //同步输入字数 
  self.nums = keyword.length;

  //无内容
  if (keyword.length <= 0) {
    self.$toast.show({
      text: '原文内容为空',
      time: 1.5,
      type: 'warn'
    })
  }

  //超过最大5000字
  if (keyword.length > self.maxLimitnNums) {
    self.$toast.show({
      text: `超过${self.maxLimitnNums}字`,
      time: 1.5,
      type: 'warn'
    })
  }

  params.data = {
    keyword: keyword,
    from: self.source.from,
    to: self.source.to,
    keyfrom: keyfrom,
  }

  params.success = function (res) {
    //更新数据
    self.$loading.hide()
    self.data.result = filter.translate(res);
  }

  params.fail = function (res) {
    self.$loading.hide()
    self.$toast.show({
      text: '翻译失败,稍后重试',
      type: 'error'
    })
  }
  api.apier(params, self);
}



//鼠标移动上去高亮对照
export function highlight() {
  let self = this;
  let $source = $(self.$el).find('.source');
  let $target = $(self.$el).find('.target');

  $target
    .off('mouseenter mouseleave')
    .on('mouseenter mouseleave', '.src,.tgt[data-group]', function (e) {
      var $this = $(this);
      var $objs = $(
        '[data-group=' + $this.data('group') + ']',
        e.delegateTarget
      );

      $objs[e.type == 'mouseenter' ? 'addClass' : 'removeClass']('highlight');

      if (e.type == 'mouseenter') {
        var data_group = $this.attr('data-group');
        var $source_span = $source.find(
          '.src[data-group=' + data_group + ']'
        );

        $source_span.addClass('highlight');

        //滚动位置
        $source.scrollTop(
          $source_span.offset().top -
          $source.offset().top +
          $source.scrollTop() -
          40
        );
      } else {
        var _data_group = $this.attr('data-group');
        $source
          .find('.src[data-group=' + _data_group + ']')
          .removeClass('highlight');
      }
    });

  $source
    .off('mouseenter mouseleave')
    .on('mouseenter mouseleave', '.src', function (e) {
      var $this = $(this);
      var $objs = $(
        '[data-group=' + $this.data('group') + ']',
        e.delegateTarget
      );

      $objs[e.type == 'mouseenter' ? 'addClass' : 'removeClass']('highlight');

      if (e.type == 'mouseenter') {
        var data_group = $this.attr('data-group');
        var $target_span = $target.find(
          '.tgt[data-group=' + data_group + ']'
        );

        $target_span.addClass('highlight');

        //滚动位置
        $target.scrollTop(
          $target_span.offset().top -
          $target.offset().top +
          $target.scrollTop() -
          40
        );
      } else {
        var _data_group = $this.attr('data-group');
        $target
          .find('.tgt[data-group=' + _data_group + ']')
          .removeClass('highlight');
      }
    })
}

//为了高亮对照替换原文内容
// export function changeInput(data) {
//     let self = this;
//     let $fanyi_input = $(self.$el).find('#js_fanyi_input');
//     let tranSrc = '';
//     data.forEach((item, parentIndex) => {
//         item.forEach((item, index) => {
//             tranSrc += `<span class='src' data-group='${parentIndex}-${index}'>${item['src']}</span>`;
//         })
//         tranSrc += `<br/>`;
//     })
//     $fanyi_input.html(tranSrc);
// }
