<template>
  <div class="suggestArea scroll_wrap">
    <div class="suggestNumber">
      共
      <span>{{currentTypeInfos.length}}</span>个修改建议
    </div>
    <!-- <input class="correctBtn" @click="manualCorrecting" type="button" value="开始批改" /> -->

    <!-- 展示文章错误 -->
    <div class="feedback">
      <ul class="suggestItems">
        <li
          v-for="item in currentTypeInfos"
          :key="item.orgChunk+'-'+item.errorId"
          :data-fixedStartPos="item.fixedStartPos"
          :data-fixedEndPos="item.fixedEndPos"
          :data-errId="item.errorId"
          @click="expand(item.fixedStartPos,item.fixedEndPos,item.errorId)"
          :class="{'active':activeId === item.errorId}"
        >
          <div class="normal">
            <i class="circle" :class="{error: (item.type === 'typo' || item.type === 'grammar')}"></i>
            <div class="words" v-html="item.orgChunk"></div>
            <span class="types">{{item.newSubErrorType | subErrorTypes}}</span>
          </div>
          <div class="expand">
            <div class="content">
              <i class="circle" :class="{error: (item.type === 'typo' || item.type === 'grammar')}"></i>
              <b class="origin" v-html="item.orgChunk"></b>
              <i class="arror"></i>
              <div
                class="target"
                @click="selectError(item.fixedStartPos, item.fixedEndPos, item.correctChunk, item.errorId)"
                title="点击修改"
                v-html="item.correctChunk"
              ></div>
            </div>
            <i
              class="delete"
              @click="ignoreError(item.fixedStartPos, item.fixedEndPos, item.errorId)"
            ></i>
            <div class="detail" v-html="item.reason"></div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import * as filters from "../../filters";
export default {
  props: {
    currentTypeInfos: {
      type: Array,
      isrequied: true,
    },
  },
  data() {
    return { activeId: "" };
  },
  filters: filters,
  methods: {
    selectError: function (fixedStartPos, fixedEndPos, correctChunk, errorId) {
      if (!navigator.onLine) {
        this.$toast.show({
          type: "fail",
          text: "当前网络不可用，请检查您的网络设置",
        });
        return;
      }
      this.$emit(
        "selectError",
        fixedStartPos,
        fixedEndPos,
        correctChunk,
        true,
        errorId
      );
    },
    ignoreError: function (fixedStartPos, fixedEndPos, errorId) {
      if (!navigator.onLine) {
        this.$toast.show({
          type: "fail",
          text: "当前网络不可用，请检查您的网络设置",
        });
        return;
      }
      this.$emit("ignoreError", fixedStartPos, fixedEndPos, true, errorId);
    },
    expand: function (fixedStartPos, fixedEndPos, errorId) {
      this.activeId = errorId;
      this.$emit("sync", fixedStartPos, fixedEndPos, "suggest", true, errorId);
      ydk.rlog({
        action: "check_unflod",
      });
    },
    // setActive: function (index) {
    //   this.activeIndex = index;
    // },
    setFirstActive: function () {
      // this.activeIndex = 0
      // console.log(this.currentTypeInfos[0])
      if (Array.isArray(this.currentTypeInfos)) {
        this.activeId = this.currentTypeInfos[0].errorId;
      }
    },
  },
};
</script>


<style lang="scss">
@import "./index";
</style>