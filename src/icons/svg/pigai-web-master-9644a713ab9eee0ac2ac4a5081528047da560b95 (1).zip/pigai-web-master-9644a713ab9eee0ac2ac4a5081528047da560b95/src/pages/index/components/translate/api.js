import $Http from './methods/http.crypto';

/**
 * 合并翻译数据
 */
var extend = (source, target) => {
  source = source || {};
  if (!target) return source;

  Object.keys(target).forEach((key) => {
    var val = target[key];
    if (val && typeof (val) == 'object' && !source[key]) {
      source[key] = val;
    }
  });
  return source;
};


/**
 * 为了页面更快的响应，同时发起本地和网络请求
 */
export function apier(params, obj) {
  var self = obj;
  //网络请求是否已经返回
  var isNetResultReturn = false;
  //本地请求是否已经返回
  var isLocalResultReturn = false;
  var netData = null;
  var ldetailData = null;

  //网络翻译 
  cryptoNet({
    data: params.data,
    success: function (res) {
      isNetResultReturn = true;
      var isDog = false; //是否查词很多次被限制
      var isCat = false; //是否是局域网
      if (_.isObject(res.data)) {
        if (Object.keys(res.data).length < 1) {
          res.data = $.extend(res.data, ldetailData);
        }
      } else {
        try {
          if ($.parseXML(res.data)) {
            isDog = true;
          } else {
            isCat = true;
          }
        } catch (e) {
          isCat = true;
        }
        res.data = ldetailData;
      }

      if (res.data) {
        res.data.isDog = isDog;
        res.data.isCat = isCat;
      }
      res.type = 'net';
      netData = res.data;
      // console.log('网络翻译数据:', JSON.stringify(res))
      params.success(res);
    },
    fail: params.fail
  })

  //本地翻译(web端只需要网络请求)
  // ldetail({
  //     data: params.data,
  //     success: function (res) {
  //         isLocalResultReturn = true;
  //         if (isNetResultReturn) return;
  //         res.data.online = res.online;
  //         ldetailData = res.data;
  //         res.type = 'local';
  //         console.log('离线翻译数据:', JSON.stringify(res))
  //         params.success(res);
  //     },
  //     fail: params.fail
  // }, obj)

}


// 本地翻译
function ldetail(params, obj) {
  var wrap = (callback) => {
    if (!callback) return null;
    return function (res) {
      res = res || {};
      res.from = 'local';
      callback(res);
    }
  }
  var self = obj;
  var keyword = params.data.keyword;
  var _from = params.data.from;
  var _to = params.data.to;
  var keyfrom = params.data.keyfrom;
  var language = ['en', 'fr', 'ko', 'ja', 'es', 'pt', 'zh-CHS', 'zh-CHT'];

  //判断是否为6种离线语种
  if ($.inArray(_from, language) > -1 && $.inArray(_to, language) > -1) {
    _from = params.data.from;
    _to = params.data.to;
  } else {
    if (_from == 'auto') {
      if (self.$utils.isChinese(keyword, 30)) {
        _from = 'zh-CHS';
        _to = 'en';
      } else {
        _from = 'en';
        _to = 'zh-CHS';
      }
    }
  }

  ydk.getTranslateResult({
    data: {
      keyword: keyword,
      from: _from,
      to: _to,
      keyfrom: keyfrom,
      forTranslatePage: true,
      type: 'local'
    },
    complete: wrap(params.complete),
    fail: wrap(params.fail),
    success: wrap(params.success)
  });
}

// 网络翻译
function net(params) {
  var wrap = (callback) => {
    if (!callback) return null;
    return function (res) {
      res = res || {};
      res.from = 'net';
      callback(res);
    }
  }
  ydk.getTranslateResult({
    data: {
      keyword: params.data.keyword,
      from: params.data.from,
      to: params.data.to,
      keyfrom: params.data.keyfrom,
      forTranslatePage: true,
    },
    complete: wrap(params.complete),
    fail: wrap(params.fail),
    success: wrap(params.success)
  });
}

// 加密网络翻译
// 加密文档：https://gitlab.corp.youdao.com/translator-dev/smtfront/blob/master/docs/API.md
function cryptoNet(params) {
  var wrap = (callback, res) => {
    if (!callback) return null;
    res = res || {};
    res.from = 'net';
    callback(res);
  }

  let url = '/translate';
  $Http({
    method: 'POST',
    url,
    data: {
      i: params.data.keyword, // 翻译文本
      from: params.data.from, // 原语言
      to: params.data.to, // 目标语言
      client: 'pigaiweb', // 用于身份验证，和私钥配对
      salt: new Date().getTime(), // 随机数
      version: '2.1', // 翻译格式版本，2.1版本可以实现句子对齐
      keyfrom: 'pigai.web', // 额外参数
    },
  }).then((res) => {
    wrap(params.success, res);
  }).catch((res) => {
    wrap(params.fail, res);
  });
}
