<template>
  <div class="workArea" @copy="editorCopy">
    <div v-show="comparing" class="cover"></div>
    <div class="contentWrap" v-show="comparing">
      <div class="scrollArea">
        <input class="title" v-model="title" readonly="readonly" />
        <div id="editorWrap" class="editorWrap">
          <div class="translateComponet" spellcheck="false" v-html="translateHtml"></div>
        </div>
      </div>
      <div class="translateBtn" v-show="isShowCompare" @click="compareTranslate">关闭对照翻译</div>
      <div class="submitBtnDisactive">批改</div>
      <!-- <div class="compareTranslateWarn" v-if="currentNum>maxLimitnNum">
        <em>目前仅支持{{maxLimitnNum}}字符的对照翻译</em>
      </div> -->
    </div>
    <div class="contentWrap" @keydown.enter.ctrl.prevent="submit" v-show="!comparing">
      <slot name="bubbleTips"></slot>
      <div class="scrollArea" @scroll.passive="scroll">
        <input
          type="text" 
          class="title"
          v-model="title"
          placeholder="请在此输入标题"
          maxlength="200"
          spellcheck="false"
          @keyup.enter="keepLastIndex"
          @input="titleInput"
          @keyup="titleKeyup"
        />
        <div id="editorWrap" class="editorWrap">
          <div
            class="editorComponent"
            spellcheck="false"
            ref="editorRef"
            v-html="innerText"
            :contenteditable="canEdit"
            @input="editorInput"
            @keyup="editorKeyup"
            @focus="editorFocus"
            @blur="editorBlur"
            @paste="editorPaste"
          ></div>

          <!-- <slot name="editEmptyGuide"></slot> -->
          <div class="emptyGuideText" v-show="currentNum===0">请开始您的写作或粘贴待批改的文本</div>
        </div>
      </div>
      <div class="emptyClipPrompt" v-show="isShowEmptyPrompt">剪贴板中无文字</div>
      <div class="pigaiHit" v-show="isShowPigaiHit">{{isMac() ? 'Control + Enter':'Crtl + Enter'}}</div>
      <!-- <i class="clearBtm" @click="clear" /> -->
      <div class="showNums">
        <span :style="currentNum>maxLimitnNum?{color:'red'}:{}">{{currentNum}}</span>/{{maxLimitnNum}}  
      </div>
      <div class="translateBtn" v-show="isShowCompare&&currentNum>0" @click="compareTranslate">对照翻译</div>
      <div
        class="submitBtn"
        @click="submit"
        @mousemove="showPigaiHit"
        @mouseleave="hidePigaiHit"
        :class="{submitBtnDisactive:!currentNum}"
      >批改</div>
    </div>
  </div>
</template>

<script>
import * as methods from "./methods";
import { mapState } from "vuex";
import simpleVdom from "../../methods/simpleVdom";
import Store from "commons/localStorage.js";
let isIE11 = false;
//判断IE11(ie无法监听input事件，要改成keydown事件)
//keydown会丢失最后一个输入字符，改成keyup
if (navigator.userAgent.toLowerCase().match(/rv:([\d.]+)\) like gecko/)) {
  isIE11 = true;
}
//组件是否更新
let componentUpdated = false;

export default {
  name: "editDiv",
  props: {
    maxLimitnNum: {
      type: Number,
      default: 10000,
    },
    receiveText: {
      type: String,
      default: "",
    },
    canEdit: {
      type: Boolean,
      default: true,
    },
    html: {
      type: String,
      default: "",
    },
    isModfiy: {
      type: Boolean,
      default: false,
    },
    translateHtml: {
      type: String,
      default: "",
    },
    isShowCompare: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      // title: "", // 标题
      innerText: "", //输入框内容
      focus: false, //输入框是否聚焦
      currentNum: 0, //当前输入字符
      isIE11,
      comparing: false, //是否是对照翻译状态
      isShowEmptyPrompt: false, //是否显示剪贴板无文字提示
      isShowPigaiHit: false, //是否显示批改快捷键提示
    };
  },
  created() {},
  watch: {
    receiveText(val) {
      this.innerText = val;
      this.currentNum = val.length;
      //设置光标， 有内容不批改情况
      this.$nextTick(function () {
        if (!componentUpdated && !this.isModfiy) {
          this.keepLastIndex();
          componentUpdated = true;
        }
      });
    },
    html(val) {
      this.innerText = val;
      //设置光标， 有内容要批改情况
      this.$nextTick(function () {
        if (!componentUpdated && this.isModfiy) {
          this.keepLastIndex();
          componentUpdated = true;
        }
      });
    },
  },
  computed: {
    title: {
      get() {
        return this.$store.state.essay.title;
      },
      set(value) {
        this.$store.dispatch("setTitle", value);
      },
    },
  },
  methods: methods,
  mounted() {
    //设置光标, 无内容情况
    // this.keepLastIndex();
    // document.execCommand('insertBrOnReturn', false, '<br><br>')
    // IE和firefox,contenteditale 回车会insertParagraph
    // if (document.queryCommandSupported("insertBrOnReturn")) {
    //   $('.editorComponent').keydown(function (event) {
    //     if (event.keyCode == 13 && !event.ctrlKey) {
    //       // document.execCommand("insertHTML", false, "\n");
    //       document.execCommand('insertLineBreak',false)
    //       event.preventDefault();
    //       // document.execCommand('insertParagraph',false)
    //       // document.execCommand('insertLineBreak', false, null);
    //       return false;
    //     }
    //   })
    // }
    if (!Store.get("is_hide_pigai_hit")) {
      this.isShowPigaiHit = true;
      setTimeout(() => {
        this.isShowPigaiHit = false;
        Store.set("is_hide_pigai_hit", true);
      }, 2000);
    }
  },
};
</script>

<style lang="scss">
@import "./index.scss";
</style>