//显示
export function show(params) {
  let self = this;
  $(self.$el).css({
    left: params.left || 0,
    top: params.top || 0
  });
  self.orgChunk = params.orgChunk;
  self.correctChunk = params.correctChunk;
  self.fixedStartPos = params.fixedStartPos;
  self.fixedEndPos = params.fixedEndPos;
  self.errorId = params.errorId;
  self.isShow = true;
}


//隐藏
export function hide() {
  let self = this;
  self.isShow = false;
}


//修改
export function correctAction() {
  let self = this;
  if(!navigator.onLine){
    self.$toast.show({
      type: 'fail',
      text: '当前网络不可用，请检查您的网络设置'
    })
    return
  }
  self.$emit('correctAction', {
    correctChunk: self.correctChunk,
    fixedStartPos: self.fixedStartPos,
    fixedEndPos: self.fixedEndPos,
    errorId: self.errorId
  });
  self.hide();
}


//忽略
export function ignoreAction() {
  let self = this;
  if(!navigator.onLine){
    self.$toast.show({
      type: 'fail',
      text: '当前网络不可用，请检查您的网络设置'
    })
    return
  }
  self.$emit('ignoreAction', {
    correctChunk: self.correctChunk,
    fixedStartPos: self.fixedStartPos,
    fixedEndPos: self.fixedEndPos,
    errorId: self.errorId
  });
  self.hide();
}
