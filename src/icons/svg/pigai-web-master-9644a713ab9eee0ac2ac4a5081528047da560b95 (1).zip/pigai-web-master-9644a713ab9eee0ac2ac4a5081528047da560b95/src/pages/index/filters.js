export function errorTypes(errorType) {
  let errorTypeStr = '';

  switch (errorType) {
    case 0:
      errorTypeStr = '拼写错误';
      break;
    case 1:
      errorTypeStr = '冠词错误';
      break;
    case 2:
      errorTypeStr = '动词时态或者第三人称单复数错误';
      break;
    case 3:
      errorTypeStr = '名词单复数错误';
      break;
    case 4:
      errorTypeStr = '格式错误';
      break;
    case 5:
      errorTypeStr = '介词错误';
      break;
    case 6:
      errorTypeStr = '其他语法错误';
      break;
    case 7:
      errorTypeStr = '文本格式错误';
      break;

  }

  return `${errorTypeStr}`;
}


export function supErrorTypes(errorType) {
  let errorTypeStr = '';

  switch (errorType) {
    case 1:
      errorTypeStr = '书写格式';
      break;
    case 2:
      errorTypeStr = '拼写';
      break;
    case 3:
      errorTypeStr = '标点';
      break;
    case 4:
      errorTypeStr = '冠词';
      break;
    case 5:
      errorTypeStr = '动词';
      break;
    case 6:
      errorTypeStr = '名词单复数';
      break;
    case 7:
      errorTypeStr = '代词';
      break;
    case 8:
      errorTypeStr = '介词';
      break;
    case 9:
      errorTypeStr = '形容词';
      break;
    case 10:
      errorTypeStr = '副词';
      break;
    case 11:
      errorTypeStr = '连词';
      break;
    case 20:
      errorTypeStr = '其他';
      break;
    case 21:
      errorTypeStr = '所有语法';
      break;

  }

  return `${errorTypeStr}`;
}


export function subErrorTypes(errorType) {
  let errorTypeStr = '';

  switch (errorType) {
    case 1:
      errorTypeStr = '语法错误';
      break;
    case 2:
      errorTypeStr = '词汇缺失';
      break;
    case 3:
      errorTypeStr = '词汇冗余';
      break;
    case 4:
      errorTypeStr = '冠词误用';
      break;
    case 5:
      errorTypeStr = '介词误用';
      break;
    case 6:
      errorTypeStr = '动词主谓一致错误';
      break;
    case 7:
      errorTypeStr = '动词时态错误';
      break;
    case 8:
      errorTypeStr = '情态动词后应接动词原形错误';
      break;
    case 9:
      errorTypeStr = '被动语态错误';
      break;
    case 10:
      errorTypeStr = '动词不定式错误';
      break;
    case 11:
      errorTypeStr = '其他动词错误';
      break;
    case 12:
      errorTypeStr = '形容词比较级错误';
      break;
    case 13:
      errorTypeStr = '形容词最高级错误';
      break;
    case 14:
      errorTypeStr = '副词比较级错误';
      break;
    case 15:
      errorTypeStr = '副词最高级错误';
      break;
    case 16:
      errorTypeStr = '名词单复数错误';
      break;
    case 17:
      errorTypeStr = '其他名词错误';
      break;
    case 18:
      errorTypeStr = '人称代词主宾格混淆';
      break;
    case 19:
      errorTypeStr = '人称代词和物主代词混淆';
      break;
    case 20:
      errorTypeStr = '形容词性和名词性代词混淆';
      break;
    case 21:
      errorTypeStr = '人称代词和反身代词混淆';
      break;
    case 22:
      errorTypeStr = '疑问、关系、连接代词混淆';
      break;
    case 23:
      errorTypeStr = '指示代词混淆';
      break;
    case 24:
      errorTypeStr = '不定代词混淆';
      break;
    case 25:
      errorTypeStr = '其他代词错误';
      break;
    case 26:
      errorTypeStr = '标点符号误用';
      break;
    case 27:
      errorTypeStr = '拼写错误';
      break;
    case 28:
      errorTypeStr = '不规范错误';
      break;

  }

  return `${errorTypeStr}`;
}
