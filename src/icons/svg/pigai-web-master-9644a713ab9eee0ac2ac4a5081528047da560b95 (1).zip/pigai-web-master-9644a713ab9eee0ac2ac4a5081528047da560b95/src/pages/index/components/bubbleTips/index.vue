<template>
  <div class="bubbleTips" :style="styles">
    <div>
      <span class="text">{{text}}</span>
      <span class="line"></span>
      <span v-if="needClose" class="closeBtn icon-close" @click="closeBubble"></span>
    </div>
    <span class="arror-down" :style="arrorStyle"></span>
  </div>
</template>

<script>
export default {
  props: {
    theme: {
      type: String,
      default: "",
    },
    needClose:{
      type: Boolean,
      default: true
    },
    text: {
      type: String,
      default: "",
      required: true
    },
    styles: {
      type: String,
      default: ""
    },
    arrorDirection:{
      type: String,
      default: "down"
    },
    arrorStyle: {
      type: String,
      default: ""
    }    
  },
  methods: {
    closeBubble() {
      this.$emit("closeBubble");
    }
  }
};
</script>

<style lang="scss" scoped>
.bubbleTips {
  background: #fdf2f1;
  border-radius: 3px;
  font-size: 12px;
  color: #333333;
  position: relative;

  .text {
    line-height: 16px;
    padding: 10px 10px 10px 12px;
    min-width: 178px;
    float: left;
  }
  .line {
    height: 24px;
    display: block;
    width: 1px;
    overflow: hidden;
    background: #c83939;
    margin-top: 5px;
    float: left;
    opacity: 0.1;
  }
  .closeBtn {
    display: block;
    width: 13px;
    height: 13px;
    font-size: 13px;
    float: left;
    margin: 11px 11px 0px 12px;
    cursor: pointer;
    color: #999999;
  }
  .arror-down {
    width: 0;
    height: 0;
    overflow: hidden;
    display: block;
    border: 10px solid transparent;
    border-top: 10px solid#FDF2F1;
    position: absolute;
    bottom: -18px;
    left: 188px;
  }
}
</style>