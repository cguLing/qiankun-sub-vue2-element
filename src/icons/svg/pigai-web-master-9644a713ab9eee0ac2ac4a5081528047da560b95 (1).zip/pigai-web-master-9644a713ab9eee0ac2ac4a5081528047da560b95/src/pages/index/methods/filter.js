export default {

  /**
   * 生成原始的信息，并转换绝对位置
   * @param {*} sentsFeedback  
   */
  genRawSentsFeedback(sentsFeedback) {
    const allErrPostInfo = []
    let lastFixedEndPos = 0;
    // console.log('sentsFeedback',sentsFeedback)
    sentsFeedback.forEach(raw => {
      const {
        sentStartPos,
        paraId,
        sentId
      } = raw
      raw.errorPosInfos.forEach((v, k) => {
        const {
          startPos,
          endPos
        } = v
        // 转换绝对起始位置
        const fixedStartPos = sentStartPos + startPos
        // 转换绝对结束位置
        const fixedEndPos = sentStartPos + endPos
        if (fixedStartPos >= lastFixedEndPos) {
          v.fixedStartPos = fixedStartPos;
          v.fixedEndPos = fixedEndPos;
          v.errorId = `${paraId}-${sentId}-${k}`
          allErrPostInfo.push(v)
          lastFixedEndPos = fixedEndPos
        } else {
          console.error('错误位置重叠，忽略该错误', v)
        }
      })
    })
    // console.log(sentsFeedback)
    return allErrPostInfo.sort((a, b) => a.fixedStartPos - b.fixedStartPos)
  },

  /**
   * 生成错误的信息
   * @param {*} genRawSentsFeedback 原始数据
   */
  genTypeErrorPostInfo(genRawSentsFeedback) {
    const allErrPostInfo = [];

    genRawSentsFeedback.forEach(raw => {
      const {
        type
      } = raw;
      if (type === 'typo' || type === 'grammar') {
        allErrPostInfo.push(raw);
      }
    })

    return allErrPostInfo;
  },

  /**
   * 生成不规范的信息
   * @param {*} genRawSentsFeedback 原始数据
   */
  genTypeIrregularPostInfo(genRawSentsFeedback) {

    const allErrPostInfo = [];

    genRawSentsFeedback.forEach(raw => {
      const {
        type
      } = raw;
      if (type === 'refactor') {
        allErrPostInfo.push(raw);
      }
    })

    return allErrPostInfo;
  },


  /**
   * 生成所有的错误信息
   * @param {*} genRawSentsFeedback   原始数据
   */
  genAllErrorPostInfo(genRawSentsFeedback) {
    return genRawSentsFeedback;
  },

  /**
   * 过滤当前操作的数据
   * @param {*} errorPostInfo 
   * @param {*} options 
   */
  filterErrorPostInfo(errorPostInfo, options) {
    const includeOperationErrPostInfo = [];
    const exceptOperationErrPostInfo = [];
    options = Object.assign({
      operation: 'change',
      fixedStartPos: '',
      fixedEndPos: ''
    }, options);

    errorPostInfo.forEach(element => {
      const {
        fixedStartPos,
        fixedEndPos
      } = element;
      if (fixedStartPos == options.fixedStartPos && fixedEndPos == options.fixedEndPos) {
        element.operation = options.operation;
        //return;  //跳出本次循环
      } else {
        exceptOperationErrPostInfo.push(element);
      }
      includeOperationErrPostInfo.push(element);
    });


    return {
      includeOperationErrPostInfo, //包含当前操作数据
      exceptOperationErrPostInfo //不包含当前操作数据
    };

  },

  /**
   * 生成有原始错误信息
   * @param {*} sentsFeedback 
   */
  filterRawSentsFeedback(sentsFeedback) {
    const result = {
      sents: []
    };
    let lastFixedEndPos = 0;
    if (Array.isArray(sentsFeedback)) {
      sentsFeedback.forEach((item) => {
        const {
          errorPosInfos,
          sentStartPos,
          rawSent
        } = item;
        if (errorPosInfos.length > 0) {
          const i = {
            orgSent: rawSent,
            errorPosInfos: []
          };
          errorPosInfos.forEach((v, k) => {
            const {
              startPos,
              endPos
            } = v;
            // 转换绝对起始位置
            const fixedStartPos = sentStartPos + startPos;
            // 转换绝对结束位置
            const fixedEndPos = sentStartPos + endPos;
            if (fixedStartPos >= lastFixedEndPos) {
              i.errorPosInfos.push({
                fixedStartPos: fixedStartPos,
                fixedEndPos: fixedEndPos,
                isAccepted: false, //是否接受批改
                isIgnored: false //是否忽略批改
              });
              lastFixedEndPos = fixedEndPos;
            } else {
              console.error('错误位置重叠，忽略该错误', v);
            }
          });
          result.sents.push(i);
        }
      });
    }
    //console.log('原始：', result);
    return result;
  },

  /**
   * 生成修改之后的段落信息
   * @param {*} sentsFeedback 
   * @param {*} options 
   */
  // genModfiySentsFeedback(sentsFeedback, options) {
  //   options = Object.assign({
  //     isAccepted: false,
  //     isIgnored: false,
  //     fixedStartPos: '',
  //     fixedEndPos: ''
  //   }, options);

  //   if (sentsFeedback.sents && Array.isArray(sentsFeedback.sents)) {
  //     sentsFeedback.sents.forEach((v, k) => {
  //       const {
  //         errorPosInfos
  //       } = v;
  //       errorPosInfos.forEach((v, k) => {
  //         const {
  //           fixedStartPos,
  //           fixedEndPos
  //         } = v;
  //         if (fixedStartPos == options.fixedStartPos && fixedEndPos == options.fixedEndPos) {
  //           v.isAccepted = options.isAccepted;
  //           v.isIgnored = options.isIgnored;
  //         }
  //       });
  //     });
  //   }
  //   //console.log('修改：', sentsFeedback);
  //   return sentsFeedback;
  // }
  genModfiySentsFeedback(sentsFeedback, options) {
    options = Object.assign({
      isAccepted: false,
      isIgnored: false,
      // fixedStartPos: '',
      // fixedEndPos: ''
    }, options);

    // console.log('sentsFeedback', sentsFeedback)
    let userActionSeq = {
      sents: []
    }
    if (Array.isArray(sentsFeedback)) {
      sentsFeedback.forEach(s => {
        let sent = {
          orgSent: s.rawSent,
          errorPosInfos: []
        }
        s.errorPosInfos.forEach((err,i) => {
          sent.errorPosInfos.push({
            isAccepted: false,
            isIgnored: false,
            errorId:`${s.paraId}-${s.sentId}-${i}`
          })
        })
        userActionSeq.sents.push(sent)
      })
    }
    // console.log('userActionSeq', userActionSeq)
    return userActionSeq
  }
}
