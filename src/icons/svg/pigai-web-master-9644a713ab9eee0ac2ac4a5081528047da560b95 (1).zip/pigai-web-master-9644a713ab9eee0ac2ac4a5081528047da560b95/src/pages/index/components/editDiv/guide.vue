<!-- 未填写时候的引导 -->
<template>
  <div class="editEmptyGuide">
    <!-- <div class="emptyText"><span class="place">请开始您的写作...</span></div> -->
    <div class="bubbleTips">
      <div>
        <span class="text">{{text}}</span>
        <span class="line"></span>
      </div>
      <span class="arror-down" :style="arrorStyle"></span>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    theme: {
      type: String,
      default: ""
    },
    needClose: {
      type: Boolean,
      default: true
    },
    text: {
      type: String,
      default: "",
      required: true
    },
    styles: {
      type: String,
      default: ""
    },
    arrorDirection: {
      type: String,
      default: "down"
    },
    arrorStyle: {
      type: String,
      default: ""
    }
  },
  methods: {
    closeBubble() {
      this.$emit("closeBubble");
    }
  }
};
</script>

<style lang="scss" scoped>
.editEmptyGuide {
  background: #fff;
  position: relative;
  .emptyText{
     font-size: 18px;
     line-height: 30px;
     color: #333;
  }
  .bubbleTips {
    display: inline-block;
    background: #fb4a3e;
    border-radius: 3px;
    font-size: 14px;
    font-family: Microsoft YaHei;
    color: #fff;
    position: absolute;
    left: 0;
    top:57px;
    z-index:16;

    .text {
      line-height: 16px;
      padding: 14px 12px;
      font-weight: 600;
      float: left;
    }
    .line {
      height: 24px;
      display: block;
      width: 1px;
      overflow: hidden;
      background: #c83939;
      margin-top: 5px;
      float: left;
      opacity: 0.1;
    }
    .closeBtn {
      display: block;
      width: 13px;
      height: 13px;
      font-size: 13px;
      float: left;
      margin: 11px 11px 0px 12px;
      cursor: pointer;
      color: #999999;
    }
    .arror-down {
      width: 0;
      height: 0;
      overflow: hidden;
      display: block;
      border: 10px solid transparent;
      border-bottom: 10px solid #fb4a3e;
      position: absolute;
      top: -18px;
      left: 17px;
    }
  }
}
</style>