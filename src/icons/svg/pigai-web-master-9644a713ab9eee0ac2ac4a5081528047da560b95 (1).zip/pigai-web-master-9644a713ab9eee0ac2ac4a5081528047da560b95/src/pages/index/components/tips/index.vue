<template>
  <div class="tipsArea">
    <dl class="tipsSort">
      <dd class="allError" data-type="1" @click="clickTip(1)" :class="{'active':activeIndex == 1}">
        <span>所有错误</span>
        <span class="num">{{allTypeInfos.length}}</span>
      </dd>
      <div class="divider"></div>
      <dd data-type="2" @click="clickTip(2)" :class="{'active':activeIndex == 2}">
        <i class="circle error"></i>
        <span>错误</span>
        <span class="num">{{errorTypeInfos.length}}</span>
      </dd>
      <dd data-type="3" @click="clickTip(3)" :class="{'active':activeIndex == 3}">
        <i class="circle irregular"></i>
        <span>书写不规范</span>
        <span class="num">{{irregularTypeInfos.length}}</span>
      </dd>
    </dl>
  </div>
</template>

<script>
export default {
  props: {
    allTypeInfos: {
      type: Array,
      required: true,
    },
    errorTypeInfos: {
      type: Array,
      required: true,
    },
    irregularTypeInfos: {
      type: Array,
      required: true,
    },
  },
  data() {
    return { activeIndex: 1 };
  },
  methods: {
    clickTip(type) {
      console.log("clickTip", type);
      let inputText = this.$parent.$refs.editdivRef.getEditVal();
      this.$store.dispatch("setInputText", inputText);
      this.$store.dispatch("setCurrentType", type);
      this.activeIndex = type;
      //不改输入框变内容
      this.$emit("showEditErrorType", type);
      let logType = "all";
      if (type == 1) {
        logType = "all";
      } else if (type == 2) {
        logType = "error";
      } else if (type == 3) {
        logType = "abnormal";
      }
      ydk.rlog({
        action: "check_sort_click",
        type: logType,
      });
    },
  },
};
</script>


<style lang="scss">
@import "./index";
</style>