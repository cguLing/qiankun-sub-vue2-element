/*eslint-disable */

//import StringReplace from 'commons/stringReplace'
import simpleVdom from './simpleVdom';

export default {
  /**
   * 替换字符串内容，subString方式
   * @param {*} source 
   * @param {*} startPos 
   * @param {*} endPos 
   * @param {*} replacetext 
   */
  replaceSubstring(source, startPos, endPos, replacetext) {
    let newStr = '';
    newStr = source.substring(0, startPos) + replacetext + source.substring(endPos);
    return newStr;
  },

  /**
   * 替换字符串子串，正则方式
   * @param {*} str 
   * @param {*} startPos 
   * @param {*} endPos 
   * @param {*} replacetext 
   */
  replaceRegexpStr(str, startPos, endPos, replacetext) {
    let newStr = '';
    let subStr = str.substring(startPos, endPos);
    newStr = str.replace(new RegExp(subStr, "g"), replacetext);
    return newStr;
  },

  /**
   * 将原文 以及 得到的错误信息 依次转换为html
   * @param {String} rawEssay 原文
   * @param {Object} essayFeedback 错误信息
   * @param {Boolean} wordNum 是否需要显示单词数
   * @return {Array} 节点数组
   */
  genEssayHtml(rawEssay, allErrPostInfo, options) {
    console.log('allErrPostInfo', allErrPostInfo)
    options = Object.assign({
        wordNum: false,
        currentType: 1, //当前选择的错误类型 1：全部（默认） 2：错误 3：不规范
        errorClass: 'errorLine',
        irregularClass: 'irregularLine',
      },
      options
    )

    const errWordsNodes = []
    let index = 0
    let lastEndPos = 0
    if (Array.isArray(allErrPostInfo)) {
      // 上一次错误信息的结束位置
      allErrPostInfo.forEach(v => {
        // 错误信息相对于该行的起始位置与结束位置
        const {
          fixedStartPos,
          fixedEndPos,
          orgChunk,
          correctChunk,
          type,
          operation
        } = v
        if (fixedStartPos >= lastEndPos) {
          // 如果该错误起始位置 大于 上一次 错误的结束位置 => 生成一个新的节点保存两者中间的内容
          if (fixedStartPos > lastEndPos) {
            const beforeText = rawEssay.substring(lastEndPos, fixedStartPos)
            errWordsNodes.push(simpleVdom.createNode('span', beforeText))
          }
          lastEndPos = fixedEndPos
          // 生成错误文本 错误文本为空的情况下 生成正确文本长度的横线
          let errText = rawEssay.substring(fixedStartPos, fixedEndPos)
          // 移除0长度字符
          errText = errText.replace(/\u200B/g, '')
          errText =
            errText.length > 0 ?
            errText :
            this.genSpace(v.correctChunk.length)
          /**
           * 生成错误信息的样式 以及 属性
           * 中文错误 提示为 灰色 为贯穿线
           * 其它错误 提示为 红色 为下划线
           */
          let typeClass = '';
          let currentType = options.currentType;
          if (currentType == 1) {
            //不规范：refactor， 错误： typo/grammar
            if (type === 'refactor') {
              typeClass = options.irregularClass;
            } else if (type === 'typo' || type === 'grammar') {
              typeClass = options.errorClass;
            }
          } else if (currentType == 2) {
            if (type === 'typo' || type === 'grammar') typeClass = options.errorClass;
          } else if (currentType == 3) {
            if (type === 'refactor') typeClass = options.irregularClass;
          }

          let dataTypeClass = '';
          if (type === 'refactor') {
            dataTypeClass = options.irregularClass;
          } else if (type === 'typo' || type === 'grammar') {
            dataTypeClass = options.errorClass;
          }


          const errTextAttr = {
            class: `underline ${typeClass}`,
            'data-index': index++,
            'data-correctChunk': correctChunk,
            'data-orgChunk': orgChunk,
            'data-fixedStartPos': fixedStartPos,
            'data-fixedEndPos': fixedEndPos,
            'data-errorType': dataTypeClass
          }


          if (operation == 'change') {
            // 增加正确信息    
            errWordsNodes.push(
              simpleVdom.createNode('span', correctChunk, {})
            )
          } else if (operation == 'ignore') {

            //增加忽略
            errWordsNodes.push(
              simpleVdom.createNode('em', errText, {})
            )
          } else {
            // 增加错误信息
            errWordsNodes.push(
              simpleVdom.createNode('span', errText, errTextAttr)
            )
          }
        }
      })

      // 加入结束的文本（最后可能有未处理的文本）
      const endText = rawEssay.substring(lastEndPos)
      errWordsNodes.push(simpleVdom.createNode('span', endText))

    }
    // 根据换行符重新整理dom  然后 渲染
    return this.render(this.formatEnterChar(errWordsNodes));
  },


  genEssaySentHtml(rawEssay, rawSentsFeedback, options) {
    // console.log('rawEssay, rawSentsFeedback', rawEssay, rawSentsFeedback)
    options = Object.assign({
        wordNum: false,
        currentType: 1, //当前选择的错误类型 1：全部（默认） 2：错误 3：不规范
        errorClass: 'errorLine',
        irregularClass: 'irregularLine',
      },
      options
    )
    const sentenceNodes = []
    if (Array.isArray(rawSentsFeedback)) {
      // 处理每一句
      let lastCentenceEnd = 0;
      rawSentsFeedback.forEach(sent => {
        // if (sent.errorPosInfos.length === 0) {
        //   let errorNodes = [simpleVdom.createNode('span', sent.rawSent)]
        //   const {
        //     paraId,
        //     sentId,
        //   } = sent
        //   let sentencesAttr = {
        //     'class': 'sentence',
        //     'data-id': `${paraId}-${sentId}`
        //   }
        //   sentenceNodes.push(simpleVdom.createNode('span', errorNodes, sentencesAttr))
        // }
        // else{
        const errorNodes = []
        const {
          paraId,
          sentId,
          rawSent,
          errorPosInfos,
          sentStartPos
        } = sent
        // 句子的开始和结尾下标
        let start = 0
        let end = rawSent.length - 1

        // 处理句子间可能存在的空格换行等
        // let sentEndPos = end + rawSent.length   

        if (sentStartPos !== lastCentenceEnd) {
          let betweenCentenceText = rawEssay.substring(lastCentenceEnd, sentStartPos)
          // console.log('betweenCentenceText:', betweenCentenceText)
          sentenceNodes.push(simpleVdom.createNode('span', betweenCentenceText))
        }
        lastCentenceEnd = sentStartPos + rawSent.length
        // 根据每个错误分割句子
        errorPosInfos.forEach((err, index) => {
          const {
            startPos,
            endPos,
            type,
            correctChunk,
            orgChunk
          } = err
          // 每个错误需要插入错误之前和错误本身的文本
          let pre = rawSent.substring(start, startPos)
          if (pre.length !== 0) {
            errorNodes.push(simpleVdom.createNode('span', pre))
          }
          // 插入错误本身的文字，并设置属性
          let errText = rawSent.substring(startPos, endPos)
          let typeClass = '';
          if (type === 'refactor') {
            typeClass = options.irregularClass;
          } else if (type === 'typo' || type === 'grammar') {
            typeClass = options.errorClass;
          }
          let dataTypeClass = '';
          if (type === 'refactor') {
            dataTypeClass = options.irregularClass;
          } else if (type === 'typo' || type === 'grammar') {
            dataTypeClass = options.errorClass;
          }
          let errTextAttr = {
            'class': `underline ${typeClass}`,
            'data-correctChunk': encodeURIComponent(correctChunk),
            'data-orgChunk': encodeURIComponent(orgChunk),
            'data-errorType': dataTypeClass,
            'data-errid': `${paraId}-${sentId}-${index}`
          }
          // 移除0长度字符
          errText = errText.replace(/\u200B/g, '')
          errText =
            errText.length > 0 ?
            errText :
            this.genSpace(v.correctChunk.length)
          errorNodes.push(simpleVdom.createNode('span', errText, errTextAttr))
          start = endPos
        })
        // 加入最后可能的文本
        if (start <= end) {
          let lastText = rawSent.substring(start)
          errorNodes.push(simpleVdom.createNode('span', lastText))
        }
        // }
        // 每句话的span加上标识
        let sentencesAttr = {
          'class': 'sentence',
          'data-id': `${paraId}-${sentId}`
        }
        sentenceNodes.push(simpleVdom.createNode('span', errorNodes, sentencesAttr))
        // }
      })
      // 加入最后的空格和换行符
      let last = rawEssay.substring(lastCentenceEnd)
      if (last) {
        sentenceNodes.push(simpleVdom.createNode('span', rawEssay.substring(lastCentenceEnd)))
      }
    }
    // console.log(this.render(sentenceNodes))
    return this.render(sentenceNodes);
  },

  genTranslateHtml(translateResult) {
    let sentenceNodes = []
    let tgtAttr = {
      'class': 'tgt'
    }
    let srcAttr = {
      'class': 'src'
    }
    if (Array.isArray(translateResult)) {
      translateResult.forEach(p => {
        p.forEach(s => {
          sentenceNodes.push(simpleVdom.createNode('span', s.src + ' ', srcAttr))
          sentenceNodes.push(simpleVdom.createNode('span', s.tgt, tgtAttr))
        })
        sentenceNodes.push(simpleVdom.createNode('span', '\n'))
      })
    }
    return this.render(sentenceNodes);
  },

  /**
   * 将换行符之前的文本转换为全部替换到 p Node 下的 childreen
   * @param {Array} errWordsNodes 错误节点
   * @return {Array} 节点数组
   */
  formatEnterChar(errWordsNodes) {
    const res = []
    // 上一次换行的节点索引
    let lastBreakLineIndexOfNodes = 0
    for (let i = 0, length = errWordsNodes.length; i < length; i++) {

      // 当前节点
      const errWordsNode = errWordsNodes[i]
      // 内容为文本的限定
      if (typeof errWordsNode.children === 'string') {
        // 相对于文本的换行位置
        let breakLineIndex
        // 遍历当前文本所有的换行位置
        while ((breakLineIndex = errWordsNode.children.indexOf('\n')) > -1) {
          const errWordsNodeStr = errWordsNode.children

          // 换行符前面的文本
          //const firstStr = errWordsNodeStr.slice(0, breakLineIndex)
          //const firstStr = '<br />'
          let firstStr = errWordsNodeStr.slice(0, breakLineIndex);
          if (firstStr.length <= 0) {
            firstStr = ' ';
          }

          // 换行符后面的文本
          //const secondStr = errWordsNodeStr.slice(breakLineIndex + 1)
          //const secondStr = '<br />'
          let secondStr = errWordsNodeStr.slice(breakLineIndex + 1);
          if (secondStr.length <= 0) {
            secondStr = ' ';
          }

          // 该节点到上一次拥有换行符节点之间的所有的节点
          const beforeNodesValue = errWordsNodes.slice(
            lastBreakLineIndexOfNodes,
            i
          )
          // 将 两者之间的节点 以及 换行符前面的文本 生成新的节点数组 加入 p标签内
          res.push(
            simpleVdom.createNode('p', [
              ...beforeNodesValue,
              simpleVdom.createNode(errWordsNode.type, firstStr)
            ])
          )
          // 将 当前节点 替换为 换行符后面的文本 生成的节点
          Object.assign(
            errWordsNodes[i],
            simpleVdom.createNode(errWordsNode.type, secondStr)
          )
          // 记录该节点的索引位置
          lastBreakLineIndexOfNodes = i
        }
      }
    }

    // 添加剩余的节点
    res.push(
      simpleVdom.createNode(
        'p',
        errWordsNodes.slice(lastBreakLineIndexOfNodes)
      )
    )

    return res;
  },


  /**
   * 生成空格
   * @return {String}
   */
  genSpace(length) {
    return new Array(length).fill('&nbsp').join(';')
  },

  /**
   * 将节点渲染成html
   * @param {Array} nodes
   */
  render(nodes) {
    return simpleVdom.render(nodes)
  }

}
