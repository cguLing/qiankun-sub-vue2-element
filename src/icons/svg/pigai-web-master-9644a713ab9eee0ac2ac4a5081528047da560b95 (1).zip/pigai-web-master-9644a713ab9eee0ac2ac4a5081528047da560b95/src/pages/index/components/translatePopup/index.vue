<template>
  <div class="translate-main" :style="style" v-show="isShow">
    <!-- <div class="raw-area" :contenteditable="isEditAble" v-text="rawSent" @input="handleInput"></div> -->
    <div class="textarea-wrapper ">
      <div id="contentEditable" class="content-editable scroll">{{rawSent}}</div>
      <textarea
        class="raw-area scroll"
        id="raw-area"
        type="text"
        :readonly="isEditAble ? false : 'readonly'"
        v-model="rawSent"
        placeholder="可以输入中文字符获取翻译结果替换原内容"
        @keydown.enter.prevent="debounceGetEditTranslate"
        maxlength="500"
        spellcheck="false"
      />
    </div>
    <div class="suggest-area" v-show="isShowSuggest">
      <div class="divider"></div>
      <div v-show="suggest" class="suggest scroll">{{suggest}}</div>
      <div v-show="!suggest" class="holder">译文</div>
      <div class="cancle" @click="clear">取消</div>
      <div class="replace" @click="replace">替换</div>
    </div>
    <i class="edit" @click="showSuggest" v-show="!isShowSuggest"></i>
  </div>
</template>

<script>
import * as methods from "./methods/index";
export default {
  data() {
    return {
      isShow: false,
      isShowSuggest: false,
      style: {
        top: "0px",
        left: "0px",
      },
      isEditAble: false,
      sentId: "",
      rawSent: "",
      suggest: "",
    };
  },
  watch: {
    rawSent: function () {
      if (this.isShowSuggest) {
        this.debounceGetEditTranslate();
      }
    },
  },
  created: function () {
    this.debounceGetEditTranslate = _.debounce(this.getEditTranslate, 500);
  },
  // mounted: function () {
    // let self = this;
    // 点击周围区域隐藏
    // $(document)
    //   //   .off("click")
    //   .on("mousedown", function (e) {
    //     let _con = $(".translate-main");
    //     if (!_con.is(e.target) && _con.has(e.target).length === 0) {
    //       self.hide();
    //     }
    //   });
  // },
  methods: methods,
};
</script>

<style lang="scss">
@import "./index";
</style>