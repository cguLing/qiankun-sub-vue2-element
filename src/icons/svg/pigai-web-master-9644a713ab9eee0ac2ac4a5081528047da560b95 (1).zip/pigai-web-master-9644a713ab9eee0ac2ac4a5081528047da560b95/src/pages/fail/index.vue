<template>
<div id="networkerPage">
   <!-- <img src="./imgs/networker_pic_NoNetwork.png" class="test"/> -->
   <div class="picTips"></div>
   <p class="txtTips">暂无网络连接</p>
   <em v-if="code">{{ code }}</em>
</div> 
</template>
<script>
import coder from './methods/coder.js';
export default {
  data (){
    return {
      code : ''
    }
  },
  created(){
    var code = this.$utils.getQueryString().code;
    if(code){
      this.code = coder[code] || '';
    }
  }
}  
</script>
<style lang="scss">
#networkerPage{
  position: relative;
  width:100%;
  height:100%;
  /*.test{
     display:block;
     width: 225px;
     height:129px;
     margin:144px auto 0;
     border:1px solid red;
   }*/

  .picTips{
    display:block;
    width: 225px;
    height:129px;
    margin:144px auto 0;
    background: url('./imgs/networker_pic_NoNetwork.png') no-repeat center center;
    background-size:100% 100%;
  }
  .txtTips{
    text-align:center;
    font-size: 15px;
    color: #333333;
    padding-top:16px;  
  }
  em{
    margin-top: 10px;
    display: block;
    color: #c7c7c7;
    text-align:center;
  }    
}   
</style>