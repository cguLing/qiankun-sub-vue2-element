<template>
  <div
    id="home-page"
    v-infinite-scroll="loadMore"
    infinite-scroll-disabled="busy"
    infinite-scroll-distance="50"
    @scroll="hide"
  >
    <!--头部-->
    <div class="header-container">
      <div class="logo-container" @click="toHomepage">
        <div class="logo-image"></div>
        <div class="logo-text">有道写作</div>
      </div>
      <div class="info-container">
        <!-- <i class="download" @click="toDownload"></i> -->
        <!-- <span @click="toDownload">下载</span> -->
        <i class="personal" @click.stop="dorpdown"></i>
        <span class="user" @click.stop="dorpdown">{{ username }}</span>
        <i class="arrow-down" @click.stop="dorpdown"></i>
        <div class="dropdown" v-show="dorpdownActive">
          <div class="dropdown-item" @click="logout">退出登录</div>
          <div class="dropdown-item" @click.stop="writeOff">账户注销</div>
          <div class="writeOffDetail" v-show="isShowWriteOffDetail" @click.stop="">
            <p>您可以通过发送注销邮件至客服邮箱</p>
            <p>
              <a href="mailto:youdaowriting@corp.youdao.com"
                >youdaowriting@corp.youdao.com</a
              >
            </p>
            <p>以完成账户的注销。</p>
          </div>
        </div>
      </div>
    </div>
    <div class="content">
      <!--搜索-->
      <template>
        <div class="search-container">
          <input
            type="text"
            class="search"
            placeholder="请输入关键词搜索标题"
            v-model.trim="searchText"
            @keypress.enter="search"
          />
          <i class="search_icon" @click="search"></i>
        </div>
      </template>
      <!--新建-->
      <template>
        <div @click="createPigai" class="creatPigaiWrap">
          <i class="create"></i>
          <span>新建</span>
        </div>
      </template>
      <!--批改历史-->
      <transition-group tag="div">
        <pigaiItem
          v-for="(item, index) in pigaiHistory"
          :key="item.uniqueKey"
          :index="index"
          :uniqueKey="item.uniqueKey"
          :title="item.title || '未知标题-From移动端'"
          :content="item.content"
          :adviseCount="item.adviseCount"
          :type="item.type"
          :todayIndex="todayIndex"
          :yesterdayIndex="yesterdayIndex"
          :earlierIndex="earlierIndex"
          @showDeleteDialog="showDeleteDialog"
        ></pigaiItem>
      </transition-group>

      <!--删除某条批改历史时弹出窗-->
      <deleteDialog
        :is-show="status.isShowDeleteDialog"
        @close="hideDeleteDialog"
        @deleteHistory="deleteHistory"
      ></deleteDialog>
    </div>
  </div>
</template>


<script>
// import Config from 'config';
import * as methods from "./methods/index.js";
import * as time from "./methods/time.js";
import { mapState } from "vuex";
import Store from "@/commons/localStorage.js";
const pigaiItem = () =>
  import(/* webpackChunkName: "Undo" */ "./components/pigaiItem");
const deleteDialog = () =>
  import(/* webpackChunkName: "Undo" */ "./components/deleteDialog");

export default {
  data() {
    return {
      pigaiHistory: [],
      // 初始页数为1
      page: 1,
      searchText: "",
      // 无限滚动状态
      busy: false,
      status: {
        isShowDeleteDialog: false,
        currentSelectUniqueKey: "",
      },
      dorpdownActive: false,
      isFirstVisit: !Store.get("is_visited"),
      isShowWriteOffDetail: false,
    };
  },
  beforeRouteEnter(to, from, next) {
    // debugger
    ydk.rlog({
      action: "check_list",
      from: to.query.from || "",
      // success: next()
    });
    // setTimeout(() => {
    //   next();
    // }, 100);
    next();
  },
  beforeCreate() {
    // 检查登录状态，未登录返回登陆页面
    // this.$utils.checkLogin();
    const loginURL =
      "https://c.youdao.com/common-login-web/index.html?redirect_url=";
    ydk.isLogin({
      success: function (res) {
        // console.log(res);
        if (!res.isLogin) {
          console.log("未登录");
          window.location.href = loginURL + encodeURIComponent(document.URL);
        } else {
          console.log("已经登陆");
          Store.set("is_visited", true);
        }
      },
      fail: function () {
        window.location.href = loginURL + encodeURIComponent(document.URL);
      },
    });
  },
  created() {
    $("#loading").remove();
    this.$loading.show();

    // this.loadMore();
  },
  mounted() {
    this.$loading.hide();
    this.getUserInfo();
    document.addEventListener("click", () => {
      this.dorpdownActive = false;
      this.isShowWriteOffDetail = false;
    });
    // console.log(this.pigaiHistory.length)
    // if(!Store.get('is_visited')&&)
    // console.log("111");
    // Store.set("is_visited", true);
    // this.pigai()
  },
  methods: methods,
  components: {
    pigaiItem,
    deleteDialog,
  },
  computed: {
    todayIndex: function () {
      return this.pigaiHistory.findIndex((e) => {
        return time.isToday(e.correctTime);
      });
    },
    yesterdayIndex: function () {
      return this.pigaiHistory.findIndex((e) => {
        return time.isYesterday(e.correctTime);
      });
    },
    earlierIndex: function () {
      return this.pigaiHistory.findIndex((e) => {
        return time.isBeforeYesterday(e.correctTime);
      });
    },
    ...mapState({
      uniqueKey: (state) => state.global.uniqueKey, // 标识批改的key
      username: (state) => state.global.username, //用户昵称
    }),
  },
};
</script>


<style lang="scss">
@import "./index.scss";
</style>