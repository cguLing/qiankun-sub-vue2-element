export function isToday(unixTime) {
  let now = new Date()
  let nowTime = now.setHours(0, 0, 0, 0)
  return unixTime >= nowTime && unixTime < nowTime + 86400000
}

export function isYesterday(unixTime) {
  let now = new Date()
  let nowTime = now.setHours(0, 0, 0, 0)
  return unixTime >= nowTime - 86400000 && unixTime < nowTime
}

export function isBeforeYesterday(unixTime) {
  let now = new Date()
  let nowTime = now.setHours(0, 0, 0, 0)
  return unixTime < nowTime - 2 * 86400000
}
