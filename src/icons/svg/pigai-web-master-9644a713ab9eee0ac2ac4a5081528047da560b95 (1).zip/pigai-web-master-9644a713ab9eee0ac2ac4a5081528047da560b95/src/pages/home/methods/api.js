import $Http from '@/service/httpPigai.js';

export const listHistory = (params) => {
  const url = '/dictserver/writing/correct/listHistory'
  return $Http({
    method: 'GET',
    url,
    params
  })
}

export const delHistory = (data) => {
  const url = '/dictserver/writing/correct/delHistory'
  return $Http({
    method: 'POST',
    url,
    data
  })
}

export const submitDemo = () => {
  console.log('update_demo')
  const url = '/dictserver/writing/correct/submit'
  return $Http({
    method: 'POST',
    url,
    data: {
      isActionCacheMode: true,
      title: 'This is a demo',
      text: "I'm glad to know that you come to my city at the summer vacation. However, I'm afraid there're some bad news. I'm planning to participate in an international conference to held in another city during the time of you visit, All the top scientist in my field will show up at the conference. More importantly, I'm fortunate enough tp have been selected to give a speech on behalf of my research team at the conference. So I really can't miss it.",
      stLevel: 0,
      keyfrom: 'web1.0',
    }
  })
}

export const saveDraft = (data) => {
  const url = '/dictserver/writing/correct/saveDraft'
  return $Http({
    method: 'POST',
    url,
    data
  })
}
export const getUserNickname = () => {
  const url = '/profile/nickname/my'
  return $Http({
    method: 'GET',
    url
  })
}

export const logout = () => {
  const url = 'login/acc/se/reset'
  return $Http({
    method: 'POST',
    url,
    data: {
      product: 'DICT',
      app: 'web',
      keyfrom: 'pigai.web'
    }
  })
}
