<template>
  <div>
    <div class="before-text" v-if="index===todayIndex">今天</div>
    <div class="before-text" v-if="index===yesterdayIndex">昨天</div>
    <div class="before-text" v-if="index===earlierIndex">更早</div>
    <div class="pigai-wrap" @click="toPigai">
      <div class="pigai-left">
        <div v-if="type===0" class="draft">草稿</div>
        <div v-else-if="adviseCount===0" class="noFault">
          <i class="correct"></i>
        </div>
        <div v-else class="fault">{{adviseCount>99?'99+':adviseCount}}</div>
      </div>
      <div class="pigai-right">
        <div class="pigai-title" v-html="title"></div>
        <i class="del-btn" @click="del"></i>
        <div class="pigai-text" v-html="content"></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    index: {
      type: Number,
      required: true,
    },
    uniqueKey: {
      type: String,
      required: true,
    },
    adviseCount: {
      type: Number,
      required: false,
      default: 2,
    },
    title: {
      type: String,
      // required: false,
      default: "Deafult",
    },
    content: {
      type: String,
      required: true,
    },
    type: {
      type: Number,
      required: true,
    },
    todayIndex: {
      type: Number,
      required: true,
    },
    yesterdayIndex: {
      type: Number,
      required: true,
    },
    earlierIndex: {
      type: Number,
      required: true,
    },
  },
  data() {
    return {};
  },
  methods: {
    toPigai: function toPigai() {
      this.$store.dispatch("setUniqueKey", this.uniqueKey);
      this.$router.push("/index");
      ydk.rlog({
        action: "check_detail",
        type: "record",
      });
    },
    del: function showDeleteDialog(e) {
      e.stopPropagation();
      this.$emit("showDeleteDialog", this.uniqueKey);
      ydk.rlog({
        action: "check_list_delete",
      });
    },
  },
};
</script>

<style lang="scss">
@import "./index.scss";
</style>

