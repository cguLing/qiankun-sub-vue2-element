<template>
  <div class="dialog">
    <div class="dialog-cover back" v-if="isShow"></div>
    <transition name="drop">
      <!--style 通过props 控制内容的样式  -->
      <div class="dialog-content" v-if="isShow">
        <i class="close-btn" @click="closeMyself"></i>
        <div class="dialog-main">
          <!--弹窗的内容-->
          确定要删除该条批改记录吗？
        </div>
        <!--弹窗关闭按钮-->
        <div class="foot-cancel" @click="closeMyself">我再想想</div>
        <div class="foot-comfirm" @click="comfirmDelete">确定删除</div>
      </div>
    </transition>
  </div>
</template>

<script>
export default {
  props: {
    isShow: {
      type: Boolean,
      required: true,
    },
  },
  methods: {
    closeMyself() {
      this.$emit('close');
    },
    comfirmDelete() {
      this.$emit('deleteHistory');
    },
  },
};
</script>

<style lang="scss">
@import "./index.scss";
</style>