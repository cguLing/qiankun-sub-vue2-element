import * as api from './api.js'
// 获取用户历史批改记录
export function getUserHistory(params) {
  return api.listHistory(params).then(res => res.data)
}

//删除批改记录 
export function deleteHistory() {
  this.status.isShowDeleteDialog = false
  let uniqueKey = this.status.currentSelectUniqueKey
  api.delHistory({
    uniqueKey
  }).then(() => {
    this.pigaiHistory.splice(this.pigaiHistory.findIndex(item => item.uniqueKey === uniqueKey), 1)
  })
}

export function toDownload() {
  window.open('../download.html')
}

export function toHomepage() {
  window.location.href = '../index.html'
}

// 获取用户信息
export function getUserInfo() {
  api.getUserNickname().then(res => {
    if (res.data.error === 0) {
      this.$store.dispatch('setUsername', res.data.nickname)
    } else {
      const loginURL = 'https://c.youdao.com/common-login-web/index.html?redirect_url='
      window.location.href = loginURL + encodeURIComponent(document.URL)
    }
  })
}


// 创建新的批改
export function createPigai() {
  if(!navigator.onLine){
    ydk.toast({
      msg:'当前网络不可用，请检查您的网络设置'
    })
    return
  }
  this.$store.dispatch('setUniqueKey', '')
  this.$router.push('/index')
  ydk.rlog({
    action: 'check_detail',
    type: 'new'
  })
}

// 显示确认删除弹出框
export function showDeleteDialog(uniqueKey) {
  console.log(uniqueKey)
  this.status.isShowDeleteDialog = true
  this.status.currentSelectUniqueKey = uniqueKey
}

// 隐藏确认删除弹出框
export function hideDeleteDialog() {
  this.status.isShowDeleteDialog = false
  this.status.currentSelectUniqueKey = ''
}

// 滚动加载更多
export function loadMore() {
  this.busy = true;
  let params = {
    page: this.page,
    pageSize: 5
  }
  if (this.searchText !== '') {
    params.title = this.searchText
  }
  api.listHistory(params).then(res => {
    this.pigaiHistory = this.pigaiHistory.concat(res.data.data.historyList);
    this.page += 1
    if (res.data.data.hasMore) {
      this.busy = false;
    }
    // res.data.data.historyList.map(his=>{
    //   api.delHistory({
    //     uniqueKey:his.uniqueKey
    //   })
    // })


    this.$nextTick(() => {
      if (this.pigaiHistory.length === 0 && this.isFirstVisit) {
        // console.log(this.pigaiHistory.length, this.isFirstVisit)
        api.submitDemo().then(() => {
          api.listHistory({}).then(res => {
            this.pigaiHistory = this.pigaiHistory.concat(res.data.data.historyList)
          })
        });
      }
    });
  })
}

// 根据输入框重新获取批改历史
export function search() {
  this.page = 1
  this.pigaiHistory = []
  this.loadMore()
  ydk.rlog({
    action: 'check_search'
  })
}

// 退出登录
export function logout() {
  api.logout().then(() => {
    sessionStorage.clear()
    window.location.href = '../index.html'
  })
}

// 下拉
export function dorpdown() {
  this.dorpdownActive = !this.dorpdownActive
}

export function writeOff(){
  this.isShowWriteOffDetail = true
}
export function hide(){
  this.isShowWriteOffDetail = false
  this.dorpdownActive = false
}