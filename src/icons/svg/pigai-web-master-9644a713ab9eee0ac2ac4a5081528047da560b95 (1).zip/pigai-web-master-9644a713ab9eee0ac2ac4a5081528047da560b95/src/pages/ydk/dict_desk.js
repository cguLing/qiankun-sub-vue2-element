/*eslint-disable */
import * as msger from 'modules/debug_msg';

export function start(){
  
    var buttonTest = (options) => {
      var params = options.params || {};
      var tc = options.tc;
      var $span = $('<span></span>');
      var $span2 = $('<span></span>');
      var btn = $('<button>'+options.title+'</button>');
      btn.click(function (e){
        console.log('------------options.api');
        console.log(options.api);
        $span.html('<p>输入：' + tc.code(params) + '</p>');
        var _start = _.now();
        
        ydk[options.api](_.extend(params , {
          complete: function (res) {
            msger.log(['ydk.' + options.api + '耗时 ：<em>' + (_.now() - _start) +'</em>']);
            tc.updateStatus(res.code);
            if(options.output !== false){
              $span2[options.append === false ? 'html' : 'append']('<p>输出：' + tc.code(res) + '消耗时间：<em>' + (_.now() - _start) +'</em></p>')
            }
          }
        }));
      })
      tc.append(btn);
      tc.append($span);
      tc.append($span2);
      if(options.output === false){
        tc.append('<p>这个没有返回值</p>') 
      }
    }


    describe('- 以下 API 为PC项目的定制 -', '', function (tc) {
      tc.mod.addClass('mod-header')
    })


    describe('ydk.getKeyword', '获取客户端当前查询关键字和语言', function (tc) {
      tc.append('<p>输入：' + tc.code({}) + '</p>')
      // ydk.getKeyword({
      //   complete: function (res) {
      //     tc.updateStatus(res.code)
      //     tc.append('<p>输出：' + tc.code(res) + '</p>')
      //   }
      // })
    });


    describe('ydk.setKeyword', '设置客户端输入条关键字', function (tc) {

      var $span = $('<span></span>')
      var params = {
          keyword: 'test',
          lang : 'en'
      }
      var btn = $('<button>点击设置native输入条关键字</button>');
      tc.append(btn)
      btn.click(function (e){
        params.keyword = 'test '+ (new Date().getTime())
        $span.html('<p>输入：' + tc.code(params) + '</p>')
        ydk.setKeyword(params);
      })

      tc.append($span)
      //ydk.setKeyword(params);
      tc.append('<p>这个没有返回值</p>')
    })


    describe('ydk.onKeywordChanged', '监听关键字变化，onKeyUp', function (tc) {
      var $span = $('<p>等待关键字变化......</p>');
      tc.append($span)
      ydk.onKeywordChanged({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出：' + tc.code(res) + '</p>')
        }
      })
    });

    describe('ydk.onKeywordSubmit', '监听关键字输入完成，onChange', function (tc) {
      var $span = $('<p>监听关键字输入完成......</p>');
      tc.append($span)
      ydk.onKeywordSubmit({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出：' + tc.code(res) + '</p>')
        }
      })
    });

    describe('ydk.setNativeTab', '设置客户端左侧激活的TAB', function (tc) {
        var index = 0;
        //查词翻译 、 单词本、 精品课、 人工翻译
        var key = ['DictTab' , 'WordBookTab' , 'ClassTab' , 'ManualTransTab'];
        var $span = $('<span></span>')
        var params = {
        }
        var btn = $('<button>点击设置客户端左侧激活的TAB</button>');
        tc.append(btn)
        btn.click(function (e){
            params.key = key[index++ % key.length];
            $span.html('<p>输入：' + tc.code(params) + '</p>')
            ydk.setNativeTab(params);
        })

        tc.append($span)
        //ydk.setKeyword(params);
        tc.append('<p>这个没有返回值</p>')
    })

    describe('ydk.simulateClick', '设置客户端左侧激活的TAB', function (tc) {
        var index = 0;
        //查词翻译 、 单词本、 精品课、 人工翻译
        var key = ['DictTab' , 'WordBookTab' , 'ClassTab' , 'ManualTransTab'];
        var $span = $('<span></span>')
        var params = {
        }
        var btn = $('<button>点击设置客户端左侧激活的TAB</button>');
        tc.append(btn)
        btn.click(function (e){
            params.key = key[index++ % key.length];
            $span.html('<p>输入：' + tc.code(params) + '</p>')
            ydk.simulateClick(params);
        })

        tc.append($span)
        // ydk.setKeyword(params);
        tc.append('<p>这个没有返回值</p>')
    })

    describe('ydk.onTriggerNativeEvent', '监听客户端事件', function (tc) {
      var $span = $('<p>监听客户端事件......</p>');
      tc.append($span)
      ydk.onTriggerNativeEvent({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出：' + tc.code(res) + '</p>')
        }
      })
    });



    /*describe('ydk.getInfoLineData', '获取信息流数据', function (tc) {
        var params = {
        }
        tc.append('<p>输入：' + tc.code(params) + '</p>')
        ydk.getInfoLineData(_.extend(params , {
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        }));
    });*/

    /*describe('ydk.loadMainURL', '设置客户端主窗口URL', function (tc) {
        var index = 0;
        //查词、百科，例句 翻译 单词本 学堂 设置
        var $span = $('<span></span>')
        var params = {
            url : 'frame://fanyi.html'
        }
        var btn = $('<button>设置客户端主窗口frame://fanyi.html</button>');
        tc.append(btn)
        btn.click(function (e){
            $span.html('<p>输入：' + tc.code(params) + '</p>')
            ydk.loadMainURL(params);
        })

        tc.append($span)
        tc.append('<p>这个没有返回值</p>')
    })*/

    describe('ydk.getDictResult', '获取查词结果', function (tc) {

      var params1 = { //getDictResult 接口默认查询本地结果
       data : {
        keyword: 'good',
        lang : 'en'
       }
      }
      buttonTest({
        tc : tc,
        params : params1,
        api : 'getDictResult',
        title : '获取查词结果',
        append : false
      })

      var params3 = {
        data : {
          keyword: 'good',
          lang : 'en',
          type : 'quick'
        }
      }
      buttonTest({
        tc : tc,
        params : params3,
        api : 'getDictResult',
        title : '获取查词结果 - quick',
        append : false
      })

      var params2 = {
        data : {
          keyword: 'good',
          lang : 'en',
          type : 'detail',
          dicts : '{"count":9,"dicts":[["ec","ce","cj","jc","ck","kc","cf","fc"],["pic_dict"],["collins","ec21","ce_new"],["web_trans","special","ee","hh"],["phrs","syno","rel_word"],["blng_sents_part","media_sents_part","auth_sents_part"],["baike"],["fanyi"],["typos"]]}'
        }
      }
      buttonTest({
        tc : tc,
        params : params2,
        api : 'getDictResult',
        title : '获取查词结果 - detail',
        append : false
      });
      var params4 = {
        data : {
          keyword: 'good',
          lang : 'en',
          type : 'mini',
          dicts : '{"count":4,"dicts":[["ec","ce","cj","jc","ck","kc","cf","fc"],["web_trans"],["fanyi"],["typos"]]}'
        }
      }
      buttonTest({
        tc : tc,
        params : params4,
        api : 'getDictResult',
        title : '获取查词结果 - mini',
        append : false
      })

      var params5 = {
        data : {
          keyword: 'abnormal',
          lang : 'en',
          type : 'ldetail'
        }
      }
      buttonTest({
        tc : tc,
        params : params5,
        api : 'getDictResult',
        title : '本地详细查询 - ldetail',
        append : false
      })

      
    });


    describe('ydk.getTranslateResult', '获取网络翻译结果', function (tc) {
        var params = {
          data : {
            keyword: 'thank you very much',
            from : 'auto',
            to : '',
            keyfrom : 'deskdict.main'
          }
        }
        buttonTest({
          tc : tc,
          params : params,
          api : 'getTranslateResult',
          title : '获取网络翻译结果',
          append : false
        })

    });

    describe('ydk.getTranslateResult', '获取本地翻译结果', function (tc) {
        var params = {
          data : {
            keyword: '你是谁',
            from : 'zh-CHS',
            to : 'en',
            keyfrom : 'deskdict.main',
            type : 'local'
          }
        }
        buttonTest({
          tc : tc,
          params : params,
          api : 'getTranslateResult',
          title : '获取本地翻译结果',
          append : false
        })

    });    

    describe('ydk.getSimsentResult', '获取相似例句结果', function (tc) {
        var params = {
          data : {
            keyword: 'built'
          }
        }
        buttonTest({
          tc : tc,
          params : params,
          api : 'getSimsentResult',
          title : '获取相似例句结果',
          append : false
        })
    });



    describe('ydk.getSetting', '获取客户端设置', function (tc) {
        var params = {
        }
        tc.append('<p>输入：' + tc.code(params) + '</p>')
        ydk.getSetting(_.extend(params , {
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        }));
    });

    describe('ydk.saveSetting', '保存客户端设置', function (tc) {
      var $span = $('<span></span>')
      var btn = $('<button>保存</button>');
      tc.append(btn)
      btn.click(function (e){
        ydk.getSetting({
          success : function(res){
            var params = res.data;
            tc.append('<p>输入：' + tc.code(params) + '</p>')
            ydk.saveSetting({
              setting : params,
              complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
              }
            });
          }
        })
      })

      tc.append($span)
    });


    describe('ydk.closeSuggest', '关闭关键字自动完成窗口', function (tc) {
        var $span = $('<span></span>')
        var params = {
        }
        var btn = $('<button>设置关闭</button>');
        tc.append(btn)
        btn.click(function (e){
            $span.html('<p>输入：' + tc.code(params) + '</p>')
            ydk.closeSuggest(params);
        })

        tc.append($span)
        tc.append('<p>这个没有返回值</p>')
    });

    describe('ydk.onNativeKeyDown', '监听客户端键盘事件', function (tc) {
        var $span = $('<p>监听客户端键盘事件(up、down、enter)......</p>');
        tc.append($span)
        ydk.onNativeKeyDown({
            complete: function (res) {
                tc.updateStatus(res.code);
                $span.html('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });

    describe('ydk.copyToClipboard', '复制到剪贴板', function (tc) {
        var index = 0;
        var $span = $('<span></span>')
        var params = {

        }
        var btn = $('<button>点击复制</button>');
        tc.append(btn)
        btn.click(function (e){
            params.content = 'test '+ (new Date().getTime())
            $span.html('<p>输入：' + tc.code(params) + '</p>')
            ydk.copyToClipboard(params);
        })

        tc.append($span)
        tc.append('<p>这个没有返回值</p>')
    });




    describe('ydk.broadcast', '广播消息', function (tc) {
        var index = 0;
        var $span = $('<span></span>')
        var params = {
            type : 'test',
            format : 'string'
        }
        var btn = $('<button>点击广播</button>');
        tc.append(btn)
        btn.click(function (e){
            params.data = 'broadcast '+ (new Date().getTime())
            $span.html('<p>输入：' + tc.code(params) + '</p>')
            ydk.broadcast(params);
        })

        tc.append($span)
        tc.append('<p>这个没有返回值</p>')
    });

    describe('ydk.onBroadcast', '监听广播的消息', function (tc) {
        var $span = $('<p>监听广播的消息</p>');
        tc.append($span)
        ydk.onBroadcast({
            complete: function (res) {
                tc.updateStatus(res.code);
                $span.html('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });

    describe('ydk.setHasHistory', '设置是否有历史记录', function (tc) {
        var index = 0;
        var $span = $('<span></span>')
        var params = {
            has : true
        }
        var btn = $('<button>设置有历史记录</button>');
        tc.append(btn)
        btn.click(function (e){
            $span.html('<p>输入：' + tc.code(params) + '</p>')
            ydk.setHasHistory(params);
        })

        tc.append($span)
        tc.append('<p>这个没有返回值</p>')
    });

    describe('ydk.onHistory', '显示客户端的窗口', function (tc) {
        var $span = $('<p>显示客户端的窗口</p>');
        tc.append($span)
        ydk.onHistory({
            complete: function (res) {
                tc.updateStatus(res.code);
                $span.html('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });

    describe('ydk.onCornerPopupShow', '监听右下角弹窗', function (tc) {
        var $span = $('<p>监听右下角弹窗</p>');
        tc.append($span)
        ydk.onCornerPopupShow({
            complete: function (res) {
                tc.updateStatus(res.code);
                $span.html('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });

    describe('ydk.showCornerPopup', '展示右下角弹窗', function (tc) {
        var $span = $('<span></span>')
        var params = {
        }
        var btn = $('<button>显示</button>');
        tc.append(btn)
        btn.click(function (e){
            $span.html('<p>输入：' + tc.code(params) + '</p>')
            ydk.showCornerPopup(params);
        })

        tc.append($span)
        tc.append('<p>这个没有返回值</p>')
    });


    describe('ydk.onStrokeResult', '展示划词页面', function (tc) {
        var $span = $('<p>展示划词页面</p>');
        tc.append($span)
        ydk.onStrokeResult({
            complete: function (res) {
                tc.updateStatus(res.code);
                $span.html('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });

    describe('ydk.setStroke', '设置划词关键字和语言', function (tc) {
        var $span = $('<span></span>')
        var params = {
            keyword : 'good',
            lang : 'en'
        }
        var btn = $('<button>设置划词关键字和语言</button>');
        tc.append(btn)
        btn.click(function (e){
            $span.html('<p>输入：' + tc.code(params) + '</p>')
            ydk.setStroke(params);
        })
    });



    describe('ydk.closeWin', '关闭/隐藏当前CEF窗口', function (tc) {
        var $span = $('<span></span>')
        var params = {
          type : 'Wordbook', // 8.0 加上了类型参数，改为通用接口
        }
        var btn = $('<button>关闭</button>');
        tc.append(btn)
        btn.click(function (e){
            $span.html('<p>输入：' + tc.code(params) + '</p>')
            ydk.closeWin(params);
        })

        tc.append($span)
        tc.append('<p>这个没有返回值</p>')
    });

    describe('ydk.checkUpdate', '检测更新', function (tc) {
        var $span = $('<span></span>')
        var params = {
        }
        var btn = $('<button>检测更新</button>');
        tc.append(btn)
        btn.click(function (e){
            $span.html('<p>输入：' + tc.code(params) + '</p>')
            ydk.checkUpdate(params);
        })

        tc.append($span)
        tc.append('<p>这个没有返回值</p>')
    });

    describe('ydk.onSettingChange', '通知设置项变更', function (tc) {
      var $span = $('<span></span>');
      tc.append($span)
      ydk.onSettingChange({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出：' + tc.code(res) + '</p>')
        }
      })
    });

    describe('ydk.setTop', '激活词典，置于最前', function (tc) {
      var $span = $('<span></span>')
      var params = {
      }
      var btn = $('<button>置于最前</button>');
      tc.append(btn)
      btn.click(function (e){
        $span.html('<p>输入：' + tc.code(params) + '</p>')
        ydk.setTop(params);
      })

      tc.append($span)
      tc.append('<p>这个没有返回值</p>')
    });


    describe('ydk.checkWordBook', '检查单词是否添加到单词本', function (tc) {
      var params = {
        word : 'good',
        lang : 'en'
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'checkWordBook',
        title : '检查单词是否添加到单词本'
      })
    });

    describe('ydk.addToWordBook', '添加到单词本', function (tc) {
      var params = {
        word : 'good',
        lang : 'en',
        phonetic : 'ɡʊd',
        category : '分组1',
        trans : 'adj. 好的；优良的；愉快的；虔诚的;\r\nn. 好处；善行；慷慨的行为',
        plan : true,//加入复习计划
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'addToWordBook',
        title : '添加到单词本',
        output : false
      })
    });

    describe('ydk.updateToWordBook', '修改单词本', function (tc) {
      var params = {
        word : 'good',
        lang : 'en',
        phonetic : 'ɡʊd',
        category : '分组2',
        trans : '11111111111111',
        plan : false,
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'updateToWordBook',
        title : '修改单词本'
      })
    });

    describe('ydk.removeFromWordBook', '从单词本删除', function (tc) {
      var params = {
        data : [{
          word : 'good',
          lang : 'en'
        }]
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'removeFromWordBook',
        title : '从单词本删除',
        output : false
      })
    });

    describe('ydk.queryWordBook', '读取单词本记录', function (tc) {
      var params = {
        start : 0,
        size : 29000,
        category : '*',
        order : 'timenew'
      }
     buttonTest({
        tc : tc,
        params : params,
        api : 'queryWordBook',
        title : '读取单词本记录',
        append : false
      })
    });


    describe('ydk.syncWordBook', '同步单词本', function (tc) {
      var params = {}
      buttonTest({
        tc : tc,
        params : params,
        api : 'syncWordBook',
        title : '同步单词本'
      })
    });


    describe('ydk.onWordBookChanged', '单词本变化', function (tc) {
      var $span = $('<span></span>');
      tc.append($span);
      ydk.onWordBookChanged({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出：' + tc.code(res) + '</p>')
        }
      })
    });


    describe('ydk.simpleWordbookChange', '单词本变化', function (tc) {
      var $span = $('<span></span>');
      tc.append($span);
      ydk.simpleWordbookChange({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出：' + tc.code(res) + '</p>')
        }
      })
    });

    describe('ydk.queryWordBookCategory', '读取单词本分组', function (tc) {
      var params = {}
      buttonTest({
        tc : tc,
        params : params,
        api : 'queryWordBookCategory',
        title : '读取单词本分组',
        append : false
      })
    });

    describe('ydk.addWordBookCategory', '新增单词本分组', function (tc) {
      var params = {
        name : '分组1'
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'addWordBookCategory',
        title : '新增单词本分组'
      })
    });

    describe('ydk.updateWordBookCategory', '更新单词本分组', function (tc) {
      var params = {
        name : '分组1',
        newname : '新分组'
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'updateWordBookCategory',
        title : '更新单词本分组'
      })
    });

    describe('ydk.removeWordBookCategory', '删除单词本分组', function (tc) {
      var params = {
        name : '分组1',
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'removeWordBookCategory',
        title : '删除单词本分组'
      })
    });

    describe('ydk.importToWordBook', '导入单词本', function (tc) {
      var params = {
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'importToWordBook',
        title : '导入单词本',
      })
    });

    describe('ydk.exportFromWordBook', '导出单词本', function (tc) {

      var params = {
        category : '*',
        order : 'timenew'
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'exportFromWordBook',
        title : '导出单词本',
      })

    });
    describe('ydk.cancleExportFromWordBook', '取消导出单词本', function (tc) {
      var params = {
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'cancleExportFromWordBook',
        title : '取消导出单词本',
      })
      tc.append('<p>这个没有返回值</p>')
    });

    describe('ydk.queryWordBookForReview', '读取需要复习的单词', function (tc) {
      var params = {
        start: 0,
        size: 1,
        disorder : false,
        category: 'test',
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'queryWordBookForReview',
        title : '读取需要复习的单词',
        append : false
      })
    });


    describe('ydk.setWordBookCategory', '批量修改单词分组', function (tc) {
      var params = {
        data : [
          {word : 'good' , lang : 'en'} , 
          {word : 'hello' , lang : 'en'} 
        ],
        category : '分组1',
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'setWordBookCategory',
        title : '批量修改单词分组',
      })
    });

    describe('ydk.setWordBookPlan', '设置单词是否加入复习计划', function (tc) {
      var params1 = {
        data : [
            {word : 'good' , lang : 'en'} , 
            {word : 'hello' , lang : 'en'} 
        ],
        plan : true
      };
      var params2 = {
        data : [
            {word : 'good' , lang : 'en'} , 
            {word : 'hello' , lang : 'en'} 
        ],
        plan : false
      };
      buttonTest({
        tc : tc,
        params : params1,
        api : 'setWordBookPlan',
        title : '加入复习计划',
      });

      buttonTest({
        tc : tc,
        params : params2,
        api : 'setWordBookPlan',
        title : '退出入复习计划',
      });
    });

    describe('ydk.reviewWordBook', '单词本复习单词', function (tc) {
      var params1 = {
        data : [
            {word : 'good' , lang : 'en'} ,
        ],
        remember : true
      };
      var params2 = {
        data : [
            {word : 'good' , lang : 'en'} ,
        ],
        remember : false
      };
      buttonTest({
        tc : tc,
        params : params1,
        api : 'reviewWordBook',
        title : '复习单词-记得',
      })
      buttonTest({
        tc : tc,
        params : params2,
        api : 'reviewWordBook',
        title : '复习单词-不记得',
      })
    });

    describe('ydk.minimizeWin', '最小化当前CEF窗口', function (tc) {
      var params = {
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'minimizeWin',
        title : '最小化当前CEF窗口',
        output : false
      })
    });

    describe('ydk.setDebug', '开启debug模式', function (tc) {
      var $span = $('<span></span>')
      var btn1 = $('<button>开启debug模式</button>');
      var btn2 = $('<button>开启debug模式</button>');
      tc.append($span);
      tc.append(btn1);
      tc.append(btn2);

      btn1.click(function (e){
        var params = {
            debug : true
        };
        $span.html('<p>输入：' + tc.code(params) + '</p>')
        ydk.setDebug(params);
      })
      btn2.click(function (e){
        var params = {
            debug : false
        };
        $span.html('<p>输入：' + tc.code(params) + '</p>')
        ydk.setDebug(params);
      })

      tc.append($span)
      tc.append('<p>这个没有返回值</p>')
    });

    describe('ydk.setWinHeight', '设置窗口高度', function (tc) {
      var params = {
        height : 300,
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'setWinHeight',
        title : '设置窗口高度',
        output : false
      })
    });

    describe('ydk.setWinSize', '设置窗口宽高', function (tc) {
      var params = {
        height : 300,
        width : 200
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'setWinSize',
        title : '设置窗口宽高',
        output : false
      })
    });

    describe('ydk.setWinMove', '设置窗口可移动', function (tc) {
      var params = {
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'setWinMove',
        title : '设置窗口可移动',
        output : false
      })
    });

    describe('ydk.showWin', '显示当前CEF窗口', function (tc) {
      var params = {
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'showWin',
        title : '显示当前CEF窗口',
        output : false
      })
    });

    describe('ydk.getOcrModelList', '获取OCR模型列表', function (tc) {
      var params = {
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'getOcrModelList',
        title : '获取OCR模型列表',
        append : false
      })
    });

    describe('ydk.downloadOcrModel', '下载/更新OCR模式文件', function (tc) {
      var params = {
        lang : 'ja'
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'downloadOcrModel',
        title : '下载/更新OCR模式文件',
      })
    });

    describe('ydk.removeOcrModel', '删除OCR模型文件', function (tc) {
      var params = {
        lang : 'ja'
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'removeOcrModel',
        title : '删除OCR模型文件',
      })
    });


    describe('ydk.onDownloadProgress', '下载进度', function (tc) {
      var $span = $('<p>等待下载进度变化......</p>');
      tc.append($span);
      ydk.onDownloadProgress({
        complete: function (res) {
            tc.updateStatus(res.code);
            $span.html('<p>输出：' + tc.code(res) + '</p>')
        }
      })
    });

    describe('ydk.downloadBrowserPlugin', '下载浏览器插件', function (tc) {
      var params1 = {
        browser : 'chrome'
      }
      buttonTest({
        tc : tc,
        params : params1,
        api : 'downloadBrowserPlugin',
        title : '下载chrome插件',
        output : false
      })
      var params2 = {
        browser : 'sogou'
      }
      buttonTest({
        tc : tc,
        params : params2,
        api : 'downloadBrowserPlugin',
        title : '下载sogou插件',
        output : false
      })
      var params3 = {
        browser : '360'
      }
      buttonTest({
        tc : tc,
        params : params3,
        api : 'downloadBrowserPlugin',
        title : '下载360插件',
        output : false
      })
      var params3 = {
        browser : 'pdf'
      }
      buttonTest({
        tc : tc,
        params : params3,
        api : 'downloadBrowserPlugin',
        title : '下载pdf插件',
        output : false
      })
    });


    describe('ydk.saveCache', '保存缓存', function (tc) {
      var params1 = {
        table : 'table1',
        key : 'test1',
        value : 'test value'
      }
      buttonTest({
        tc : tc,
        params : params1,
        api : 'saveCache',
        title : '保存到缓存',
        output : false
      })
    });


    describe('ydk.getCache', '读取缓存', function (tc) {
      var params1 = {
        table : 'table1',
        keys : ['test1' , 'test2']
      }
      buttonTest({
        tc : tc,
        params : params1,
        api : 'getCache',
        title : '读取缓存',
        append : false
      })
    });


    describe('ydk.removeCache', '删除缓存', function (tc) {
      var params1 = {
        table : 'table1',
        keys : ['test1' , 'test2']
      }
      buttonTest({
        tc : tc,
        params : params1,
        api : 'removeCache',
        title : '删除缓存',
        output : false
      })
    });

    describe('ydk.clearCache', '清空缓存', function (tc) {
      var params1 = {
        table : 'table1',
      }
      buttonTest({
        tc : tc,
        params : params1,
        api : 'clearCache',
        title : '清空缓存',
        output : false
      })
    });

    describe('ydk.openWin', '打开新窗口', function (tc) {
      var params = {
        src : 'html/index.html#/wordbook_edit?keyword=take&lang=en',
        title : '编辑单词'
      }
      buttonTest({
        tc : tc,
        params : params,
        api : 'openWin',
        title : '打开新窗口',
        output : false
      })
    });

    // 调用客户端音频播放
    var vLocalId = 'http://xue.youdao.com/zx/wp-content/uploads/2015/03/You-Belong-To-Me-Jason-Wade.mp3'
    //var vLocalId = 'http://zx.youdao.com/zx/wp-content/uploads/2015/03/start.mp3';
    describe('ydk.playNativeVoice', '播放音频', function (tc) {
      var params = {
        localId: vLocalId
      }

      buttonTest({
        tc : tc,
        params : params,
        api : 'playNativeVoice',
        title : '点击播放',
        append : false
      })
    });
    describe('ydk.stopNativeVoice', '停止播放', function (tc) {
      var params = {}
      buttonTest({
        tc : tc,
        params : params,
        api : 'stopNativeVoice',
        title : '停止播放',
        output : false
      })
    });
    describe('ydk.setQueryFocus', '设置搜索框焦点', function (tc) {
      var params = {}
      buttonTest({
        tc : tc,
        params : params,
        api : 'setQueryFocus',
        title : '设置搜索框焦点',
        output : false
      })
    })
    describe('ydk.setQuerySelectAll', '设置搜索框全选', function (tc) {
      var params = {}
      buttonTest({
        tc : tc,
        params : params,
        api : 'setQuerySelectAll',
        title : '设置搜索框全选',
        output : false
      })
    })

    describe('ydk.onLoginStatusChanged', '监听客户端登陆状态', function (tc) {
      var $span = $('<p>监听客户端登陆状态......</p>');
      tc.append($span)
      ydk.onLoginStatusChanged({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出：' + tc.code(res) + '</p>')
        }
      })
    })

    describe('ydk.onHotKey', '监听快捷键响应', function (tc) {
      var $span = $('<p>监听快捷键响应......</p>');
      tc.append($span)
      ydk.onHotKey({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出：' + tc.code(res) + '</p>')
        }
      })
    })

    describe('ydk.updateWinZOrder', '更新窗口排序', function (tc) {
        var $span = $('<span></span>')
        var params = {
        }
        var btn = $('<button>更新窗口排序</button>');
        tc.append(btn)
        btn.click(function (e){
            $span.html('<p>输入：' + tc.code(params) + '</p>')
            ydk.updateWinZOrder(params);
        })
        tc.append($span)
        tc.append('<p>这个没有返回值</p>')
    });

    describe('ydk.getOfflineLexiconList',' 获取离线词库', function (tc) {
      var params = {}
      buttonTest({
        tc : tc,
        params : params,
        api :  'getOfflineLexiconList',
        title : '获取离线词库',
        append : false
      })
    })

    describe('ydk.removeOfflineLexicon',' 删除离线词库', function (tc) {
      var params = {
        dict : 'YdBaseCE',
        name : '汉英超大离线词库'
      }
      buttonTest({
        tc : tc,
        params : params,
        api :  'removeOfflineLexicon',
        title : '删除离线词库',
        output : false
      })
    })


    describe('ydk.downloadOfflineLexicon',' 下载/更新离线词库', function (tc) {
      var params = {
        dict : 'YdBaseCE'
      }
      buttonTest({
        tc : tc,
        params : params,
        api :  'downloadOfflineLexicon',
        title : '下载/更新离线词库',
        append : false
      })
    })

    describe('ydk.onLoadOfflineLexiconProgress', '下载进度', function (tc) {
      var $span = $('<p>等待下载进度变化......</p>');
      tc.append($span);
      ydk.onLoadOfflineLexiconProgress({
        complete: function (res) {
            tc.updateStatus(res.code);
            $span.html('<p>输出：' + tc.code(res) + '</p>')
        }
      })
    });

    describe('ydk.stopLoadOfflineLexicon', '暂停/开始下载', function (tc) {
      var params = {
        dict : 'YdBaseCE',
        option: 'stop' // stop/start
      }
      buttonTest({
        tc : tc,
        params : params,
        api :  'stopLoadOfflineLexicon',
        title : '暂停/开始下载',
        append : false
      })
    });

    describe('ydk.clearHistory','清空历史记录', function (tc) {
      var params = {};
      buttonTest({
        tc : tc,
        params : params,
        api :  'clearHistory',
        title : '清空历史记录',
        output : false
      })
    })
    
    describe('ydk.setDictTabLayout','调整输入框布局', function (tc) {
      var params = {
        hasDictResult : true, //有查词结果就为true只有翻译为false
      };
      buttonTest({
        tc : tc,
        params : params,
        api :  'setDictTabLayout',
        title : '调整输入框布局',
        output : false
      })
    })


    describe('ydk.showTransResult', '文档翻译结果', function (tc) {
      var $span = $('<span></span>');
      tc.append($span);
      ydk.showTransResult({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出：' + tc.code(res) + '</p>')
        }
      })
    });

    describe('ydk.showWordbookCardModel','打开单词本卡片模式',function (tc) {
      var $span = $('<p>等待单词本模式变化......</p>');
      tc.append($span);
      ydk.showWordbookCardModel({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出: ' + tc.code(res) + '<p>')
        }
      })
    })

    describe('ydk.showWordbookDetail','展示单词本详细结果',function (tc) {
      var $span = $('<p>等待单词本模式变化......</p>');
      tc.append($span);
      ydk.showWordbookDetail({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出: ' + tc.code(res) + '<p>')
        }
      })
    })
    
    describe('ydk.showWordbookReviewModel','展示单词本复习模式',function (tc) {
      var $span = $('<p>等待单词本模式变化......</p>');
      tc.append($span);
      ydk.showWordbookReviewModel({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出: ' + tc.code(res) + '<p>')
        }
      })
    })

    // describe('ydk.showWordbookAdd','单词本添加单词页面',function (tc) {
    //   var $span = $('<p>等待单词本模式变化......</p>');
    //   tc.append($span);
    //   ydk.showWordbookAdd({
    //     complete: function (res) {
    //       tc.updateStatus(res.code);
    //       $span.html('<p>输出: ' + tc.code(res) + '<p>')
    //     }
    //   })
    // })

    describe('ydk.wordbookCardPlay','单词本播放卡片',function (tc) {
      var $span = $('<p>等待单词本卡片播放变化......</p>');
      tc.append($span);
      ydk.wordbookCardPlay({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出: ' + tc.code(res) + '<p>')
        }
      })
    })

    // describe('ydk.openWordBookExportPage','打开单词本导出',function (tc) {
    //   var $span = $('<p>等待打开导出页面变化......</p>');
    //   tc.append($span);
    //   ydk.openWordBookExportPage({
    //     complete: function (res) {
    //       tc.updateStatus(res.code);
    //       $span.html('<p>输出: ' + tc.code(res) + '<p>')
    //     }
    //   })
    // })

    // describe('ydk.openWordbookSettingPage','打开单词本设置',function (tc) {
    //   var $span = $('<p>等待打开单词本设置页......</p>');
    //   tc.append($span);
    //   ydk.openWordbookSettingPage({
    //     complete: function (res) {
    //       tc.updateStatus(res.code);
    //       $span.html('<p>输出: ' + tc.code(res) + '<p>')
    //     }
    //   })
    // })
    
    describe('ydk.newCefLoadingPage','客户端打开cef窗口',function (tc) {
      var $span = $('<p>等待打开cef窗口......</p>');
      tc.append($span);
      ydk.newCefLoadingPage({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出: ' + tc.code(res) + '<p>')
        }
      })
    })

  
    describe('ydk.wbLoadingPage','响应单词本加载页面',function (tc) {
      var $span = $('<p>等待单词本加载页面响应......</p>');
      tc.append($span);
      ydk.wbLoadingPage({
        complete: function (res) {
          tc.updateStatus(res.code);
          $span.html('<p>输出: ' + tc.code(res) + '<p>')
        }
      })
    })


    describe('ydk.loadDTResult', '加载文档翻译结果', function (tc) {
        var btn = $('<button>加载文档翻译结果</button>')
        tc.append(btn);
        btn.click(function(){
            var params = {
              key : '368D4ACDBC564608BCEBC034809ED01B',
              page : 1
            };    
            tc.append('<p>输入：' + tc.code(params) + '</p>')        
            ydk.loadDTResult(_.extend({}, params, {
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
    });

    describe('ydk.renderFinish', '设置渲染回调(测试用)', function (tc) {
        var btn = $('<button>设置渲染回调(测试用)</button>')
        tc.append(btn);
        btn.click(function(){
            var params = {
                requestId : 'requestId',
            };    
            tc.append('<p>输入：' + tc.code(params) + '</p>')        
            ydk.renderFinish(_.extend({}, params, {
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
    });

    describe('ydk.setTranslateContent', '设置翻译tab', function (tc) {
        var btn = $('<button>设置翻译tab</button>')
        tc.append(btn);
        btn.click(function(){        
            ydk.setTranslateContent({
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            })
        })
    });    

  describe('ydk.onTriggerWebEvent', '通知客户端前端事件', function (tc) {
    var btn = $('<button>通知客户端前端事件</button>')
    tc.append(btn);
    btn.click(function () {
      ydk.onTriggerWebEvent({
        key: 'document'
      })
    })
  }); 
  
  
  describe('ydk.getGrammarText', '获取客户端传过来批改数据', function (tc) {
    var btn = $('<button>获取客户端传过来批改数据</button>')
    tc.append(btn);
    btn.click(function () {
      ydk.getGrammarText({
        complete: function (res) {
          tc.updateStatus(res.code)
          tc.append('<p>输出：' + tc.code(res) + '</p>')
        }
      })
    })
  }); 

}