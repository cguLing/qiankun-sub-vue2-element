/*eslint-disable */

export function start(){

    describe('当前环境：', function (tc) {
      tc.subtitle.html(ydk.ni.features.jsbridge ? 'Native' : 'Web')
      tc.append('<p>' + navigator.userAgent + '</p>')
      tc.updateStatus(1000)
    });

    describe('ydk.config', '配置', function (tc) {
      var params = {
        debug: true,
        jsApiList: [

          'checkJsApi',
          'getClientInfo',
          'getNetworkType',
          'onNetStatusChange',
          'getOrientationStatus',
          'onOrientationChange',
          'share',
          'toast',

          'playVoice',
          'pauseVoice',
          'stopVoice',
          'onVoicePlayEnd',
          'onVoicePlayProgress',

          'startRecord',
          'stopRecord',
          'onVoiceRecordEnd',

          'chooseImage',
          'previewImage',
          'uploadImage',
          'downloadImage',

          'ajax',

          'isLogin',
          'login',
          'getUserInfo',
          'rlog',
          'onVipInfoGot',
          'refreshVipInfo',
          'getProfile',
          'setProfile',
          'checkNickname',
          'getNickname',
          'setNickname'
        ]
      }

      tc.append('<p>输入：' + tc.code(params) + '</p>')

      ydk.config(_.extend(params, {
        complete: function (res) {
          tc.updateStatus(res.code)
          tc.append('<p>输出：' + tc.code(res) + '</p>')
        }
      }))
    });

    describe('ydk.checkJsApi', '判断是否支持相应接口', function (tc) {
      var params = {
        jsApiList: [
          'ajax',

          'playVoice',
          'startRecord',
          'chooseImage',

          'getNetworkType',
          'isLogin',
          'onVipInfoGot',
          'refreshVipInfo',
          'getProfile',
          'setProfile',
          'checkNickname',
          'getNickname',
          'setNickname',      
        ]
      }

      tc.append('<p>输入：' + tc.code(params) + '</p>')

      ydk.checkJsApi(_.extend(params, {
        complete: function (res) {
          tc.updateStatus(res.code)
          tc.append('<p>输出：' + tc.code(res) + '</p>')
        }
      }))
    });

    // -----------------------------------------------------------------------------
    // ajax

    describe('ydk.ajax', '一般用法', function (tc) {
        var params = {
            url: 'http://dingzq.iyoudao.net/apis/ydk-ajax.php'
        }
        tc.append('<p>注意，测试地址要求公司内网</p>')
        tc.append('<p>输入：' + tc.code(params) + '</p>')

        ydk.ajax(_.extend(params, {
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        }))
    });

    describe('ydk.ajax', 'jsonp', function (tc) {
        var params = {
            url: 'http://dingzq.iyoudao.net/apis/ydk-ajax.php',
            dataType: 'jsonp'
        }

        tc.append('<p>输入：' + tc.code(params) + '</p>')

        ydk.ajax(_.extend(params, {
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        }))
    });


    describe('ydk.ajax', '检测fail功能', function (tc) {
        var params = {
            url: 'http://dingzq.iyoudao.net/apis/not-exist.php'
        }

        tc.append('<p>输入：' + tc.code(params) + '</p>')

        ydk.ajax(_.extend(params, {
            complete: function (res) {
                tc.updateStatus(res.code == 1002 ? 1000 : -1);
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        }))
    });
    // -----------------------------------------------------------------------------
    // 录音

    describe('ydk.startRecord', '开始录音', function (tc) {
        var btn = $('<button>点击开始录音</button>')
        tc.append(btn)
        btn.click(function (evt) {
            ydk.startRecord({
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            })
        })
    });
    var recordfile = null;
    describe('ydk.stopRecord', '停止录音', function (tc) {
        var btn = $('<button>点击停止录音</button>')
        tc.append(btn)
        btn.click(function (evt) {
            ydk.stopRecord({
                complete: function (res) {
                    recordfile = res.localId
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            })
        })
    });
    // res = {
    //     code: 1000,
    //     errMsg: "",

    //     localId: "string", // 本地地址
    //     duration: "float" // 总时长
    // }
    describe('ydk.onVoiceRecordEnd', '监听录音自动停止', function (tc) {
        tc.append('<p>等待有录音自动停止......</p>')
        ydk.onVoiceRecordEnd({
            complete : function(res){
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        });
    });

    describe('ydk.uploadVoice', '上传音频', function (tc) {
        var btn = $('<button>上传音频</button>')
        tc.append(btn)
        btn.on('click', function () {
            if (!recordfile) {
                alert('请先录制一段语音')
                return
            }
            ydk.uploadVoice({
                localId : recordfile,
                complete : function(res){
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            });
        })
    });

    // -----------------------------------------------------------------------------
    // 音频播放

    var vLocalId = 'http://xue.youdao.com/zx/wp-content/uploads/2015/03/You-Belong-To-Me-Jason-Wade.mp3'
    //var vLocalId = 'http://zx.youdao.com/zx/wp-content/uploads/2015/03/start.mp3';
    describe('ydk.playVoice', '播放音频', function (tc) {
        var params = {
            localId: vLocalId
        }
        var btn = $('<button>点击播放</button>')
        tc.append(btn)
        tc.append('<p>输入：' + tc.code(params) + '</p>')
        btn.click(function (evt) {
            ydk.playVoice(_.extend(params, {
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
    });
    describe('ydk.playVoice', '指定时间开始播放音频', function (tc) {
        var params = {
            localId: vLocalId,
            currentTime : 150
        }
        var btn = $('<button>点击播放</button>')
        tc.append(btn)
        tc.append('<p>输入：' + tc.code(params) + '</p>')
        btn.click(function (evt) {
            ydk.playVoice(_.extend(params, {
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
    });
    describe('ydk.pauseVoice', '暂停音频', function (tc) {
        var btn = $('<button>点击暂停</button>')
        tc.append(btn)
        btn.click(function (evt) {
            ydk.pauseVoice({
                localId: vLocalId,
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            })
        })
    });
    describe('ydk.stopVoice', '停止音频', function (tc) {
        var btn = $('<button>点击停止播放</button>')
        tc.append(btn)
        btn.click(function (evt) {
            ydk.stopVoice({
                localId: vLocalId,
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            })
        })
    });
    describe('ydk.onVoicePlayEnd', '监听播放完毕, 未指定ID', function (tc) {
        tc.append('<p>输入：' + tc.code({}) + '</p>')
        ydk.onVoicePlayEnd({
            complete : function(res){
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        });
    });
    describe('ydk.onVoicePlayEnd', '监听播放完毕，指定ID', function (tc) {
        tc.append('<p>输入：' + tc.code({localId: vLocalId}) + '</p>')
        ydk.onVoicePlayEnd({
            localId: vLocalId,
            complete : function(res){
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        });
    });
    describe('ydk.onVoicePlayProgress', '监听音频播放过程', function (tc) {
        var p = $('<p>输出：监听中。。。</p>')
        tc.append(p)
        ydk.onVoicePlayProgress({
            complete : function(res){
                tc.updateStatus(res.code)
                p.html('输出：' + tc.code(res))
            }
        });
    });


    // -----------------------------------------------------------------------------
    // 图片相关

    var _localIds = []

    describe('ydk.chooseImage', '拍照或从相册中选图', function (tc) {
        var btn = $('<button>点击拍照或选图</button>')
        tc.append(btn)
        tc.append('<p>输入：' + tc.code({}) + '</p>')
        btn.click(function (evt) {
            ydk.chooseImage({
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')

                    _localIds = res.localIds || []
                }
            })
        })
    });
    describe('ydk.previewImage', '预览图片', function (tc) {
        var btn = $('<button>点击预览图片</button>')
        tc.append(btn)
        var urls = [
            'http://oimagea6.ydstatic.com/image?id=-4224393815620890839&product=adpublish',
            'http://oimagea8.ydstatic.com/image?id=1563303607390488462&product=adpublish',
            'http://oimagea6.ydstatic.com/image?id=-2208400889207586435&product=adpublish'
        ]
        var params = {
            current: urls[0],
            urls: urls
        }
        tc.append('<p>微信下该 API 没有执行回调。。。</p>')
        tc.append('<p>默认输入：' + tc.code(params) + '</p>')
        btn.click(function (evt) {
            params.urls = [].concat(_localIds, urls)
            ydk.previewImage(_.extend(params, {
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
    });
    describe('ydk.uploadImage', '上传图片', function (tc) {
        var btn = $('<button>上传图片</button>')
        tc.append(btn)
        btn.click(function (evt) {
            if (!_localIds.length) {
                alert('请选择本地图片')
                return
            }
            ydk.uploadImage({
                localId: _localIds[0],
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                    if (res.serverId) {
                        _serverId = res.serverId
                    }
                }
            })
        })
    });
    var _serverId = "http://oimagec7.ydstatic.com/image?id=-4606017425187573964&product=xue";
    describe('ydk.downloadImage', '下载图片', function (tc) {
        var btn = $('<button>下载图片</button>')
        tc.append(btn)
        btn.click(function (evt) {
            if (!_serverId) {
                alert('请先成功上传一张图片')
                return
            }
            var params = {
                serverId: _serverId
            }
            tc.append('<p>输入：' + tc.code(params) + '</p>')
            ydk.downloadImage(_.extend(params, {
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
    });

    // -----------------------------------------------------------------------------

    describe('ydk.share', '一键分享', function (tc) {
        var btnWeixin = $('<button>微信好友</button>')
        var btnWeixinMoments = $('<button>微信朋友圈</button>')
        var btnQQ = $('<button>QQ</button>')
        var btnQQZone = $('<button>QQ 空间</button>')
        var btnWeibo = $('<button>微博</button>')
        var btnYixin = $('<button>易信好友</button>')
        var btnYixinQuan = $('<button>易信好友圈</button>')
        tc.append(btnWeixin)
        tc.append(btnWeixinMoments)
        tc.append(btnQQ)
        tc.append(btnQQZone)
        tc.append(btnWeibo)
        tc.append(btnYixin)
        tc.append(btnYixinQuan)
        var params = {
            // type : 'wechat_moments',
            title: '有道 YDK 分享测试 - 标题',
            desc: '有道 YDK 分享测试 - 描述信息',
            link: 'http://www.youdao.com',
            imgUrl: 'http://oimagec3.ydstatic.com/image?id=5606355977608992016&product=adpublish&w=150'
        }
        tc.append('<p>输入：' + tc.code(params) + '</p>')
        // type : "[qq|qq_zone|weibo|wechat|wechat_moments|yixin|yixinquan]",

        btnWeixin.click(function (evt) {
            ydk.share(_.extend({}, params, {
                type : 'wechat',
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })

        btnWeixinMoments.click(function (evt) {
            ydk.share(_.extend({}, params, {
                type : 'wechat_moments',
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
        btnQQ.click(function (evt) {
            ydk.share(_.extend({}, params, {
                type : 'qq',
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
        btnQQZone.click(function (evt) {
            ydk.share(_.extend({}, params, {
                type : 'qq_zone',
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
        btnWeibo.click(function (evt) {
            ydk.share(_.extend({}, params, {
                type : 'weibo',
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
        btnYixin.click(function (evt) {
            ydk.share(_.extend({}, params, {
                type : 'yixin',
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
        btnYixinQuan.click(function (evt) {
            ydk.share(_.extend({}, params, {
                type : 'yixinquan',
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
    });

    describe('ydk.getNetworkType', '网络类型', function (tc) {
        tc.append('<p>输入：' + tc.code({}) + '</p>')
        ydk.getNetworkType({
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });

    describe('ydk.onNetStatusChange', '监听网络状态变化', function (tc) {
        tc.append('<p>等待网络发生变化......</p>')
        ydk.onNetStatusChange({
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });

    describe('ydk.getOrientationStatus', '获取屏幕方向', function (tc) {
        tc.append('<p>输入：' + tc.code({}) + '</p>')
        ydk.getOrientationStatus({
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });

    describe('ydk.onOrientationChange', '监听横竖屏', function (tc) {
        tc.append('<p>等待横竖屏发生变化......</p>')
        ydk.onOrientationChange({
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });

    describe('ydk.getClientInfo', '客户端基本信息', function (tc) {
        tc.append('<p>输入：' + tc.code({}) + '</p>')
        ydk.getClientInfo({
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });

    describe('ydk.toast', '显示提示信息，3s左右自动消失', function (tc) {
        var btn = $('<button>点击提示</button>')
        tc.append(btn)
        btn.click(function (evt) {
            ydk.toast({
                msg : "时间：" + (+new Date),
                complete : function(res){
                   tc.updateStatus(res.code)
                   tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            });
        })
    });

    describe('ydk.rlog', '发一个测试 log', function (tc) {
        var btn = $('<button>点击发送</button>')
        tc.append(btn)
        btn.click(function (evt) {
            var params = {
                aaa : 'this is a test rlog',
                bbb : 'test time ' + (+new Date),
            };
            tc.append('<p>输入：' + tc.code(params) + '</p>')
            ydk.rlog(_.extend({}, params, {
                complete : function(res){
                   tc.updateStatus(res.code)
                   tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }));
        })
    });



    describe('ydk.addHistory', '增加历史记录给客户端', function (tc) {
        var btn = $('<button>点击增加</button>')
        tc.append(btn)
        btn.click(function (evt) {
            var params = {
                word : 'test',
                lang : 'en',
                explain : '',
                phonetic : '',
            };
            tc.append('<p>输入：' + tc.code(params) + '</p>')
            ydk.rlog(_.extend({}, params, {
                complete : function(res){
                   tc.updateStatus(res.code)
                   tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }));
        })
    });




    // -----------------------------------------------------------------------------
    // 用户接口

    describe('ydk.isLogin', '是否已登陆', function (tc) {
        tc.append('<p>输入：' + tc.code({}) + '</p>')
        ydk.isLogin({
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });

    describe('ydk.login', '用户登陆', function (tc) {
        var btn = $('<button>点击登陆</button>')
        tc.append(btn, '<p>输入：' + tc.code({}) + '</p>')
        btn.click(function (evt) {
            ydk.login({
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            })
        })
    });

    describe('ydk.getUserInfo', '是否已登陆', function (tc) {
        tc.append('<p>输入：' + tc.code({}) + '</p>')
        ydk.getUserInfo({
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });
    describe('ydk.onVipInfoGot', '监听vip状态', function (tc) {
        tc.append('<p>输入：' + tc.code({}) + '</p>')
        ydk.onVipInfoGot({
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });




    describe('ydk.refreshVipInfo', '通知客户端更新vip信息', function (tc) {
        var btn = $('<button>通知客户端更新vip信息</button>')
        tc.append(btn, '<p>输入：' + tc.code({}) + '</p>');
        btn.click(function(){     
            ydk.refreshVipInfo({
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            })
        })
    });


    describe('ydk.getProfile', '获取用户信息', function (tc) {
        tc.append('<p>输入：' + tc.code({}) + '</p>')
        ydk.getProfile({
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });

    describe('ydk.setProfile', '设置用户信息', function (tc) {
        var btn = $('<button>设置用户信息</button>')
        tc.append(btn);
        btn.click(function(){
            var params = {
                profile : {
                  option_introduction : '我是来自测试',
                }
            };
            tc.append('<p>输入：' + tc.code(params) + '</p>')        
            ydk.setProfile(_.extend({}, params, {
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
    });

    describe('ydk.checkNickname', '检查昵称是否可用', function (tc) {
        var btn = $('<button>点击检查</button>')
        tc.append(btn);
        btn.click(function(){
            var params = {
                nickname : 'testName',
            };         
            tc.append('<p>输入：' + tc.code(params) + '</p>')
            ydk.checkNickname(_.extend({}, params, {
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
    });


    describe('ydk.getNickname', '获取用户昵称', function (tc) {
        tc.append('<p>输入：' + tc.code({}) + '</p>')
        ydk.getNickname({
            complete: function (res) {
                tc.updateStatus(res.code)
                tc.append('<p>输出：' + tc.code(res) + '</p>')
            }
        })
    });

    describe('ydk.setNickname', '设置昵称', function (tc) {
        var btn = $('<button>设置昵称</button>')
        tc.append(btn);
        btn.click(function(){
            var params = {
                nickname : 'testName',
            };    
            tc.append('<p>输入：' + tc.code(params) + '</p>')        
            ydk.setNickname(_.extend({}, params, {
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })
    });
}
