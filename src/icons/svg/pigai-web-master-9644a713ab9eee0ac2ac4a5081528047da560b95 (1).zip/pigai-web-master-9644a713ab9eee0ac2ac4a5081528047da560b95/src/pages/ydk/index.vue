<template>
   <div id="pageYdk">
		<div class="ydkIntro" style="margin:1em;">
		  用于测试客户端内部接口是否可调用
		  <ul>
		    <li>黄色：所有测试用例的初始颜色，表示还未运行过测试代码，比如一些需要点击按钮的测试用例，只有在点击后才会执行测试代码</li>
		    <li>绿色：已运行，成功通过</li>
		    <li>红色：已运行，未通过</li>
		    <li>黑色：已运行，接口还未实现（no found）</li>
		    <li>客户端传过来的 true / false 为字符串，需转化使用</li>
		  </ul>
		  <h3>当前view的UA：</h3>
		  <p >{{ ua }}</p>
		</div>
		<div class="ydkContent"></div>
   </div>   			
</template>
<script>
import * as yt from './ytest.js';
import * as mt from './main.test.js';
import * as dd from './dict_desk.js';
import * as sw from './sw.js';

export default {
  data: function() {
    return {
      ua: window.navigator.userAgent
    };
  },
  mounted() {
    yt.start();
    mt.start();
    dd.start();
    sw.start();
  }
};
</script>
<style lang="scss">
@import "./index";
</style>