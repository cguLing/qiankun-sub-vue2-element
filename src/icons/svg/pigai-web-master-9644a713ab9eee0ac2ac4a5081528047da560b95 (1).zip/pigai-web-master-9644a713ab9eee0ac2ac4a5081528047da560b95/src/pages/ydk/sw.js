/*eslint-disable */

export function start(){
    describe('- 以下 API 为看天下项目的定制 -', '', function (tc) {
        tc.mod.addClass('mod-header')
    })

    describe('ydk.toggleAD', '展示或隐藏底部 native 广告', function (tc) {
        var params = {
            name : 'ad_bottom_banner',
            state : false
        }
        var btn = $('<button>点击切换 native 广告</button>');
        tc.append(btn)
        btn.click(function (e){
            params.state = !params.state
            ydk.toggleAD(_.extend(params, {
                complete : function (res) {
                    tc.updateStatus(res.code);
                    tc.append('<p>输出：‘' + tc.code(res) + '</p>')
                }
            }))
        })

    })


    describe('分享到第三方平台', '个性化分享测试', function (tc) {
        tc.append('<a href="http://c.youdao.com/test/dingzq/ydk.share.test.html">个性化分享测试</a><br>')
        var btn = $('<button>弹出分享窗口</button>')
        var btn1 = $('<button>设置分享数据-词典官网</button>')
        var btn2 = $('<button>设置分享数据-有道学堂</button>')

        var btn3 = $('<button>直接分享到QQ-有道首页</button>')
        var btn4 = $('<button>直接分享到微博-有道首页</button>')
        var btn5 = $('<button>直接分享到微信-有道首页</button>')
        var btn6 = $('<button>直接分享到微信朋友圈-有道首页</button>')

        tc.append(btn)
        tc.append(btn1)
        tc.append(btn2)
        tc.append(btn3)
        tc.append(btn4)
        tc.append(btn5)
        tc.append(btn6)

        var params = {
            title: '网易有道首页',
            desc: '网易旗下搜索引擎，主要提供网页、图片、热闻、视频、音乐、博客等传统搜索服务，同时推出海量词典、阅读、购物搜索等创新型产品。',
            link: 'http://www.youdao.com',
            imgUrl: 'http://shared.youdao.com/images/myth/images/logo.png'
        }

        var params1 = {
            title: '有道词典官网',
            desc: '有道词典是最好用的免费全能翻译软件，拥有5亿用户，占据市场第一。 独创的“网络释义”功能，轻松收录最新词汇。为您提供准确的在线词典、在线翻译、海量例句、全球发音等。',
            link: 'http://m.youdao.com/',
            imgUrl: 'http://oimagec3.ydstatic.com/image?id=5606355977608992016&product=adpublish'
        }

        var params2 = {
            title: '有道学堂',
            desc: '有道学堂，个性化的英语在线学习网站',
            link: 'http://xue.youdao.com',
            imgUrl: 'http://shared.ydstatic.com/study/1.2.3/images/logo/logo.png'
        }

        btn.click(function (evt) {
            tc.append('<p>输入：' + tc.code(params) + '</p>')
            ydk.share(_.extend(params, {
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })

        btn1.click(function () {
            tc.append('<p>输入：' + tc.code(params1) + '</p>')
            ydk.share(_.extend(params1, {
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })

        btn2.click(function () {
            tc.append('<p>输入：' + tc.code(params2) + '</p>')
            ydk.share(_.extend(params2, {
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })

        btn3.click(function () {
            tc.append('<p>输入：' + tc.code(params) + '</p>')
            ydk.share(_.extend(params, {
                type: 'qq',
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })

        btn4.click(function () {
            tc.append('<p>输入：' + tc.code(params) + '</p>')
            ydk.share(_.extend(params, {
                type: 'weibo',
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })

        btn5.click(function () {
            tc.append('<p>输入：' + tc.code(params) + '</p>')
            ydk.share(_.extend(params, {
                type: 'wechat',
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })

        btn6.click(function () {
            tc.append('<p>输入：' + tc.code(params) + '</p>')
            ydk.share(_.extend(params, {
                type: 'wechat_moments',
                complete: function (res) {
                    tc.updateStatus(res.code)
                    tc.append('<p>输出：' + tc.code(res) + '</p>')
                }
            }))
        })

    });
}
