module.exports = {
    version: @now@,
    debug: @debug@,
    mock: @mock@,
    isProduction: @isProduction@,
    isDevelopment: @isDevelopment@,
    platform: '@platform@',
    release: @release@,
    versionPath:'@versionPath@', // 版本文件夹名字
    //pigaiUrl: '//pigai.youdao.com',  //线上POST接口
    pigaiUrl: '//pigai_test.inner.youdao.com',  //测试POST接口
    pigaiJsonpUrl: '//pigai.youdao.com/pigai/action_jsonp', // 线上jsonp接口
    //pigaiJsonpUrl: '//pigai_test.inner.youdao.com/pigai/action_jsonp', //测试jsonp接口
    
    signWhiteList: [
      '/pigai/v/sign_action',
      '/pigai/v/sign_action_jsonp',
      '/translate_o',
      '/translate',
      '/dictserver/writing/correct/submit',
      '/dictserver/writing/correct/getHistory',
      '/dictserver/writing/correct/ocr',
      '/dictserver/writing/correct/listHistory',
      '/dictserver/writing/correct/saveHistory',
      '/dictserver/writing/correct/delHistory',
      '/dictserver/writing/correct/saveDraft',
    ], // 需要加签名的接口
    secretWhiteList: [
      '/dictserver/writing/correct/submit',
      '/dictserver/writing/correct/getHistory',
      '/dictserver/writing/correct/ocr'
    ], // 需解密签名
    // pigaiHost: 'pigai.youdao.com',
    // partnerId: 'youdao_online',
    // secretId: '030ff0fd16534bc6b0e612c3b40d8d8d',
    // secretKey: 'KCDeEl0eShoJMpo/W1/6xyw/5KL4EQlAMRCefplZymQ=',
    pigaiHost: 'dict.youdao.com',
    translateHost: 'pigai.youdao.com',
    partnerId:'pigaiweb',
    secretId: '030ff0fd16534bc6b0e612c3b40d8d8d', 
    // secretKey: 'KCDeEl0eShoJMpo/W1/6xyw/5KL4EQlAMRCefplZymQ=',
    fanyiSecretKey: 'c[dG40@Aqa@#K#A8L%R$O)', // 翻译私钥


      // test
    product: 'mdict',
    keyId: 'mdict-writing',
    secretKey: 'ezDcAUIyoFZbh32qxyhu1aSY1wGTyzz1',
    secretIv: 'TfRjbc4Dpv4A0GgZ',
    signSecretKey: 'kKpWfMFaa7EzPy\$c*DnakzbvIMzVK!I',
    algorithm: 'aes-128-cbc',
  };