/* 状态全写这里 */
import Vue from 'vue';
import Vuex from 'vuex';
import common from './modules/common';
import essay from './modules/essay'
import global from './modules/global'

Vue.use(Vuex);


export default new Vuex.Store({
  modules: {
    common,
    essay,
    global,
  },
});
