/**
 *  通用的配置，例如左边的配置跟地址菜单
 */

import * as types from '../mutation-types';

//初始state状态
const state = {
  isDebugger: false,
};

//可以做filter数据处理，也可以原始输出
const getters = {
  getDebugger: (state) => {
    return state.isDebugger;
  }
};


//可以异步获取数据，也可以在组件中使用dispatch来发出actions
const actions = {
  setDebugger({
    commit
  }, isDebugger) {
    commit(types.IS_DEBUGGER, isDebugger);
  },
};


//更新state状态
const mutations = {
  [types.IS_DEBUGGER](state, isDebugger) {
    state.isDebugger = isDebugger;
  }
};


export default {
  state,
  actions,
  getters,
  mutations
}