import * as types from '../mutation-types';


//初始state状态
const state = {
  title:'',
  inputText: '',
  currentType: 1,
  rawSentsFeedback: [],
  rawSentsIncludeFeedback: [],
  feedbackData: [],
  essayHtml: '',
  fixedPos: {
    fixedStartPos: null,
    fixedEndPos: null
  },
  history: {
    title: null,
    inputText: null,
    currentType: null,
    rawSentsFeedback: null,
    rawSentsIncludeFeedback: null,
    feedbackData:null,
    essayHtml: null
  }
}

//可以做filter数据处理，也可以原始输出
const getters = {
  getTitle(state) {
    return state.title;
  },
  getInputText(state) {
    return state.inputText;
  },

  getCurrentType(state) {
    return state.currentType;
  },

  getRawSentsFeedback(state) {
    return state.rawSentsFeedback;
  },

  getRawSentsIncludeFeedback(state) {
    return state.rawSentsIncludeFeedback;
  },

  getFeedbackData(state){
    return state.feedbackData;
  },

  getEssayHtml(state) {
    return state.essayHtml;
  },

  getFixedPos(state) {
    return state.fixedPos;
  },

  getHistory(state) {
    return state.history;
  }
}

//更新state状态
const mutations = {
  [types.TITLE](state, title) {
    state.history.title = state.title; //保存上一次操作数据
    state.title = title;
  },

  [types.INPUTTEXT](state, inputText) {
    state.history.inputText = state.inputText; //保存上一次操作数据
    state.inputText = inputText;
  },

  [types.CURRENTTYPE](state, currentType) {
    state.history.currentType = state.currentType; //保存上一次操作数据
    state.currentType = currentType;
  },

  [types.RAWSENTSFEEDBACK](state, rawSentsFeedback) {
    state.history.rawSentsFeedback = state.rawSentsFeedback; //保存上一次操作数据
    state.rawSentsFeedback = rawSentsFeedback;
  },

  [types.RAWSENTSINCLUDEFEEDBACK](state, rawSentsIncludeFeedback) {
    const {
      fixedStartPos,
      fixedEndPos
    } = state.fixedPos;
    let historyRawSentsIncludeFeedback = [];
    let stateRawSentsIncludeFeedback = state.rawSentsIncludeFeedback;
    //对历史数据进行处理
    stateRawSentsIncludeFeedback.forEach(element => {
      const obj = Object.assign({}, element);
      if (fixedStartPos == element.fixedStartPos && fixedEndPos == element.fixedEndPos) {
        obj.operation = '';
      }
      historyRawSentsIncludeFeedback.push(obj);
    });
    state.history.rawSentsIncludeFeedback = historyRawSentsIncludeFeedback; //保存上一次操作数据
    state.rawSentsIncludeFeedback = rawSentsIncludeFeedback;
  },

  [types.FEEDBACKDATA](state, feedbackData){
    state.history.feedbackData = state.feedbackData;
    state.feedbackData = feedbackData;
  },

  [types.ESSAYHTML](state, essayHtml) {
    state.history.essayHtml = state.essayHtml; //保存上一次操作数据
    state.essayHtml = essayHtml;
  },

  [types.FIXEDPOS](state, fixedPos) {
    state.history.fixedPos = state.fixedPos; //保存上一次操作数据
    state.fixedPos = fixedPos;
  },

  [types.HISTORY](state, history) {
    state.history.inputText = null;
    state.history.currentType = null;
    state.history.rawSentsFeedback = null;
    state.history.rawSentsIncludeFeedback = null;
    state.history.essayHtml = null;
  }
}


//可以异步获取数据
const actions = {
  setTitle({
    commit
  }, title) {
    commit(types.TITLE, title);
  },

  setInputText({
    commit
  }, inputText) {
    commit(types.INPUTTEXT, inputText);
  },

  setCurrentType({
    commit
  }, currentType) {
    commit(types.CURRENTTYPE, currentType);
  },

  setRawSentsFeedback({
    commit
  }, rawSentsFeedback) {
    commit(types.RAWSENTSFEEDBACK, rawSentsFeedback);
  },

  setRawSentsIncludeFeedback({
    commit
  }, rawSentsIncludeFeedback) {
    commit(types.RAWSENTSINCLUDEFEEDBACK, rawSentsIncludeFeedback);
  },

  setFeedbackData({
    commit
  }, feedbackData) {
    commit(types.FEEDBACKDATA, feedbackData);
  },

  setEassyHtml({
    commit
  }, essayHtml) {
    commit(types.ESSAYHTML, essayHtml);
  },

  setFixedPos({
    commit
  }, fixedPos) {
    commit(types.FIXEDPOS, fixedPos);
  },

  clearHistory({
    commit
  }, history = {}) {
    commit(types.HISTORY, history);
  },
}



export default {
  state,
  actions,
  getters,
  mutations
}
