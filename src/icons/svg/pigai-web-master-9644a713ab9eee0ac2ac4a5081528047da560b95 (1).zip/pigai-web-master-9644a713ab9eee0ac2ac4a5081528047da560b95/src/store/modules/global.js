/**
 *  全局的状态
 */

import * as types from '../mutation-types';
import SessionStore from 'commons/sessionStorage.js';
//初始state状态
const state = {
  uniqueKey: '',
  username: '',
};

//可以做filter数据处理，也可以原始输出
const getters = {
  getUniqueKey: (state) => {
    return state.uniqueKey;
  },
  getUsername: (state) => {
    return state.username;
  }
};


//可以异步获取数据，也可以在组件中使用dispatch来发出actions
const actions = {
  setUniqueKey({
    commit
  }, uniqueKey) {
    commit(types.UNIQUEKEY, uniqueKey);
  },
  setUsername({
    commit
  }, username) {
    commit(types.USERNAME, username);
  },
};


//更新state状态
const mutations = {
  [types.UNIQUEKEY](state, uniqueKey) {
    state.uniqueKey = uniqueKey;
    SessionStore.set('uniqueKey',uniqueKey)
  },
  [types.USERNAME](state, username) {
    state.username = username;
    SessionStore.set('username',username)
  }
};


export default {
  state,
  actions,
  getters,
  mutations
}
