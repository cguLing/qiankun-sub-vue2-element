//通用--common
export const IS_DEBUGGER = 'IS_DEBUGGER'; //是否启用调试模式

//英文批改--essay
export const TITLE = 'title';
export const INPUTTEXT = 'inputText';
export const CURRENTTYPE = 'currentType';
export const RAWSENTSFEEDBACK = 'rawSentsFeedback';
export const RAWSENTSINCLUDEFEEDBACK = 'rawSentsIncludeFeedback';
export const ESSAYHTML = 'essayHtml';
export const FIXEDPOS = 'fixedPos';
export const HISTORY = 'history';

export const FEEDBACKDATA = 'feedbackData'

//全局--global
export const UNIQUEKEY = 'uniqueKey'
export const USERNAME = 'username'