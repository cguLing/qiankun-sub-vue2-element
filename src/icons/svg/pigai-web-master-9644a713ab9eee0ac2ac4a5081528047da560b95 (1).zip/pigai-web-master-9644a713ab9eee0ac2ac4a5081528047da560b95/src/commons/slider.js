/**
 * 图片幻灯片
 * Last Update:2015-7-30
 */
var slider = function($selector, options) {

  $selector = $($selector);

  var defaults = {
      auto: false, //自动播放         
      speed: 500, //速度; 越小越快
      pause: 4000, //此4000代表自动播放的间隔，单位：毫秒
      style: 1, //1为显示分页按钮，2为只显示前后两个按钮, 3两种都显示
      sliderType: 'filter', //滚动方向:filter
      onCallback: null //回调
    },
    thix = this,
    $dots,
    $li = $selector.find('li'),

    autoPlayTimer,

    _preIndex = 0, //当前图片
    imagesSize = $li.length, //获取焦点图个数
    showDot = false, //是否显示小圆点
    showNav = false; //是否显示上下翻页

  options = $.extend({}, defaults, options);

  var init = function() {

    switch (options.style) {
      case 1:
        showDot = true;
        break;
      case 2:
        showNav = true;
        break;
      case 3:
        showDot = true;
        showNav = true;
        break;
    }

    if(imagesSize < 2){
      showNav = false;
      showDot = false;
    }
    render();
    bindEnvent();

    options.auto && startAutoPlay();
  };


  var render = function() {
    var html = '';

    if (showDot) {
      html = '<div class="module-slider-nav">';
      for (var i = 0; i < imagesSize; i++) {
        if (i == 0) {
          html += '<span class="current"></span>';
        } else {
          html += '<span></span>';
        }
      }
      html += '</div>';
    }

    if (showNav) {
      html += '<a class="button-slider-prev" href="javascript:;"><em>〈</em><s></s></a>';
      html += '<a class="button-slider-next" href="javascript:;"><em>〉</em><s></s></a>';
    }

    // $li.first().show().siblings("li").hide();

    $selector.append(html);
  };

  var bindEnvent = function() {
    //绑定小圆点动作
    if (showDot) {
      var hoverTimer;
      $selector.on('mouseenter mouseleave', ".module-slider-nav span", function() {
        clearTimeout(hoverTimer);
        var newIndex = $(this).index();
        hoverTimer = setTimeout(function() {
          show(newIndex);
        }, 200);
      });

      $dots = $selector.find(".module-slider-nav span");
    }

    //绑定翻页按钮动作
    if (showNav) {
      var hoverTimer;
      $selector
        .on("click", ".button-slider-prev", thix.prev)
        .on("click", ".button-slider-next", thix.next);
    }

    options.auto && $selector.hover(stopAutoPlay, startAutoPlay);
  };

  /**
   * 切换图片
   */
  var show = function(pre) {
    if (_preIndex == pre) return;
    switch (options.sliderType) {
      case 'filter': //滤镜效果
        var $lis = $("li", $selector);
        $lis.eq(_preIndex)
          .removeClass("module-slider-in")
          .addClass("module-slider-out");

        $lis.eq(pre)
          .removeClass("module-slider-out")
          .addClass("module-slider-in");

        _preIndex = pre;
        break;
    }

    showDot && renderDot(pre);
  };

  var renderDot = function(preIndex) {
    $dots
      .removeClass("current")
      .eq(preIndex)
      .addClass('current');
  };


  var startAutoPlay = function() {
    clearInterval(autoPlayTimer);
    autoPlayTimer = setInterval(function() {
      var index = _preIndex;
      index += 1;
      show(index >= imagesSize ? 0 : index);
    }, options.pause);
  };

  var stopAutoPlay = function() {
    clearInterval(autoPlayTimer);
  };

  thix.next = function() {
    var toIndex = _preIndex + 1;
    show(toIndex >= imagesSize ? 0 : toIndex);
  };

  thix.prev = function() {
    var toIndex = _preIndex - 1;
    show(toIndex < 0 ? imagesSize - 1 : toIndex);
  };

  thix.reload = function() {
    imagesSize = $("li", $selector).length;
    $selector.find('.module-slider-nav').remove();
    $selector.find('.button-slider-prev,.button-slider-next').remove();
    render();
    $dots = $selector.find(".module-slider-nav span");
    show(0);
  };


  init();
};



module.exports = slider;