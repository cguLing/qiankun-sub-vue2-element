import indexdb from 'commons/indexedDB.js';
import * as settinger from 'modules/dict_setting';

var history_type = 'dict/result';

var options =  {
  keyPath: 'id',//主键
  autoIncrement: false//是否自增长
};

var store = new indexdb('dict_history' , history_type , options);

export function saveToDb(params) {
  if(!params.keyword){
    return;
  }
  params.lang = params.lang || 'en';
  params.langDst = params.langDst || '';

  store.save({
    id : [params.keyword , params.lang , params.langDst].join('_'),
    keyword: params.keyword,
    lang : params.lang,
    langDst : params.langDst,
    time : new Date().getTime()
  })
}

export function query(callback) {

  //获取系统设置
  settinger.get((setting) => {
    var max = setting.content.history_num;
    store.all((data) => {
      var len = data.length;
      data = data.sort((a , b) => {
        return b.time - a.time;
      });
      
      //保留若干条数记录
      if(data.length > max){
        for(var i = max ; i < len ; i++){
          store.remove([data[i].keyword , data[i].lang].join('_'));
        }
      }
      callback(data.slice(0 , max));
    });
  });
}

export function clear(){
  store.clear();
}

export function remove(key , callback){
  store.remove(key , callback);
}

