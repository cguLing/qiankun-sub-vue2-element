import * as history from 'commons/history';
import * as dict_settab from 'modules/dict_settab';
import Store from 'commons/localStorage.js';


var _keyword, _lang, _langDst;
var history_arr = [];
var idx = 0;

var searchWebsterNum = Store.get('searchWebsterNum') || 0;
var searchOxfordNum = Store.get('searchOxfordNum') || 0;
var searchNewcenturyjcNum = Store.get('searchNewcenturyjcNum') || 0;
var _ky, _lg, _oxfordky, _oxfordlg, _newcenturyjcky, _newcenturyjclg;

//数组添加moveTo方法
var moveTo = (arr, old_index, new_index) => {
  if (new_index >= arr.length) {
    var k = new_index - arr.length;
    while ((k--) + 1) {
      arr.push(undefined);
    }
  }
  arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
  return arr;
}

//增加历史记录
var addHistory = (obj, params) => {
  var self = obj;
  var config = $.extend({
    keyword: '',
    langDst: '',
    detected: '',
    from: params.from || 'ydk'
  }, params || {});
  var kw = config.keyword;
  var lang = config.lang;
  var langDst = config.langDst;

  history.saveToDb({
    keyword: kw,
    lang: lang,
    langDst: langDst,
  });

  if (_keyword !== kw || _lang !== lang || _langDst !== langDst) {
    history_arr.splice(idx, 0, {
      keyword: kw,
      lang: lang,
      langDst: langDst
    });
    _keyword = kw;
    _lang = lang;
    _langDst = langDst;
    console.log('当前历史记录数据:', JSON.stringify(history_arr))
  }
}

export default {
  //获取url参数
  getQueryParamsString: function (_url, name) {
    var url = _url;
    var params = url.substr(url.indexOf('?'));
    var obj = {};
    if (!params) return obj;
    params = params.replace(/^[?]{1}|[#]{1}.*$/g, '').split('&');
    for (var i = 0, len = params.length; i < len; i++) {
      var e = params[i].split('=');
      obj[e[0]] = decodeURIComponent(e[1]);
    }
    return obj[name];
  },

  //获取url参数
  getQueryString: function () {
    var url = window.location.href;
    var params = url.substr(url.indexOf('?'));
    var obj = {};
    if (!params) return obj;
    params = params.replace(/^[?]{1}|[#]{1}.*$/g, '').split('&');
    for (var i = 0, len = params.length; i < len; i++) {
      var e = params[i].split('=');
      obj[e[0]] = decodeURIComponent(e[1]);
    }
    return obj;
  },

  //设置关键词
  setKeyword: function (params) {
    var config = $.extend({
      keyword: '',
      lang: '',
      langDst: '',
      detected: false,
      setInputKeyword: true,
      saveHistory: true,
      from: params.from || 'ydk'
    }, params || {});
    var self = config.obj;
    var kw = config.keyword;
    var lang = config.lang;
    var langDst = config.langDst || self.$store.state.common.sendKeyword.langDst;
    var detected = config.detected;

    if (lang == langDst) {
      langDst = '';
    }

    //划词传过来例如：zh-CHS2en
    if (lang.indexOf('2') > 0) {
      var idx = lang.indexOf('2');
      var tplLang = lang.substring(0, idx);
      var tplLangDst = lang.substring(idx + 1);
      lang = tplLang;
      langDst = tplLangDst;
    }

    kw && self.$store.dispatch('setKeyWord', kw);
    self.$store.dispatch('setLang', lang);
    self.$store.dispatch('setDstLang', langDst);

    //设置输入框关键词 默认为true
    if (config.setInputKeyword) {
      if (kw) {
        ydk.setKeyword({
          keyword: '' + kw,
          lang: lang,
          langDst: langDst,
          detected: detected
        });
        //韦氏词典非vip用户一天查词不能超过三次
        self.$utils.eableWebster({
          keyword: kw,
          lang: lang,
          langDst: langDst,
        });

        //新牛津词典非vip用户一天查词不能超过三次
        self.$utils.eableOxford({
          keyword: kw,
          lang: lang,
          langDst: langDst,
        });

        //新世纪日汉双解词典非vip用户一天查词不能超过三次
        self.$utils.eableNewcenturyjc({
          keyword: kw,
          lang: lang,
          langDst: langDst,
        });

      } else {
        ydk.setKeyword({
          lang: lang,
          langDst: langDst,
          detected: detected
        });
      }
    }

    //设置历史记录 默认为true     
    if (config.saveHistory && kw) {
      addHistory(self, {
        keyword: kw,
        lang: lang,
        langDst: langDst,
        detected: detected,
        from: config.from
      })
    }
  },

  //前进后退
  prevAndNext: function (obj, name) {
    var self = obj;
    var res = history_arr;

    if (name == 'next') {
      idx--;
    }
    if (name == 'prev') {
      idx++;
    }
    if (idx < 0) {
      idx = 0;
    }
    if (idx > res.length - 1) {
      idx = res.length - 1;
    }

    self.$utils.setKeyword({
      obj: self,
      keyword: res[idx].keyword,
      lang: res[idx].lang,
      langDst: res[idx].langDst || '',
      saveHistory: false
    });
  },

  //播放音频
  playVoice: function (obj, type) {
    var $this = obj;
    var url = $this.attr('data-url');
    var time = $this.attr('data-time'); // 单位为秒 
    $this.on(type, _.debounce(function () {
      ydk.playVoice({
        cache: false, //禁止ydk缓存对象
        localId: url, // 音频文件的 url
        currentTime: time || 0
      });
    }, 40));
  },

  //处理键盘事件 禁止后退键（Backspace）密码或单行、多行文本框除外
  banBackSpace: function (e) {
    var ev = e || window.event; //获取event对象
    var obj = ev.target || ev.srcElement; //获取事件
    var t = obj.type || obj.getAttribute('type'); //获取事件源类型
    //获取作为判断条件的事件类型
    var vReadOnly = obj.getAttribute('readonly');
    var vEnabled = obj.getAttribute('enabled');
    var vContenteditable = obj.getAttribute('contenteditable');
    //处理null值情况
    vReadOnly = (vReadOnly == null) ? false : true;
    vEnabled = (vEnabled == null) ? true : vEnabled;
    //当敲Backspace键时，事件源类型为密码或单行、多行文本的，
    //并且readonly属性为true或enabled属性为false的，则退格键失效
    var flag1 = (ev.keyCode == 8 && (t == 'password' || t == 'text' || t == 'textarea') && (vReadOnly || vEnabled != true)) ? true : false;
    //当敲Backspace键时，事件源类型非密码或单行、多行文本的、contenteditable，则退格键失效
    var flag2 = (ev.keyCode == 8 && !vContenteditable && t != 'password' && t != 'text' && t != 'textarea' && t != 'number') ? true : false;

    //判断
    if (flag2) {
      return false;
    }
    if (flag1) {
      return false;
    }
  },

  //判断文字的长度(英文占1个字符，中文汉字占2个字符)
  getStringNum: function (str) {
    var len = 0;
    for (var i = 0; i < (str + '').length; i++) {
      var c = str.charCodeAt(i);
      if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
        len++;
      } else {
        len += 2;
      }
    }
    return len;
  },

  //判断是否为中文（超过多少percent为准，默认为100）
  isChinese: function (str, percent = 100) {
    var sumLen = this.getStringNum(getTxtNums(str)); //中文占2个字符，英文1字符
    var chineseLen = this.chineseLength(str) * 3;

    //去掉标点符号和数字
    function getTxtNums(str) {
      var _str = str.replace(/[\ |\~|\`|\!|\@|\#|\$|\%|\^|\&|\*|\(|\)|\-|\_|\+|\=|\||\\|\[|\]|\{|\}|\;|\:|\"|\'|\,|\<|\.|\>|\/|\?|\d]/g, '');
      return _str;
    }

    if ((chineseLen / sumLen) * 100 >= percent) {
      return true;
    } else {
      return false;
    }
  },
  chineseLength: function (str) {
    var len = 0;
    //中文字符的正则
    var re = /[\u4E00-\u9FA5]/g;
    //中文标点符号 。 ？ ！ ， 、 ； ： “ ” ‘ ' （ ） 《 》 〈 〉 【 】 『 』 「 」 ﹃ ﹄ 〔 〕 … — ～ ﹏ ￥
    var reg = /[\u3002|\uff1f|\uff01|\uff0c|\u3001|\uff1b|\uff1a|\u201c|\u201d|\u2018|\u2019|\uff08|\uff09|\u300a|\u300b|\u3008|\u3009|\u3010|\u3011|\u300e|\u300f|\u300c|\u300d|\ufe43|\ufe44|\u3014|\u3015|\u2026|\u2014|\uff5e|\ufe4f|\uffe5]/g;

    if (str) {
      if (re.test(str)) {
        len = str.match(re).length;
      }
      if (reg.test(str)) {
        len = len + str.match(reg).length;
      }
    }
    return len;
  },

  //js深嵌套对象属性是否存在
  isKeyExists: function (object = {}, path = '') {
    try {
      var result = path.split('.').reduce((object, k) => object[k], object);
      if (typeof result === 'undefined') {
        return false;
      }
      return true;
    } catch (e) {
      console.error(e);
    }
  },

  //韦氏词典非vip用户一天查词不能超过三次
  eableWebster: function (params) {
    var self = window.$Vue;
    var config = $.extend({}, params || {});
    var keyword = config.keyword;
    var lang = config.lang;

    dict_settab.get(function (res) {
      var maxSearchNum = 3;
      var websterTab = res.auto.dict.webster || res.en.dict.webster; //韦氏词典tab
      var vipInfo = Store.get('dict_vipInfo') || {};
      var enableWebster = self.$store.state.dict.enable_webster;
      var websterDict = self.$store.state.dict.webster_dict; //韦氏词典数据
      var query_webster_hours = Store.get('query_webster_hours') ? Store.get('query_webster_hours') : _.now();
      var over24Hours = (_.now() - query_webster_hours) > (24 * 60 * 60 * 1000) ? true : false;

      if (vipInfo.isVip) { //vip用户
        self.$store.dispatch('setEnableWebster', true);
        Store.set('query_enable_webster', 'true');
      } else {
        if (!enableWebster && over24Hours) { //超过24小时
          self.$store.dispatch('setEnableWebster', true);
          Store.set('query_enable_webster', 'true');
          searchWebsterNum = 0;
        } else { //没超过24小时
          if (websterDict && enableWebster && websterTab && (keyword != _ky || lang != _lg)) {
            if (searchWebsterNum++ > maxSearchNum - 1) {
              self.$store.dispatch('setEnableWebster', false);
              Store.set('query_enable_webster', 'false');
              Store.set('query_webster_hours', _.now());
            }
            _ky = keyword;
            _lg = lang;
          }
        }
      }
      Store.set('searchWebsterNum', searchWebsterNum);
      console.log('webster:', websterDict, enableWebster, websterTab, keyword, _ky, lang, _lg)
      console.log('webster:_vip:' + vipInfo.isVip, '查词的次数:' + searchWebsterNum)
    })
  },

  //新牛津词典非vip用户一天查词不能超过三次
  eableOxford: function (params) {
    var self = window.$Vue;
    var config = $.extend({}, params || {});
    var keyword = config.keyword;
    var lang = config.lang;

    dict_settab.get(function (res) {
      var maxSearchNum = 3;
      var oxfordTab = res.auto.dict.oxford || res.en.dict.oxford; //新牛津词典tab
      var vipInfo = Store.get('dict_vipInfo') || {};
      var enableOxford = self.$store.state.dict.enable_oxford;
      var oxfordDict = self.$store.state.dict.oxford_dict; //新牛津词典数据
      var query_oxford_hours = Store.get('query_oxford_hours') ? Store.get('query_oxford_hours') : _.now();
      var over24Hours = (_.now() - query_oxford_hours) > (24 * 60 * 60 * 1000) ? true : false;

      if (vipInfo.isVip) { //vip用户
        self.$store.dispatch('setEnableOxford', true);
        Store.set('query_enable_oxford', 'true');
      } else {
        if (!enableOxford && over24Hours) { //超过24小时
          self.$store.dispatch('setEnableOxford', true);
          Store.set('query_enable_oxford', 'true');
          searchOxfordNum = 0;
        } else { //没超过24小时
          if (oxfordDict && enableOxford && oxfordTab && (keyword != _oxfordky || lang != _oxfordlg)) {
            if (searchOxfordNum++ > maxSearchNum - 1) {
              self.$store.dispatch('setEnableOxford', false);
              Store.set('query_enable_oxford', 'false');
              Store.set('query_oxford_hours', _.now());
            }
            _oxfordky = keyword;
            _oxfordlg = lang;
          }
        }
      }
      Store.set('searchOxfordNum', searchOxfordNum);
      console.log('oxford:', oxfordDict, enableOxford, oxfordTab, keyword, _oxfordky, lang, _oxfordlg)
      console.log('oxford:_vip:' + vipInfo.isVip, '查词的次数:' + searchOxfordNum)
    })
  },

  //新世纪日汉双解大词典非vip用户一天查词不能超过三次
  eableNewcenturyjc: function (params) {
    var self = window.$Vue;
    var config = $.extend({}, params || {});
    var keyword = config.keyword;
    var lang = config.lang;

    dict_settab.get(function (res) {
      var maxSearchNum = 3;
      var newcenturyjcTab = res.auto.dict.newcenturyjc || res.auto1.dict.newcenturyjc || res.ja.dict.newcenturyjc || res.ja1.dict.newcenturyjc; //新世纪日汉双解大词典tab
      var vipInfo = Store.get('dict_vipInfo') || {};
      var enableNewcenturyjc = self.$store.state.dict.enable_newcenturyjc;
      var newcenturyjcDict = self.$store.state.dict.newcenturyjc_dict; //新世纪日汉双解大词典数据
      var query_newcenturyjc_hours = Store.get('query_newcenturyjc_hours') ? Store.get('query_newcenturyjc_hours') : _.now();
      var over24Hours = (_.now() - query_newcenturyjc_hours) > (24 * 60 * 60 * 1000) ? true : false;

      if (vipInfo.isVip) { //vip用户
        self.$store.dispatch('setEnableNewcenturyjc', true);
        Store.set('query_enable_newcenturyjc', 'true');
      } else {
        if (!enableNewcenturyjc && over24Hours) { //超过24小时
          self.$store.dispatch('setEnableNewcenturyjc', true);
          Store.set('query_enable_newcenturyjc', 'true');
          searchNewcenturyjcNum = 0;
        } else { //没超过24小时
          if (newcenturyjcDict && enableNewcenturyjc && newcenturyjcTab && (keyword != _newcenturyjcky || lang != _newcenturyjclg)) {
            if (searchNewcenturyjcNum++ > maxSearchNum - 1) {
              self.$store.dispatch('setEnableNewcenturyjc', false);
              Store.set('query_enable_newcenturyjc', 'false');
              Store.set('query_newcenturyjc_hours', _.now());
            }
            _newcenturyjcky = keyword;
            _newcenturyjclg = lang;
          }
        }
      }
      Store.set('searchNewcenturyjcNum', searchNewcenturyjcNum);
      console.log('newcenturyjc:', newcenturyjcDict, enableNewcenturyjc, newcenturyjcTab, keyword, _ky, lang, _lg)
      console.log('newcenturyjc:_vip:' + vipInfo.isVip, '查词的次数:' + searchNewcenturyjcNum)
    })
  },

  //获取可编辑div当前光标位置
  getDivCursortPosition: function (element) {
    var caretOffset = 0;
    var doc = element.ownerDocument || element.document;
    var win = doc.defaultView || doc.parentWindow;
    var sel;
    if (typeof win.getSelection != "undefined") { //谷歌、火狐
      sel = win.getSelection();
      if (sel.rangeCount > 0) { //选中的区域
        var range = win.getSelection().getRangeAt(0);
        var preCaretRange = range.cloneRange(); //克隆一个选中区域
        preCaretRange.selectNodeContents(element); //设置选中区域的节点内容为当前节点
        preCaretRange.setEnd(range.endContainer, range.endOffset); //重置选中区域的结束位置
        caretOffset = preCaretRange.toString().length;
      }
    } else if ((sel = doc.selection) && sel.type != "Control") { //IE
      var textRange = sel.createRange();
      var preCaretTextRange = doc.body.createTextRange();
      preCaretTextRange.moveToElementText(element);
      preCaretTextRange.setEndPoint("EndToEnd", textRange);
      caretOffset = preCaretTextRange.text.length;
    }
    return caretOffset;
  },

  //获取input/textarea当前光标位置
  getTextareaCursortPosition: function (element) {
    let cursorPos = 0;
    if (document.selection) { //IE
      var selectRange = document.selection.createRange();
      selectRange.moveStart('character', -element.value.length);
      cursorPos = selectRange.text.length;
    } else if (element.selectionStart || element.selectionStart == '0') {
      cursorPos = element.selectionStart;
    }
    return cursorPos;
  },


  //设置div的光标位置 
  setDivCursortPosition: function (element, endPos) {
    //let range = window.getSelection();//创建range
    //element.focus(); //解决ff不获取焦点无法定位问题    
    //range.selectAllChildren(element);//range 选择obj下所有子内容
    //range.collapseToEnd();//光标移至最后

    element.focus();
    let sel = window.getSelection();
    let rang = document.createRange(); //创建一个rang对象
    let content = element.firstChild;
    // let  innerLen =  ele.innerText.length;
    rang.setStart(content, endPos);
    //rang.setEnd(content, endPos);
    rang.collapse(false); //起始位置和终止位置是否相同的布尔值
    sel.removeAllRanges(); //移除选中区域的range对象
    sel.addRange(rang); //给选中区域添加range对象
  },

  //ajax promise封装
  ajaxPromise(params = {}) {
    return new Promise((reslove, reject) => {
      $.ajax({
        type: params.type || 'GET',
        async: params.async || true,
        url: params.url,
        dataType: params.dataType || 'json',
        data: params.data,
        cache: params.cache || true,
        success: function (res) {
          reslove(res);
        },
        error: function (error) {
          reject(error);
        }
      })
    })
  },

  // ajax 额外封装
  server(params) {
    $.ajax(_.extend({
      data: params.data || {},
      type: params.type || 'GET',
      dataType: params.dataType || 'json',
      jsonp: params.jsonp || 'callback',
      xhrFields: {
        withCredentials: true
      },
      crossDomain: true,
      // timeout  : params.timeout || 10000,
      // async    : params.async || true,
      cache: params.cache || false,
      success: function (data) {
        params.success(data)
      },
      complete: function (xhr, status) {
        // console.log('ajax complete', arguments);
      }
    }, params))
  },
  // 生成随机字符串
  randomId(randomFlag = false, min = 10, max) {
    let str = '';
    let pos = 0;
    let range = min;
    const arr = [
      '0',
      '1',
      '2',
      '3',
      '4',
      '5',
      '6',
      '7',
      '8',
      '9',
      'a',
      'b',
      'c',
      'd',
      'e',
      'f',
      'g',
      'h',
      'i',
      'j',
      'k',
      'l',
      'm',
      'n',
      'o',
      'p',
      'q',
      'r',
      's',
      't',
      'u',
      'v',
      'w',
      'x',
      'y',
      'z',
      'A',
      'B',
      'C',
      'D',
      'E',
      'F',
      'G',
      'H',
      'I',
      'J',
      'K',
      'L',
      'M',
      'N',
      'O',
      'P',
      'Q',
      'R',
      'S',
      'T',
      'U',
      'V',
      'W',
      'X',
      'Y',
      'Z',
    ];
    // 随机产生
    if (randomFlag) {
      range = Math.round(Math.random() * (max - min)) + min;
    }
    for (let i = 0; i < range; i += 1) {
      pos = Math.round(Math.random() * (arr.length - 1));
      str += arr[pos];
    }

    // 避免会产生相同的字符串，再增加一个时间戳
    var timestamp = new Date().getTime();

    return str + timestamp;
  },
  // 过滤一些不能使用的unicode
  filterUcode(inputText) {
    // const reg = /\uFFFC/ug;
    const reg = /([\x7F-\x84]|[\x86-\x9F]|[\uFDD0-\uFDEF]|[\u{1FFFE}-\u{1FFFF}]|[\u{2FFFE}-\u{2FFFF}]|[\u{3FFFE}-\u{3FFFF}]|[\u{4FFFE}-\u{4FFFF}]|[\u{5FFFE}-\u{5FFFF}]|[\u{6FFFE}-\u{6FFFF}]|[\u{7FFFE}-\u{7FFFF}]|[\u{8FFFE}-\u{8FFFF}]|[\u{9FFFE}-\u{9FFFF}]|[\u{AFFFE}-\u{AFFFF}]|[\u{BFFFE}-\u{BFFFF}]|[\u{CFFFE}-\u{CFFFF}]|[\u{DFFFE}-\u{DFFFF}]|[\u{EFFFE}-\u{EFFFF}]|[\u{FFFFE}-\u{FFFFF}]|[\u{FFFC}]|[\u{10FFFE}-\u{10FFFF}].)/ug;
    // var reg = new RegExp('\uFFFC', 'ug');
    // console.log('bt:', '￼'.charCodeAt(0))
    // console.log('tt:', /^.$/u.test('￼'))
    // console.log('rt:', reg.test('￼'))
    // console.log('st:', reg.test(inputText))
    // console.log('at:', '￼' === '\u{FFFC}')
    var filterUCode = inputText.replace(reg, '');
    return filterUCode;
  },
  isIE11() {
    return navigator.userAgent.toLowerCase().match(/rv:([\d.]+)\) like gecko/);
  },
  // 检查用户登录状态，未登录则重定向至登录页面
  checkLogin() {
    const loginURL = 'https://c.youdao.com/common-login-web/index.html?redirect_url='
    ydk.isLogin({
      success: function (res) {
        // console.log(res);
        if (!res.isLogin) {
          window.location.href = loginURL + encodeURIComponent(document.URL)
          console.log('未登录')
        } else {
          console.log('已经登陆')
        }
      },
      fail: function () {
        window.location.href = loginURL + encodeURIComponent(document.URL)
        console.log('未登录')
      }
    });
  }
}
