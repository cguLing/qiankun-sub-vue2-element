/**
 * 通用模块-滚动可见触发
 * 当浏览滚动到元素区域,触发事件,可用于图片延迟加载/内容加载更多
 *
 * 
 * 使用方法
 * var scoll = require("commons/scroll.event.position");
 * scoll(selector , options)
 * 
 * 参数
 * options{offset : Number , one : Function , callback : Function}
 * 
 * 参数说明
 * offset：偏移量
 * one :    一次性触发事件
 * callback :   多次触发事件
 * 
 * 
 * @luzhujun
 * @2014-10-31
 */
var
  doc = document.compatMode == 'CSS1Compat' ? document.documentElement : document.body,
  $doc = $(document),
  $win = $(window),
  _scrollTopSrart = 0,
  _scrollTopEnd = 0,
  _timer,
  mods = [],
  _clientHeight;


var render = function($target , options){
  var
    top = $target.offset().top + options.offset,
    pos = top + $target.height();

  pos = pos < 0 ? 0 : pos;


  if((top >= _scrollTopSrart && top <= _scrollTopEnd) 
      || (pos >= _scrollTopSrart && pos <= _scrollTopEnd)
      || (top < _scrollTopSrart && pos > _scrollTopEnd)
  )
  {
    if(options.one){
        options.one.call($target[0]);
        return true;
    }

    if(options.callback){
        options.callback.call($target[0]);
    }
  }

  return false;
};

var onscroll = function(){

  _scrollTopSrart = $win.scrollTop();
  _scrollTopEnd = _scrollTopSrart + _clientHeight;

  for(var i = 0, len = mods.length ; i < mods.length ; i++){
    var $mod = mods[i];
    var $target = $mod.target;


    //跳过不可见元素
    if(
        $target[0].offsetHeight <= 0 
        || $target[0].offsetWidth <=0 ){
      // console.log($target , $target[0].offsetHeight , $target[0].offsetWidth);
      continue;
    }
    if(render($target , $mod.options))
    {
      //移除对象
      mods.splice(i , 1);
      i--;
      len = mods.length;
    }
  };
};

var init = function(){
  _clientHeight = doc.clientHeight;
  _scrollTopSrart = $win.scrollTop();
  _scrollTopEnd = _scrollTopSrart + _clientHeight;

  $win.scroll(function(){
    clearTimeout(_timer);
    if(mods && mods.length > 0){
      _timer = setTimeout(onscroll , 200);
    }
  });
  $win.bind("resize" , function(){
    _clientHeight = doc.clientHeight;
  });

};

var DEFAULT = {
  offset : 0,         //偏移量
  one : null,         //一次性触发事件
  callback : null     //多次触发事件
};

$(init);

module.exports =  function(selector , options){
  if(typeof(options) == "function"){
    options = {
        callback : options
    }
  }
  options = $.extend({} , DEFAULT , options);
  $(selector).each(function(){
    mods.push({ target : $(this) , options : options} );
  });
  onscroll();
};