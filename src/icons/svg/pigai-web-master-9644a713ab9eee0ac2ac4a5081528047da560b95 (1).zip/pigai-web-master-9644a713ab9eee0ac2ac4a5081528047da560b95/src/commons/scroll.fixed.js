/**
 * 通用模块-滚动固定
 *
 * 参数
 * options{ie6 : Boolean , offset : Number , onfixed : Function , onrestore : Function}
 * 
 * 参数说明
 * ie6：是否兼容IE6
 * 
 * 使用方法
 * var fixed = require("common/scroll.fixed");
 * fixed(selector , options)
 *
 * 
 * @luzhujun
 * @2015-1-19
 */

var 
    isIE = /*@cc_on!@*/false,
    isIE6 = isIE && !window.XMLHttpRequest,
    doc = document.compatMode == 'CSS1Compat' ? document.documentElement : document.body,
    $doc = $(document),
    $win = $(window),
    winH = $win.height(),
    winW = $win.width(),
    $mods = [],
    tmp,
    scrollTimer,
    resizeTimer;


//还原原本位置
var onrestore = function($target , options){
    if($target.data("fixed")){
        options.onrestore && options.onrestore.call($target[0]);
    }
    var old_css = $target.data("oldcss");
    $target.data("fixed" , false);

    if(!old_css)return;

    old_css = old_css.split(",");
    if(isIE6){
        $target.css({
            top : old_css[1]+"px"
        });
    }else{
        $target.css({
            position : old_css[0],
            top : old_css[1],
            left : old_css[2]
        });
    }
    
};

//固定某个位置
var onfix = (isIE6 ? function($target , scrollTop , offsetTop , options){

    $target.animate({ 
        top : scrollTop - offsetTop
    } , 300 , null , function(){
        if($target.data("fixed") === false){
            options.onfixed && options.onfixed.call($target[0]);
        } 
    });

    $target.data("fixed" , true);
}:function($target , scrollTop , offsetTop , options){
    if($target.data("fixed"))return;
    if($target.data("fixed") === false){
        options.onfixed && options.onfixed.call($target[0]);
    }

    var offset = $target.data("offset").split(",");
    $target.css({
        position : "fixed",
        top : 0,
        left : offset[1]+"px"
    });
    $target.data("fixed" , true);
});

//执行触发事件l
var doscroll = function(){
    var scrollTop = $win.scrollTop();
    for(var i = 0, len = $mods.length ; i < len ; i++){
        var $mod = $mods[i];
        var $target = $mod.target;
        var options = $mod.options;

        //跳过不支持IE6和不可见元素
        if(
                (isIE6 && !options.ie6)
                || $target.length == 0 
                || $target[0].offsetHeight <= 0 
                || $target[0].offsetWidth <=0 ){
            continue;
        }

        var offsetTop = $target.data("offsetTop");
        if(!offsetTop){
            var offset = $target.offset(),
                old_css = {
                    position : $target.css("position"),
                    top : $target.css("top"),
                    left : $target.css("left")
                };
            offsetTop = offset.top - (parseInt(old_css.top , 10) || 0 ) - options.offset;
            $target
                .data("offsetTop" , offsetTop)
                .data("oldcss" , [old_css.position , old_css.top , old_css.left].join(","))
                .data("offset" , offset.top + "," +offset.left);
        }

        if(scrollTop > offsetTop){
            onfix($target , scrollTop , offsetTop ,options);
        }else{
            onrestore($target , options);
        }
    }

};

var onscroll = (isIE6 ? function(){
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(doscroll , 120);
} : doscroll);


$win.bind("scroll" , onscroll);

$win.bind("resize" , function(){
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(function(){
    if(
        winH == $win.height()
        && winW == $win.width()
    ){
        //IE6,7 和旧版的chrome下的bug,当内容长度变化时,会触发resize事件
        return;
    }

    for(var i = 0, len = $mods.length ; i < len ; i++){
        var $mod = $mods[i];
        var $target = $mod.target;
        var options = $mod.options;

        if( (isIE6 && !options.ie6) || $target.length == 0)continue;
        $target.data("offsetTop" , null);
        onrestore($target , options);
    }
    doscroll();
    winH = $win.height();
    winW = $win.width();
  }, 200);
});


var DEFAULT = {
    ie6 : true,         //是否兼容IE6
    offset : 0,         //偏移
    onfixed : null,     //当滚动固定时候触发
    onrestore : null    //当位置还原时候触发
};

module.exports =  function(selector , options){
    options = $.extend({} , DEFAULT , options);
    $(selector).each(function(){
        $mods.push({ target : $(this) , options : options} );
    });
    onscroll();
};
