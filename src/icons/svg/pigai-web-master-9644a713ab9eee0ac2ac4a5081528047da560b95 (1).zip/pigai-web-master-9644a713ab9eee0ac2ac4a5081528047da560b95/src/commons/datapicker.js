function dataPicker(data, dataPath) {
  var paths = dataPath.split('.')
  var resultData = data
  try {
    paths.forEach(function (path) {
      resultData = resultData[path]
    })
  } catch (err) {
    return []
  }
  return resultData
}

module.exports = dataPicker;