var events = {};

var copy = (args , start) => {
  // avoid leaking arguments:
  // http://jsperf.com/closure-with-arguments
  var len = args.length
  var arr = [];
  for (var i = start; i < len; i ++) {
    arr.push(args[i]);
  }
  return arr;
}


module.exports = {
  //一次性事件
  one: function(name, callback) {
    if (!events[name]) {
      events[name] = [
        [callback], //one
        []
      ];
    } else {
      events[name][0].push(callback);
    }

  },
  //绑定事件
  bind: function(name, callback) {
    if (!events[name]) {
      events[name] = [
        [],
        [callback]
      ];
    } else {
      events[name][1].push(callback);
    }
  },

  //触发事件
  trigger: function(name) {
    var arr = copy(arguments, 1);
    var es = events[name];
    if (!es) return;

    var self = this;

    $.each(es[0], function(index, callback) {
      callback.apply(self, arr);
    });
    $.each(es[1], function(index, callback) {
      callback.apply(self, arr);
    });
    es[0] = [];
  }
};