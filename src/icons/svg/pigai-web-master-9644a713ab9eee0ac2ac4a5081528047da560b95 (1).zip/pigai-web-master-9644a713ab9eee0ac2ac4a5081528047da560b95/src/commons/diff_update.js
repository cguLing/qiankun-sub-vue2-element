/**
 * 基于Vue的对象差异更新
 */
import Vue from 'vue';
var defineReactive = Vue.util.defineReactive

var diff = function(parentSource , sourceKey , source , target , paths){
  if(_.isArray(source) && _.isArray(target)){
    diffArray(source , target , paths);
  }else if(_.isObject(source) && _.isObject(target) && !_.isArray(source) && !_.isArray(target)){
    diffObject(source , target , paths);
  }else{
    //对比基础类型差异
    if( source != target){
      //必须通过父级节点修改，否则修改的只是引用值
      // console.log(parentSource , sourceKey , target);
      // parentSource[sourceKey] = target;
      if(Array.isArray(parentSource)){
        parentSource.$set(sourceKey , target);
      }else{
        Vue.set(parentSource , sourceKey  , target);
      }
      logDiff(source , target , paths);
    }
  }

};

var diffArray = function(source , target , paths){
  var len = source.length;
  var tlen = target.length;

  for (var i = Math.min(len , tlen) - 1; i >= 0; i--) {
    diff(source ,i , source[i] , target[i] , paths + '.' + i);
  };


  if(len < tlen){
    target.slice(len , tlen).forEach(function(item){
      source.push(item);
    });
  }else if(len > tlen){
    source.splice(tlen , len - tlen);
  }
};

var diffObject = function(source , target , paths){

  Object.keys(source).forEach(function(k){
    if(!target.hasOwnProperty(k)){
      source[k] = null;
      // console.debug('delete' , k , source , target);
    }
  });


  Object.keys(target).forEach(function(k){
    var p = paths + '.' + k;
    var sourceVal = source[k];
    if(target[k] !== undefined && (sourceVal == null || sourceVal == undefined) ){
      logDiff(source[k] , target[k] , p);
      Vue.set(source , k  , target[k]);
    }else{
      diff(source ,k , sourceVal , target[k] , p)
    }
  });
};


var logDiff = function(source , target , path){
  // console.trace('Diff: ' + path , source , target)
};

var diffUpdate = function(source , target){

  /*Object.keys(target).forEach(function(k){
    if(!source.hasOwnProperty(k) ){
      defineReactive(source , k , target[k]);
    }
  });*/

  diff(source , target , source , target , '');
};


export default diffUpdate;