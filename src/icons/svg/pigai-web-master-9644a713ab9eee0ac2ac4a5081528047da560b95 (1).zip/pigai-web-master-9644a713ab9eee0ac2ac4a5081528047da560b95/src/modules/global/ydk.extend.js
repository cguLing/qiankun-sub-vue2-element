
var omit = (params) => {
  return _.omit(params, function (val) {
    return _.isFunction(val)
  });
};

ydk.extend({

  rlog : function (params) {
    ydk._invoke('rlog', omit(params) , params);
  },

  /**
   * 以下为PC词典私有方法
   */

  /**
   * 获取信息流数据 和 栏目
   */
  getInfoLineData : function(params){
    ydk._invoke('getInfoLineData', params.data , params);
  },

  /**
   * 设置客户端查询关键字
   * @param {String} params.keyword 关键字
   * @param {String} params.lang 语言
   */
  setKeyword : function(params){
    ydk._invoke('setKeyword', params, params);
  },

  /**
   * 获取客户端关键字
   */
  getKeyword : function(params){
    ydk._invoke('getKeyword', params , params);
  },

  /**
   * 监听客户端关键字变化，onKeyUp
   */
  onKeywordChanged : function(params){
    ydk._on('onKeywordChanged', {} , params);
  },

  /**
   * 监听客户端关键字变更，onSubmit
   */
  onKeywordSubmit : function(params){
    ydk._on('onKeywordSubmit', {} , params);
  },

  /**
   * 获取查词释义(本地和网络，哪个先有结果哪个先返回)
   *
   * params.data.type:
   *   quick:：jsonresult，速查页面使用
   *   detail：jsonapi，查词结果页
   *   mini：fsearch，mini窗口
   */
  getDictResult : function(params){
    ydk._invoke('getDictResult', params.data , params);
  },

  /**
   * 获取翻译结果
   */
  getTranslateResult : function(params){
    ydk._invoke('getTranslateResult', params.data , params);
  },

  /**
   * 获取相似例句结果
   */
  getSimsentResult : function(params){
    ydk._invoke('getSimsentResult', params.data , params);
  },

  /**
   * 客户端UI事件
   *
   * 仅仅用来，客户端通知前端打开某页面使用
   *
   * key: 
   *   SettingTab设置页
   *   Feedback反馈页
   *   Invest调查页面
   */
  onTriggerNativeEvent : function(params){
    ydk._on('onTriggerNativeEvent', {} , params);
  },

  /**
   * 设置客户端左侧激活tab 
      DictTab  查词
      WordBookTab  单词本
      ClassTab 精品课
      ManualTransTab 人工翻译
   */
  setNativeTab : function(params){
    ydk._invoke('setNativeTab', {
      key : params.key
    } , params);
  },

  /**
   * 设置客户端左侧tab 将来可能有用，先调通
   */
  simulateClick : function (params) {
    ydk._invoke('simulateClick' , {
      btnname : params.key
    } , params);
  },

  /**
   * 获取客户端设置
   */
  getSetting : function(params){
    ydk._invoke('getSetting' , {} , params);
  },

  /**
   * 保存客户端设置
   */
  saveSetting : function(params){
    ydk._invoke('saveSetting' , {
      setting : params.setting
    } , params);
  },

  /**
   * 设置主窗口URL
   */
  /*loadMainURL : function(params){
    ydk._invoke('loadMainURL' , {
      url : params.url
    } , params);
  },*/

  /**
   * 关闭suggest
   */
  closeSuggest : function(params){
    ydk._invoke('closeSuggest' , {} , params);
  },

  /**
   * 监控客户端传输的键盘事件
   */
  onNativeKeyDown : function(params){
    ydk._on('onNativeKeyDown', {} , params);
  },

  /**
   * 复制到剪贴板
   */
  copyToClipboard : function(params){
    ydk._invoke('copyToClipboard' , {
      content : params.content
    } , params);
  },

  /**
   * 监听广播的消息
   */
  onBroadcast : function(params){
    //还原数据
    params._complete = function(res){
      if(res.data.format == 'json' && typeof(res.data.data) == 'string'){
        res.data.data = JSON.parse(res.data.data);
      }
    };
    ydk._on('onBroadcast', {} , params);
  },

  /**
   * 广播消息
   *
   * route.change 页面切换
   * keyword.submit 查询关键字变更
   * delete: keyword.submit.to 查询关键字，而打开指定页面
   * delete: fanyi.submit 翻译指定内容
   * history.save 通知保存历史记录
   * 
   */
  broadcast : function(params){
    var data = params.data;
    var format = 'string';
    //自动格式化数据
    if(typeof(data) == 'object'){
      data = JSON.stringify(data);
      format = 'json';
    }
    ydk._invoke('broadcast' , {
      type : params.type,
      format : format,
      data : data
    } , params);
  },

  /**
   * 显示历史记录
   */
  onHistory : function(params){
    ydk._on('onHistory', {} , params);
  },

  /**
   * 通知客户端，当前是否有历史记录
   */
  setHasHistory : function(params){
    ydk._invoke('setHasHistory' , {
      has : params.has
    } , params);
  },

  /**
   * 监听右下角弹窗
   */
  onCornerPopupShow  : function(params){
    ydk._on('onCornerPopupShow' , {} , params);
  },

  /**
   * 展示右下角弹窗
   */
  showCornerPopup  : function(params){
    ydk._invoke('showCornerPopup' , {} , params);
  },

  /**
   * 展示划词结果
   */
  onStrokeResult : function(params){
    ydk._on('onStrokeResult', {} , params);
  },
  
  /**
   * 设置划词结果语言
   */
  setStroke : function(params){
    ydk._invoke('setStroke', omit(params) , params);
  },


  /**
   * 关闭窗口
   */
  closeWin : function(params){
    ydk._invoke('closeWin' , omit(params) , params);
  },

  /**
   * 检测更新
   */
  checkUpdate : function(params){
    ydk._invoke('checkUpdate' , {} , params);
  },

  /**
   * 设置窗口高度
   */
  setWinHeight : function(params){
    ydk._invoke('setWinHeight' , omit(params) , params);
  },

  /**
   * 设置窗口宽高
   */
  setWinSize : function(params){
    ydk._invoke('setWinSize' , omit(params) , params);
  },

  /**
   * 词典设置更新
   * (只有客户端修改了设置项，才会更新，saveSetting不会触发)
   */
  onSettingChange : function(params){
    ydk._on('onSettingChange', {} , params);
  },

  /**
   * 激活词典，置于最前
   */
  setTop : function(params){
    ydk._invoke('setTop' , {} , params);
  },

  /**
   * 检查单词是否添加到单词本
   */
  checkWordBook : function(params){
    ydk._invoke('checkWordBook' , {
      word : params.word,
      lang : params.lang
    } , params);
  },

  removeFromWordBook : function(params){
    ydk._invoke('removeFromWordBook' , omit(params) , params);
  },

  addToWordBook : function(params){
    ydk._invoke('addToWordBook' , omit(params) , params);
  },

  updateToWordBook : function(params){
    ydk._invoke('updateToWordBook' , omit(params) , params);
  },
  
  /**
   * 同步单词本
   */
  syncWordBook : function(params){
    ydk._invoke('syncWordBook' , {} , params);
  },

  /**
   * 读取单词本
   */
  queryWordBook : function(params){
    ydk._invoke('queryWordBook' , omit(params) , params);
  },

  /**
   * 单词本变更
   */
  onWordBookChanged : function(params){
    ydk._on('onWordBookChanged', {} , params);
  },

  /**
   * 读取单词本分组
   */
  queryWordBookCategory : function(params){
    ydk._invoke('queryWordBookCategory' , omit(params) , params);
  },

  /**
   * 新增单词本分组
   */
  addWordBookCategory : function(params){
    ydk._invoke('addWordBookCategory' , omit(params) , params);
  },

  /**
   * 修改单词本分组
   */
  updateWordBookCategory : function(params){
    ydk._invoke('updateWordBookCategory' , omit(params) , params);
  },

  /**
   * 删除单词本分组
   */
  removeWordBookCategory : function(params){
    ydk._invoke('removeWordBookCategory' , omit(params) , params);
  },

  /**
   * 导入单词本
   */
  importToWordBook : function(params){
    ydk._invoke('importToWordBook' , omit(params) , params);
  },

  /**
   * 读取需要复习的单词
   */
  queryWordBookForReview : function(params){
    ydk._invoke('queryWordBookForReview' , omit(params) , params);
  },

  /**
   * 复习单词-记得/不记得
   */
  reviewWordBook : function(params){
    ydk._invoke('reviewWordBook' , omit(params) , params);
  },

  /**
   * 导出单词本
   */
  exportFromWordBook : function(params){
    ydk._invoke('exportFromWordBook' , omit(params) , params);
  },

  /**
   * 取消导出单词本
   */
  cancleExportFromWordBook : function(params){
    ydk._invoke('cancleExportFromWordBook' , omit(params) , params);
  },

  /**
   * 批量修改单词分组
   */
  setWordBookCategory : function(params){
    ydk._invoke('setWordBookCategory' , omit(params) , params);
  },

  /**
   * 批量单词是否加入复习计划
   */
  setWordBookPlan : function(params){
    ydk._invoke('setWordBookPlan' , omit(params) , params);
  },
  /**
   * 最小化窗口
   */
  minimizeWin : function(){
    ydk._invoke('minimizeWin' , {} , {});
  },

  /**
   * 设置debug模式
   */
  setDebug : function(params){
    ydk._invoke('setDebug' , omit(params) , params);
  },

  /**
   * 设置窗口可移动
   */
  setWinMove : function(params){
    ydk._invoke('setWinMove' , {} , params);
  },

  /**
   * 显示当前cef窗口
   */
  showWin : function(params){
    ydk._invoke('showWin' , {} , params);
  },
  
  //显示离线下载弹窗
  openOfflineDictWin : function(params){
    ydk._invoke('openOfflineDictWin' , {} , params);
  },

  /**
   * 获取OCR模型列表
   */
  getOcrModelList : function(params){
    ydk._invoke('getOcrModelList' , {} , params);
  },

  /**
   * 下载/更新OCR模式文件
   */
  downloadOcrModel : function(params){
    ydk._invoke('downloadOcrModel' , omit(params) , params);
  },

  /**
   * 删除OCR模型文件
   */
  removeOcrModel : function(params){
    params = omit(params);
    ydk._invoke('removeOcrModel' , params , params);
  },


  /**
   * 下载进度
   */
  onDownloadProgress : function(params){
    ydk._on('onDownloadProgress' , {} , params);
  },

  /**
   * 下载浏览器插件
   */
  downloadBrowserPlugin : function(params){
    params = omit(params);
    ydk._invoke('downloadBrowserPlugin' , params , params);
  },

  /**
   * 当主窗口右侧页面加载
   */
  onPageLoadStart : function(params){
    ydk._on('onPageLoadStart' , {} , params);
  },

  /**
   * 保存缓存(基于内存)
   */
  saveCache : function(params){
    params = omit(params);
    ydk._invoke('saveCache' , omit(params) , params);
  },

  /**
   * 读取缓存
   */
  getCache : function(params){
    ydk._invoke('getCache' , omit(params) , params);
  },

  /**
   * 删除缓存
   */
  removeCache : function(params){
    params = omit(params);
    ydk._invoke('removeCache' , params , params);
  },

  /**
   * 清空缓存
   */
  clearCache : function(params){
    params = omit(params);
    ydk._invoke('clearCache' , params , params);
  },
  /**
   * 打开一个新的cef窗口
   */
  openWin : function(params){
    params = omit(params);
    ydk._invoke('openWin' , params , params);
  },
  /**
   * 调用客户端发音
   */
  playNativeVoice : function(params){
    params = omit(params);
    ydk._invoke('playNativeVoice' , params , params);
  },
  /**
   * 调用客户端停止发音
   */
  stopNativeVoice : function(params){
    ydk._invoke('stopNativeVoice' , {} , {});
  },
  /**
   * 设置搜索框焦点
   */
  setQueryFocus : function(params){
    ydk._invoke('setQueryFocus' , omit(params) , params);
  },
  /**
   * 设置搜索框全选
   */
  setQuerySelectAll : function(params){
    ydk._invoke('setQuerySelectAll' , {} , {})
  },
  /**
   * 监听客户端登陆状态
   */
  onLoginStatusChanged : function(params){
    ydk._on('onLoginStatusChanged' , {} , params)
  },
  /**
   * 监听快捷键响应
   */
  onHotKey : function(params){
    ydk._on('onHotKey' , {} , params)
  },
  /**
   * 更新窗口排序
   */
  updateWinZOrder : function(params){
    ydk._invoke('updateWinZOrder' , {} , params);
  },
  /**
   * 获取离线词库
   */
  getOfflineLexiconList : function(params){
    ydk._invoke('getOfflineLexiconList' , {} , params)
  },
  /**
   * 下载/更新离线词库
   */
  downloadOfflineLexicon : function(params){
    ydk._invoke('downloadOfflineLexicon' , omit(params) , params)
  },
  /**
   * 删除离线词库
   */
  removeOfflineLexicon : function(params){
    ydk._invoke('removeOfflineLexicon' , omit(params) , params)
  },
  /**
   * 下载进度
   */
  onLoadOfflineLexiconProgress : function(params){
    ydk._on('onLoadOfflineLexiconProgress' , {} , params)
  },
  /**
   * 暂停/开始下载
   */
  stopLoadOfflineLexicon : function(params){
    ydk._invoke('stopLoadOfflineLexicon' , params , params)
  },

  /**
   * 监听vip状态
   */
  onVipInfoGot : function(params){
    ydk._on('onVipInfoGot' , {} , params)
  },
    
  /**
   * 通知客户端更新vip信息
   */
  refreshVipInfo : function(params){
    ydk._invoke('refreshVipInfo' , {} , params)
  },
  
  //获取用户信息
  getProfile : function(params){
    ydk._invoke('getProfile' , {} ,  params)
  },
  
  //设置用户信息
  setProfile : function(params){
    ydk._invoke('setProfile' , omit(params) ,  params)
  },    
  
  //表示要检查的昵称，返回一个nStatusCode
  //0表示可用，其他值表示不可用
  checkNickname : function(params){
    ydk._invoke('checkNickname' , omit(params) ,  params)
  },
  
  //获取昵称
  getNickname : function(params){
    ydk._invoke('getNickname' , {} ,  params)
  },

  clearHistory : function(params){
    ydk._invoke('clearHistory' , {} , params);
  },

  /**
   * 添加历史记录
   */
  addHistory : function(params){
    ydk._invoke('addHistory' , omit(params) , params);
  },

  //设置昵称
  setNickname : function(params){
    ydk._invoke('setNickname' , omit(params) ,  params);
  },

  /**
   * 打开单词本卡片模式
   */
  showWordbookCardModel : function(params){
    ydk._on('showWordbookCardModel', {} , params);
  },
  /**
   * 获取文档翻译结果
   */
  showTransResult : function(params){
    ydk._on('showTransResult', {} , params);
  },
  /**
   * 打开单词本详细结果
   */
  showWordbookDetail : function(params){
    ydk._on('showWordbookDetail', {} , params);
  },
  /**
   * 打开单词本复习页面
   */
  showWordbookReviewModel : function(params){
    ydk._on('showWordbookReviewModel', {} , params);
  },
  /**
   * 打开单词本添加单词页面
   */
  showWordbookAdd : function(params){
    ydk._on('showWordbookAdd', {} , params);
  },
  /**
   * 单词本卡片模式自动播放
   */
  wordbookCardPlay : function(params){
    ydk._on('wordbookCardPlay', {} , params);
  },
  /**
   * 打开单词本导出
   */
  openWordBookExportPage : function(params){
    ydk._on('openWordBookExportPage', {} , params);
  },
  /**
   * 打开单词本设置页
   */
  openWordbookSettingPage : function(params){
    ydk._on('openWordbookSettingPage', {} , params);
  },

  //打开vip页面
  openVip : function(params){
    ydk._invoke('openVip' , omit(params) , params);
  },

  //打开新窗口加载页面
  newCefLoadingPage : function(params){
    ydk._on('newCefLoadingPage' , {} , params);
  },

  //单词本加载页面
  wbLoadingPage : function(params){
    ydk._on('wbLoadingPage' , {} , params);
  },

  /**
   * 单词本变更通知单词本刷新
   */
  simpleWordbookChange : function(params){
    ydk._on('simpleWordbookChange', {} , params);
  },
 
  //加载文档翻译结果
  loadDTResult : function(params){
    ydk._invoke('loadDTResult', omit(params) , params);
  },

  /**
   * 通知客户端文档翻译已经付费
   */
  refreshDocPaySuccessInfo : function(params){
    ydk._invoke('refreshDocPaySuccessInfo' , omit(params) , params)
  }, 
  
  //通过客户端更新cefCookie
  updateCefCookie : function(params){
    ydk._invoke('updateCefCookie' , {} , params)
  }, 

  
  //页面渲染成功给客户端的回调（测试用）
  renderFinish : function(params){
    ydk._invoke('renderFinish', omit(params) , params);
  },

  //input - translated contrast
  doContrast: function(params){
    ydk._invoke('highlightRange', omit(params), params);
  },
  
  //获取离线资源包信息
  getResourceInfo: function(params){
    ydk._invoke('getResourceInfo', omit(params), params);
  },

  //开始下载离线资源包(type, id, url)
  startDownloadResource : function(params){
    ydk._invoke('startDownloadResource', omit(params), params);
  },

  //暂停下载离线资源包 ： 参数 type, id
  pauseDownloadResource : function(params){
    ydk._invoke('pauseDownloadResource', omit(params), params);
  },

  //恢复下载离线资源包： 参数： type, id
  resumeDownloadResource : function(params){
    ydk._invoke('resumeDownloadResource', omit(params), params);
  },

  //放弃下载离线资源包： 参数： type, id
  stopDownloadResource : function(params){
    ydk._invoke('stopDownloadResource', omit(params), params);
  },
  
  //删除下载 参数 type, id
  deleteResource : function(params){
    ydk._invoke('deleteResource', omit(params), params);
  },

  //离线资源包下载进度：type, id,  
  //返回rate. rate是百分比30表示下载了30%
  //rate如果是-1的话表示下载失败
  onDownloadResourceProgress: function(params){
    ydk._on('onDownloadResourceProgress', omit(params) , params);
  },

  /**
   * 翻译页面监听这个，参数分别是srcLang 和 dstLang
   */
  onTransLangChanged : function(params){
    ydk._on('onTransLangChanged', {} , params);
  },
  
  /**
   * 设置翻译tab
   * transContent,
   * srcLang,
   * dstLang
   */   
  setTranslateContent : function(params){
    ydk._on('setTranslateContent', {} , params);
  },

  //获取屏幕dpi
  //type：“mini” “stroke”
  getWndDpi: function(params){
    ydk._invoke('getWndDpi', omit(params) ,  params);
  },
  
  //通知客户端前端事件
  //document：整个文档
  onTriggerWebEvent: function(params){
    ydk._invoke('onTriggerWebEvent', omit(params) , params);
  },

  /**
   * 获取语法检测结果
   */
  getGrammarText : function(params){
    ydk._invoke('getGrammarText', params , params);
  }
    
});


