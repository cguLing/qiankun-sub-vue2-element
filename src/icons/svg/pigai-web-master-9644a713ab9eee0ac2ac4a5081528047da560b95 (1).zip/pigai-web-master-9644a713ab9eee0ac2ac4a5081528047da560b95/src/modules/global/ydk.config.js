import event from 'event';
import config from 'config';

ydk.config({
  debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
  jsApiList: [
    'checkJsApi',
    'getClientInfo',
    'getNetworkType',
    // 'onNetStatusChange',
    'getOrientationStatus',
    'onOrientationChange',
    'share',

    'playVoice',
    'pauseVoice',
    'stopVoice',
    'onVoicePlayEnd',
    'onVoicePlayProgress',


    'downloadImage',

    'ajax',

    'isLogin',
    'login',
    'getUserInfo',
    'onVipInfoGot',

    'rlog', // 发log
    'onPageVisibilityChange',
    'onKeywordChanged',
    'onNativeKeyDown',
    'copyToClipboard',

    'getNetworkType',
    'onNetStatusChange',
    'broadcast',
    'onBroadcast',
    'setHasHistory',
    'onHistory',
    'onCornerPopupShow',
    'onStrokeResult',
    'onSettingChange',
    'onPageLoadStart',
    'openWin',
    'playNativeVoice',
    'stopNativeVoice',
    'highlightRange',
    'getResourceInfo'
  ]
});


ydk.getClientInfo({
  success : function (res) {
    if(config.debug){
      res.debug = true;
    }
    ydk.client = res;
    event.trigger('ydk.ready' , res);
  }
});


