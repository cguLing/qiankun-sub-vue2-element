import '../rlog';

// 初始化jssdk
import './ydk.extend.js';
import './ydk.simulate.extend.js';
import './ydk.config.js';
