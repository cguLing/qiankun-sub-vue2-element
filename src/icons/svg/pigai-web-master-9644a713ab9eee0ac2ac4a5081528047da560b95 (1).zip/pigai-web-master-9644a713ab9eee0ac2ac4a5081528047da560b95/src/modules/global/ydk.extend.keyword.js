/**
 * 由于PC客户端部分接口实现起来挺费劲，因此部分接口，由前端模拟实现
 *
 * ydk文档:
 * https://gitlab.corp.youdao.com/webfront-public-service/dict_js_sdk/tree/master/javascript
 */

var bridge = window.YoudaoWebJavascriptBridge;

/**
 * 复制自:
 * https://gitlab.corp.youdao.com/webfront-public-service/dict_js_sdk/blob/master/javascript/src/WebJavascriptBridge.js
 */
function _callback (callName, res, oriData) {
  var code = res.code;
  oriData.permanent && (res.permanent = oriData.permanent);
  oriData._complete && oriData._complete(res);
  if (debug){
    console.log('_callback', callName, oriData, res);
  }
  switch (code) {
    case 1000 :
      oriData.success && oriData.success(res);
      break;
    case 1001 :
      oriData.cancel && oriData.cancel(res);
      break;
    default :
      oriData.fail && oriData.fail(res);
      break;
  }
  oriData.complete && oriData.complete(res);
}

var callHandler = function(callName, reqData){
  bridge.callHandler(
    callName ,
    reqData ,

     // 当参数中指定了 silence 为 true 时，不执行任何回调
    reqData.silence ? null : function (res) {
      _callback(callName, res, reqData);
    }
  );
}

var _callExcends = {};
[
  'playVoice' , 
  'pauseVoice' , 
  'stopVoice'
].forEach(function(name){
  _callExcends[name] = function(params){
    callHandler(name , params);
  };
});


[
  'onVoicePause' , 
  'onVoicePlayEnd' , 
  'onVoicePlayProgress' , 
  'onPageVisibilityChange'
].forEach(function(name){
  _callExcends[name] = function(params){
    bridge.registerHandler(name , params);
  };
});

ydk.extend(_callExcends);

//当页面隐藏时候，停止当前页面的音频  
ydk.onPageVisibilityChange({
  success : function(res){
    if(res.hidden){
      ydk.stopVoice({});
    }
  }  
})