//当页面隐藏时候，停止当前页面的音频
ydk.onPageVisibilityChange({
  success : function(res){
    if(res.hidden){
      ydk.stopVoice({});
    }
  }
})