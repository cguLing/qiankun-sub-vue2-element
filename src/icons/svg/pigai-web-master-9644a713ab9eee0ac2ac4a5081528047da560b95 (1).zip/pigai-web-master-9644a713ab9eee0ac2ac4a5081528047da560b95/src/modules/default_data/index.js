/**
 * http://note.youdao.com/share/?id=0ad08f5802fe9016b1956ff59db0527b&type=note#/
 */
import daily from './daily.js';

var data = {
  head : daily,
  cards : [{//1
    comment: 0,
    id: 0,
    image: 'assets/default_data/1-1007453.jpg',
    like: 0,
    style: '',
    summary: '在这个人人学英语的时代，大家似乎都快忘了，中文有多美多强大！这里有一段英文的诗歌，有人用中文翻译了一下，结果所有人都惊呆了！！！',
    title: '你知道一首英文诗翻译成中文以后有多美吗？',
    type: '',
    url: 'http://xue.youdao.com/sw/m/1007453?vendor=dict_default_data'
  }, {//2
    comment: 0,
    id: 0,
    image: 'assets/default_data/2-1011621.jpg',
    like: 0,
    style: '',
    summary: '英文学以致用，领略语言之美。有道词典，不只是查单词，还带你看天下。英文中有一种地道的表达方法——“似是而非”。',
    title: '来挑战吧！90%的人都理解错的英文句子',
    type: '',
    url: 'http://xue.youdao.com/sw/m/1011621?vendor=dict_default_data'
  }, {//3
    comment: 0,
    id: 0,
    image: 'assets/default_data/3-1025416.jpg',
    like: 0,
    style: '',
    summary: '相传，学好的英语的最高境界，就是把歪果仁的思维逻辑操纵于股掌之间，这样才能妥妥甩掉Chinglish，化身英语学神一尊！',
    title: '中英文神相似的30个成语翻译，看完再也忘不掉啦！',
    type: '',
    url: 'http://xue.youdao.com/sw/m/1025416?vendor=dict_default_data'
  }, {//4
    comment: 0,
    id: 0,
    image: 'assets/default_data/4-1115146.jpg',
    like: 0,
    style: '',
    summary: '小编带着大家集体揭伤疤，搜罗那些我们念错好多年的英文单词……这里列出了 22 个，全部带上音标和易错点，有勇气就看下去吧……',
    title: '那些年念错的英文词，你膝盖中了几箭？',
    type: '',
    url: 'http://xue.youdao.com/sw/m/1115146?vendor=dict_default_data'
  }, {//5
    comment: 0,
    id: 0,
    image: 'assets/default_data/5-1137302.jpg',
    like: 0,
    style: '',
    summary: '读了这么多年的单词，才发现都读错了...这些单词的正确发音究竟是什么？快看看。',
    title: '纠正13个你常读错的单词发音！从此口语so easy！',
    type: '',
    url: 'http://xue.youdao.com/sw/m/1137302?vendor=dict_default_data'
  }, {//6
    comment: 0,
    id: 0,
    image: 'assets/default_data/6-1005831.jpg',
    like: 0,
    style: '',
    summary: '星座总让人着迷！我们总想知道何时有最好的运气，恨不能把每天，每星期，每个月的运势都摸透。那如果星座能预测你恋爱时的样子呢？',
    title: '怦然心动是种什么感觉?让星座来告诉你',
    type: '',
    url: 'http://xue.youdao.com/sw/m/1005831?vendor=dict_default_data'
  }, {//7
    comment: 0,
    id: 0,
    image: 'assets/default_data/7-1013797.jpg',
    like: 0,
    style: '',
    summary: '满口英伦腔的不一定说得好正经英式英语，脱口就是美剧范儿的也不见得都是标准美语。对于爱学英语小伙伴们来说，就算把语音模仿到天衣无缝，稍不留神还会被人戳穿',
    title: '太形象了！史上最全英语和美语对比图解',
    type: '',
    url: 'http://xue.youdao.com/sw/m/1013797?vendor=dict_default_data'
  }, {//8
    comment: 0,
    id: 0,
    image: 'assets/default_data/8-1175872.jpg',
    like: 0,
    style: '',
    summary: '最近，微微一笑很倾城正在火力热播中，随着剧情的不断推进，微微和大神的爱情也渐渐白热化。一连几天都高甜预警，时不时就来个热吻，再种个草莓，老夫的少女心真是经不起折腾。',
    title: '看微微一笑，吃饱狗粮的你知道怎么用英文优雅地叫大神吗？',
    type: '',
    url: 'http://xue.youdao.com/sw/m/1175872?vendor=dict_default_data'
  }, {//9
    comment: 0,
    id: 0,
    image: 'assets/default_data/9-1063288.jpg',
    like: 0,
    style: '',
    summary: '“多少年我们苦练英文发音和文法，这几年换他们卷着舌头学平上去入的变化”不知道还有多少人记得当年《中国话》的歌词呢？',
    title: '我们死磕英语的时候，有些歪果仁...貌似被中文折磨地也不轻…',
    type: '',
    url: 'http://xue.youdao.com/sw/m/1063288?vendor=dict_default_data'
  }, {//10
    comment: 0,
    id: 0,
    image: 'assets/default_data/10-1186646.jpg',
    like: 0,
    style: '',
    summary: '她是亚美尼亚人，而他是阿塞拜疆人，他们是一堆恩爱的跨国夫妻。然而战乱频繁，他和她成了现实版的罗密欧与茱丽叶。',
    title: '被战争斩断的爱：天长地久有时尽，此恨绵绵无绝期',
    type: '',
    url: 'http://xue.youdao.com/sw/m/1186646?vendor=dict_default_data'
  }]
};

/**
 * 模仿ydk接口数据格式
 */
export default {
  code : 1000,
  data : data
};