//import Hammer from 'commons/hammer.min.js';

const tabs = {};

// delete Hammer.defaults.cssProps.userSelect;

function ns(name) {
  var keys = name.split(':');
  var group = 'default';

  if(keys.length > 1){
    group = keys[0] || 'default';
    name = keys[1];
  }

  return {
    group : group,
    name : name
  };
}


function getTab(group){
  return tabs[group] || (tabs[group] = {
    headers : {},
    bodys : {},
    active : null
  });
}


// function prev(group , name){
//   var tab = getTab(group);
//   var keys = Object.keys(tab.headers);
//   for(var i = 0 , len = keys.length ; i < len ; i++){
//     if(keys[i] == name){
//       active(group + ':' + keys[(len + i - 1) % len]);
//     }
//   }
// }

// function next(group , name){
//   var tab = getTab(group);
//   var keys = Object.keys(tab.headers);
//   for(var i = 0 , len = keys.length ; i < len ; i++){
//     if(keys[i] == name){
//       active(group + ':' + keys[(len + i + 1) % len]);
//     }
//   }
// }

export function bindHeader(el , name , isActive) {
  var keys = ns(name);
  var tname = keys.name;
  var group = keys.group;
  var $el = $(el);
  var tab = getTab(group);

  //选中值
  tab.headers[tname] = $el;
  if(isActive){
    active(name);
  }
};

export function bindBody(el , name) {
  var keys = ns(name);
  name = keys.name;
  var group = keys.group;
  var $el = $(el);
  var tab = getTab(group);

  if(tab.active == name){
    $el.addClass('active').show();
  }else{
    $el.hide();
  }

  tab.bodys[name] = $el;

  // var hammertime = new Hammer($el[0], {
  //   inputClass: Hammer.TouchInput//仅需要支持移动端
  // });
  // hammertime.on('swipeleft' , function(){
  //   next(group , name);
  // });

  // hammertime.on('swiperight' , function(){
  //   prev(group , name);
  // });
};

export function active(name) {
  var keys = ns(name);

  var tab = getTab(keys.group);
  tab.active = keys.name;

  //切换样式
  Object.keys(tab.headers).forEach(function(k){
    if(keys.name == k){
      tab.headers[k].addClass('active');
      tab.bodys[k] && tab.bodys[k].addClass('active').show();
    }else{
      tab.headers[k].removeClass('active');
      tab.bodys[k] && tab.bodys[k].removeClass('active').hide();
    }
  });

};

export function unbind(name){
  var 
    keys = ns(name),
    tab = getTab(keys.group);

  delete tab.headers[keys.name];
  delete tab.bodys[keys.name];

  //当删除当前选中的tab，重置当前的tab为第一个
  if(tab.active == keys.name){
    var first = Object.keys(tab.headers)[0];
    first && active([keys.group , first].join(':'));
  }
};