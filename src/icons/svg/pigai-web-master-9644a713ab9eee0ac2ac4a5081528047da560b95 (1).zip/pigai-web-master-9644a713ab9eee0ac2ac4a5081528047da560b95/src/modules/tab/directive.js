import * as Store from './store.js';
import Vue from 'vue';

Vue.directive('tab' , {
  literal : true,
  bind : function(el , binding){
    var argument = binding.arg; //传给指令的参数    
    var exp = binding.expression; //参数名称
    var modifiers = binding.modifiers; //一个包含修饰符的对象
   
    if(argument == 'header'){
      var active = $(el).attr('active');
      var isActive = typeof(active) == 'string' ? (active == 'true') : modifiers.active;
      Store.bindHeader(el , exp , isActive || modifiers.active);
      $(el).off('click').on('click' , function(e){
        Store.active(exp);
      });
    }else if(argument == 'body'){
      Store.bindBody(el , exp);
    }
  },
  update : function(el , binding){
    var argument = binding.arg;    
    var exp = binding.expression; 
    var modifiers = binding.modifiers; 
    if(binding.value !== binding.oldValue){
      if(argument == 'header'){
        var active = $(el).attr('active');
        var isActive = typeof(active) == 'string' ? (active == 'true') : modifiers.active;
        Store.bindHeader(el , exp , isActive || modifiers.active);
        $(el).off('click').on('click' , function(e){
          Store.active(exp);
        });      
      }else if(argument == 'body'){
        Store.bindBody(el , exp);
      }
    }    
  },
  unbind : function(el , binding){
    var argument = binding.arg; 
    var exp = binding.expression;   
    if(argument == 'header' || argument == 'body'){
      Store.unbind(exp);
    }
  } 
})
