import config from 'config';
import * as clienter from 'modules/clienter';

var query = function(params , extend){
  if(extend){
    params.data = $.extend({
      client : 'deskdict',
      id : ydk.client.imei,
      vendor : ydk.client.vendor,
      appVer : ydk.client.version,
      keyfrom : ydk.client.keyfrom,
      abtest : ydk.client.abtest
    } , params.data);
  }
  ydk.ajax(params);
};


var api = function(params , extend){
  params.url = (/^http/.test(params.url) ? params.url :  config.server + params.url);
  params.type = params.type || 'GET';

  if(!extend){
    query(params , extend);
  }else{
    clienter.ready(() => {
      query(params , extend);
    })
  }
}

export default api;