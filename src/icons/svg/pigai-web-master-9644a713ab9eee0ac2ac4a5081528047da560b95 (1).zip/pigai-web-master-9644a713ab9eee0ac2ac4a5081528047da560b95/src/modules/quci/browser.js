/**
 * IOS 客户端的点击取词
 * To change this template use File | Settings | File Templates.
 */
(function () {
  'use strict';
  var quci = require('./index');
  quci.init();
  // container 防止在取词框再次取词,设置取词范围在文章内部
  var container = 'doc'; // 文章内部元素id

  var targetTouch, //Touch point
    targetCoord = {}, //Current Touch events coordinates
    targetRealCoord = {}, // 目标位置修正，不用事件，改用range方法获取真实位置
    currentWord, //Word detected and waited to be looked up
    content, //range content
    range, //the selected range
    click, //click or tab
    driver,
    isDisabled = false, //为 true 时，取词将不可用
    highlightNode, //当前高亮的节点
    ignored = ['video', 'audio', 'img', 'a'],
    ua = navigator.userAgent.toLowerCase();
    console.log(ua);

  //Regular Expressing declaration
  var isEngWord = function (chars) {
    return (/^[a-zA-Z\-]+$/).test(chars);
  };

  //Highlight adding and removing
  var highlightTargetHtml = function () {
    highlightNode = document.getElementsByClassName('hl')[0]
    if (!highlightNode) {
      highlightNode = document.createElement('div')
      highlightNode.className = 'hl'
      document.getElementsByTagName('body')[0].appendChild(highlightNode)
    }
    highlightNode.style.display = 'block'
    var rect = range.getBoundingClientRect()
    var t = document.documentElement || document.body.parentNode
    // var scrollTop = (typeof t.scrollTop == 'number' ? t : document.body).scrollTop
    var scrollTop = Math.max(scrollTop, document.body.scrollTop)
    highlightNode.style.width = (rect.width) + 'px';
    highlightNode.style.height = (rect.height + 1) + 'px';
    highlightNode.style.left = rect.left + 'px';
    var y = rect.y || rect.top
    highlightNode.style.top = (scrollTop + y) + 'px';
    if (window.getComputedStyle) {
      highlightNode.style.fontSize = window.getComputedStyle(range.startContainer.parentNode).fontSize;
    }
    content = range.cloneContents();
    // console.log(targetRealCoord.cx,rect.left,scrollTop+targetRealCoord.cy,scrollTop + rect.y)
    highlightNode.innerText = content.textContent.trim()
    // content = range.extractContents();
    // var node = highlightNode = document.createElement('span');
    // node.className = 'hl';
    // node.innerHTML = content.textContent;
    // range.insertNode(node);
  };

  var removeHighlight = function () {
    if (!range || !content || !highlightNode) {
      return;
    }

    highlightNode.style.display = 'none'
    range = null;
  };


  var hideResult = function () {
    //加个这个 try catch 防止报错让程序不能正常运行
    // for  android  --> 可以点击空白消失 (ios不用做这样的处理)
    if (driver.closeNativeQueryWord) {
      driver.closeNativeQueryWord();
    }
    removeHighlight();
    quci.hide();
  };

  /**
   * get word by caretRangeFromPoint API
   * @param  {int} x
   * @param  {int} y
   * @return {string}
   */
  var getWord = function (x, y) {
    range = document.caretRangeFromPoint(x, y);
    if (!range) {
      return '';
    }

    range.expand('word');
    targetRealCoord.cx = range.getBoundingClientRect().left;
    targetRealCoord.cy = range.getBoundingClientRect().top;
    return range.cloneContents().textContent.trim();
  };

  /**
   * main function trigered to run them all~
   * @param  event
   */
  var mainDic = function (event, isDbclick = false) {
    if (!filterNode(event.target)) return;
    if (range) {
      hideResult();
      return
    }

    if (isDisabled) return;

    var webster = document.getElementsByClassName('webster')[0]
    var oxford = document.getElementsByClassName('oxford')[0]
    webster && (webster.setAttribute('style', 'user-select:text;-webkit-user-select:text'))
    oxford && (oxford.setAttribute('style', 'user-select:text;-webkit-user-select:text'))

    targetTouch = isDbclick ? event : event.touches[0];
    targetCoord.px = targetTouch.pageX;
    targetCoord.py = targetTouch.pageY;
    targetCoord.cx = targetTouch.clientX;
    targetCoord.cy = targetTouch.clientY;
    var element = document.elementFromPoint(targetCoord.cx, targetCoord.cy);

    if (element.className.indexOf('pos') > -1 || element.className.indexOf('inline-icon') > -1) {
      webster && (webster.setAttribute('style', 'user-select:none;-webkit-user-select:none'))
      oxford && (oxford.setAttribute('style', 'user-select:none;-webkit-user-select:none'))
      event.stopPropagation();
      return;
    }
    if (ignored.indexOf(element.tagName.toLowerCase()) > -1) {
      webster && (webster.setAttribute('style', 'user-select:none;-webkit-user-select:none'))
      oxford && (oxford.setAttribute('style', 'user-select:none;-webkit-user-select:none'))
      event.stopPropagation();
      return;
    }
    currentWord = getWord(targetCoord.cx, targetCoord.cy);

    webster && (webster.setAttribute('style', 'user-select:none;-webkit-user-select:none'))
    oxford && (oxford.setAttribute('style', 'user-select:none;-webkit-user-select:none'))

    if (!isEngWord(currentWord) || element.innerText.indexOf(currentWord) < 0) {
      //no english or the word is not in the selected element
      range = null;
      return;
    }

    highlightTargetHtml();
    // console.log(currentWord, targetRealCoord.cx + highlightNode.offsetWidth / 2, targetRealCoord.cy + highlightNode.offsetHeight / 2)

    exec({
      word: currentWord,
      pos: {
        x: Math.floor(targetRealCoord.cx + highlightNode.offsetWidth / 2),
        y: Math.floor(targetRealCoord.cy + highlightNode.offsetHeight / 2)
      }
    })
  };

  var tapHoldTriger = null,
    move = false,
    startE = null,
    init = function (mode, scrollContainerId) {
      // var body = document.body;
      var body = document.getElementById(container) || window;
      click = mode === 'click';
      driver = window.dict ? window.dict : {};

      // 文档的取词滚动窗口是‘scroll_wrap’
      var scrollContainer = document.getElementById(scrollContainerId);
      
      scrollContainer.addEventListener('scroll', winScroll);
      function winScroll(e) {
        hideResult();
      }


      // 移动端手指点击单词监听事件
      body.addEventListener("touchstart", function (event) {
        move = false;
        startE = event;
        if (!click) {
          tapHoldTriger = setTimeout(function () {
            mainDic(startE);
          }, 500);
        }
      }, false);
      body.addEventListener("touchmove", function () {
        move = true;
        clearTimeout(tapHoldTriger);
      }, false);
      body.addEventListener("touchend", function () {

        clearTimeout(tapHoldTriger);
        if (!move && click) {
          mainDic(startE);
        }
      }, false);

      // web端鼠标双击单词监听事件
      body.addEventListener('dblclick', function (event) {
        move = false;
        startE = event;
        tapHoldTriger = setTimeout(function () {
          mainDic(startE, true);
        }, 500);
      });

      body.addEventListener("click", function (event) {
       hideResult();
      }, false);



      var styleTag = document.createElement('style'),
        defaultCSS = ([
          '.hl{',
          'background-color: #F5E4BA;',
          'color: #6C717A;',
          'position:absolute',
          '}'
        ]).join('\n');
      styleTag.id = 'catchword-style';
      styleTag.innerHTML = defaultCSS;
      document.querySelector('head').appendChild(styleTag);
    };

  //调用客户端接口进行查词
  var exec = function (opt) {
    opt.webViewWidth = window.innerWidth;
    opt.webViewHeight = window.innerHeight;

    quci.query(opt);
  };

  //检查当前用户点击的目标是否是a标签
  var filterNode = function (node) {
    var result = true;
    while (node != document.body) {
      if (node && node.tagName.toLowerCase() == "a") {
        result = false;
        break;
      } else {
        node = node.parentNode;
      }
    }
    return result;
  }

  window.catchWord = {
    init: init,
    setDisabled: function (val) {
      isDisabled = !!val;
    },
    hideResult: hideResult
  };
  // init('click');
}());