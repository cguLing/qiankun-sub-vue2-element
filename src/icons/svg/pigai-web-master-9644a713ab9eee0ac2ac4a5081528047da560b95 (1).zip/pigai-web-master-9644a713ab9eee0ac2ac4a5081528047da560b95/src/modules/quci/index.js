import Utils from '@/commons/utils';
import filter from './filter';
import template from './index.html';
import './index.scss';

/**
 * 取词接口(只能取英文)
 * @params opt
 * 所取词的信息
 * {
 *  pos:{x, y}  坐标
 *  webViewHeight 网页高度
 *  webViewWidth  网页宽度
 *  word 所取词字符串
 * }
 * */
window.quciContainer = null;
var quciContainerClassName = '.quci-container',
  quciTrangleClassName = '.triangle',
  quciCollectClassName = '.quci-collect',
  collectedClassName = 'collected',
  uncollectedClassName = 'uncollected',
  speechButtonClassName = '.speech-icon',
  triangleHeight = 15,
  triangleWidth = 13;
var table = '';

function Quci(opt) {
}

Quci.init = function () {
  console.log('取词功能启动!!!');
  var self = this;
  table =  '';

  // $(document.body).on('touchstart', function (event) {
  //   event.stopPropagation();
  //   self.hide();
  // });

};


Quci.query = function (opt) {
  opt.word = opt.word.toLowerCase();
  // 取词log
  // rlog({
  //   'action': 'quci_article_click',
  //   'base_url': location.href,
  //   'table': table,
  //   'word': opt.word
  // });

  Utils.server({
    url: 'https://dict.youdao.com/fsearch?keyfrom=deskdict.screentrans.http.0.stroke&pos=-1&doctype=xml&xmlVersion=9.1&dogVersion=1.0&client=deskdict&id=7a029b62eef9df824&in=SwWeb&fytype=AUTO',
    data: {
      q: opt.word,
      le: 'cn' || 'auto'
    },
    dataType: 'text', // 只能设置为text/xml形式
    type: 'GET',
    success: function (res) {
      // console.log('res:', res)
      // alert('取词成功:'+ opt.word)
      var ret = filter({
        result: res,
        word: opt.word
      });

      var result = {
        ret: ret,
        opt: opt
      };

      // console.log('opt:', opt);
      // console.log('ret:', ret);


      // 渲染词
      Quci.show(result);

      // 检查该词是否已被收藏过
      //Quci.checkIsCollected(result);
    }
  })
};

Quci.show = function (data) {
  var self = this;
  // 量位置,确定展示位置是词语上面还是下面
  // 正数,则在展示下方,负数展示在上方
  var webH = data.opt.webViewHeight,
    webW = data.opt.webViewWidth,
    posX = data.opt.pos.x,
    posY = data.opt.pos.y,
    _modH = Number(webH / 2 - posY),
    _modW = Number(webW / 2 - posX),
    direction = _modH > 0 ? 'below' : 'above',
    v_direction = _modW > 0 ? 'left' : 'right',
    _height = 0,
    _triangleHeight = triangleHeight,
    _triangleWidth = triangleWidth,
    _left = 0,
    _vgap = 35 / 2,
    _hgap = 0;


  // 渲染取词框到页面上
  var _temp = template($.extend({}, data, {
    table:table,
    direction: direction
  }));
  $(document.body).append(_temp);

  // 是否pc
  function IsPC() {
    var userAgentInfo = navigator.userAgent;
    var Agents = ["Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod"];
    var flag = true;
    for (var v = 0; v < Agents.length; v++) {
      if (userAgentInfo.indexOf(Agents[v]) > 0) {
        flag = false;
        break;
      }
    }
    return flag;
  }

  function filterQuciContianerLeftPosition(positionX, minPadding, containerWidth, webViewW, direction){
    var leftPosition = positionX;
    if ((positionX - minPadding) <= (containerWidth / 2) && direction == 'left'){
      leftPosition = containerWidth / 2 + minPadding;
    } else if ((webViewW - positionX + minPadding) <= (containerWidth / 2) && direction == 'right'){
      leftPosition = containerWidth / 2 - minPadding;
    }

    return leftPosition;
  }


  // 设置取词框坐标
  _height = $(quciContainerClassName).innerHeight();
  _triangleHeight = _triangleHeight / 2;
  _triangleWidth = _triangleWidth / 2;
  _left = filterQuciContianerLeftPosition(posX - _triangleWidth, 50, 300,webW, v_direction);
  

  if (direction == 'below') {
    // console.log('below');
    $(quciContainerClassName).css('top', (posY + _vgap) + 'px');
    if (IsPC()){
      $(quciContainerClassName).css('left', _left + 'px');
    }
    $(quciTrangleClassName)
      .css('left', (posX - _triangleWidth) + 'px')
      .css('top', (posY + (_vgap - _triangleHeight)) + 'px');
  } else {
    // console.log('above');
    $(quciContainerClassName).css('top', (posY - _height - _vgap) + 'px');
    if (IsPC()){
      $(quciContainerClassName).css('left', _left + 'px');
    }
    // $(quciContainerClassName).css('top', (posY - _height - _vgap - _triangleHeight) + 'px');
    $(quciTrangleClassName)
      .css('left', (posX - _triangleWidth) + 'px')
      .css('top', (posY - (_vgap + _triangleHeight - 2)) + 'px');
      // .css('top', (posY - (_vgap + _triangleHeight*2)) + 'px');
  }

  // 绑定事件
  $(quciContainerClassName).on('touchstart', function (event) {
    event.stopPropagation();
  });

  $(speechButtonClassName).on('touchstart', function (event) {
    var _this = $(event.target),
      speech = _this.data('speech');
    self.speech(speech);
  });


  
  // web绑定事件
  $(quciContainerClassName).on('click', function (event) {
    event.stopPropagation();
  });

  $(speechButtonClassName).on('click', function (event) {
    var _this = $(event.target),
      speech = _this.data('speech');
    self.speech(speech);
  });
};

// 发音
Quci.speech = function (speech) {
  ydk.playVoice({
    localId: '//dict.youdao.com/dictvoice?audio=' + speech, // 发音
    currentTime: 0,
    success : function(res){
      // rlog({
      //   'action': 'quci_article_speech',
      //   'base_url': location.href,
      //   'table':table,
      //   'speech':speech
      // });
      if(res.code == 1000){
        console.log('播放成功:',res.localId);
      }else{
        ydk.toast({
          msg:'发音失败'
        })
      }

    },
    fail:function(res){
      ydk.toast({
        msg:'发音失败'
      })
    },
    error:function (XMLHttpRequest, textStatus, errorThrown) {
      if(textStatus) {
        ydk.toast({
          msg:'发音失败'
        });
      }
      console.log('我是发音接口error',textStatus)
    }
  });
};

// 检查是否收藏过
Quci.checkIsCollected = function (data) {
  var self = this;
  var word = data.opt.word;
  var $button = $('.word-' + word);

  ydk.isLogin({success:function(res){
    if (res.isLogin) {
      checkIsCollected();
    }else{
      // 没登录,也绑定收藏事件
      $button.on('click', function (event) {
        event.stopPropagation();
        self.collect(data, $button);
      });
    }
  }});

  function checkIsCollected() {
    // server({
    //   url: '//weixinactivity.youdao.com/exam/collection/word/isCollected',
    //   data: {
    //     table: table,
    //     word: word
    //   },
    //   success: function (res) {
    //     if (res.err === 0) {
    //       if (res.data) {
    //         // 已收藏
    //         $button && self.updateButton($button, collectedClassName)
    //       } else {
    //         // 未收藏
    //         $button && self.updateButton($button, uncollectedClassName);
    //         $button.on('click', function (event) {
    //           event.stopPropagation();
    //           self.collect(data, $button);
    //         });
    //       }

    //     } else {
    //       // 未知错误
    //       console.log('???');
    //       $button.on('click', function (event) {
    //         ydk.toast({
    //           msg:'收藏失败'
    //         })
    //       });
    //     }
    //   }
    // })
  }
};

Quci.updateButton = function ($button, status) {
  switch (status) {
    case uncollectedClassName:
    {
      $button
        .removeClass(collectedClassName)
        .addClass(uncollectedClassName);
      break;
    }
    case collectedClassName:
    {
      $button
        .removeClass(uncollectedClassName)
        .addClass(collectedClassName);
      break
    }
  }

};

Quci.collect = function (data, $btn) {
  var self = this;
  if (table.trim() == '') return;

  var _params = {
    table: table,
    word: data.opt.word,
    content: JSON.stringify(data.ret)
  };

  // 检查是否有登录
  ydk.isLogin({success:function(res){
    if (res.isLogin) {
      collectWord();
    } else {
      ydk.login();
    }
  }});

  function collectWord() {
    // server({
    //   url: '//weixinactivity.youdao.com/exam/collection/word/add',
    //   data: _params,
    //   success: function (res) {
    //     // rlog({
    //     //   'action': 'quci_article_collect',
    //     //   'base_url': location.href,
    //     //   'table':table,
    //     //   'word':data.opt.word
    //     // });

    //     if (!res.err) {
    //       console.log('收藏成功');
    //       self.updateButton($btn, collectedClassName);
    //     } else {
    //       console.log('收藏失败');
    //       ydk.toast({
    //         msg:'收藏失败'
    //       });
    //     }
    //   },
    //   fail:function () {
    //     ydk.toast({
    //       msg:'收藏失败'
    //     });
    //   },
    //   error:function (XMLHttpRequest, textStatus, errorThrown) {
    //     if(textStatus) {
    //       ydk.toast({
    //         msg:'收藏失败'
    //       });
    //     }
    //     console.log('我是收藏接口error',textStatus)
    //   }
    // })
  }
};

Quci.hide = function () {
  $(quciContainerClassName).remove();
  $(quciTrangleClassName).remove();
};


module.exports = {
  init: Quci.init,
  query: Quci.query,
  hide: Quci.hide
};