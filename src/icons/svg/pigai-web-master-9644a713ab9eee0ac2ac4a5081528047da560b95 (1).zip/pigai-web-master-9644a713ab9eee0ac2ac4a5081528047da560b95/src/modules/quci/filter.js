/**
 * 将所取词返回xml字符串转换成自定义的json格式
 * */
var filterDict = ($xml) => {
  var ret = {};
  //发音
  ret.ukspeech = $('uk-speech' , $xml).text();
  ret.usspeech = $('us-speech' , $xml).text();

  ret.speech = $('speech' , $xml).text() || $('dictcn-speach' , $xml).text();
  ret.ukphonetic = $('uk-phonetic-symbol' , $xml).text();
  ret.usphonetic = $('us-phonetic-symbol' , $xml).text();
  ret.phonetic = $('phonetic-symbol' , $xml).text();


  ret.trans = [];
  $('translation content' , $xml).each(function(){
    var $this = $(this),
      text = $this.text();
    text && ret.trans.push(text);
  });

  // ret.nettran = [];
  // $('web-translation' , $xml).eq(0).find('trans value').each(function(){
  //   var $this = $(this);
  //   ret.nettran.push($this.text());
  // });

  return ret;
};

var filterFanyi = ($xml) => {
  var ret = {};
  let txt = $('tran' , $xml).text();

  if(txt.match(/\n+/g)){
    txt = '<br>' + txt;
    txt = txt.replace(/\n+/g , '<br><div class="br-height"></div>');
  }

  ret.tran = txt;

  return ret;
};


module.exports = filter;

function filter(data){
  // console.log('是否有data?:', data.result);

  var $xml;
  var ret = {};
  try{
    // $xml = $.parseXML(data.result);
    $xml = loadXML(data.result);
  }catch(e){
    /**
     * 特殊情况：
     * 划加密文档
     */
    data.result = '<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<yodaodict>\n  <return-phrase><![CDATA[]]></return-phrase>\n <le>en</le>\n<lang>eng</lang>\n <sexp>0</sexp>\n\n</yodaodict>\n';
    $xml = loadXML(data.result);
    ret.type = 'errCode';
    return ret;
  }
  // console.log('是否有$xml?:', $xml);
  ret.source = $('return-phrase' , $xml).text() || data.word;
  ret.source = ret.source.replace(/&lt;/g , '<').replace(/&gt;/g , '>').replace(/&quot;/g , '"').replace(/\n+/g , '\n');


  /**
   * 无查词结果
   */

  if(
    $('fanyi-result' , $xml).length == 0 &&
    $('translation' , $xml).length == 0 &&
    $('web-translation' , $xml).length == 0 &&
    $('yodao-web-dict', $xml).length == 0 &&  
    $('custom-translation', $xml).length == 0
  ){

    ret.type = 'empty';
    ret.lang = $('le' , $xml).text();
    ret.moreLink = ['dict://' , '?' , $.param({
      keyword : ret.source,
      lang : ret.lang
    })].join('');
    return ret;
  }

  ret.type = $('fanyi-result' , $xml).length > 0 ? 'fanyi' : 'dict';

  //识别的语言

  if(ret.type == 'dict'){
    ret.lang = $('le' , $xml).text();
    ret.dict = filterDict($xml);
    // ret.moreLink = ['dict://' , '?' , $.param({
    //   keyword : ret.source,
    //   lang : ret.lang
    // })].join('');
  }else if(ret.type == 'fanyi'){
    var fytype = $('fytype' , $xml).text();
    ret.lang = fytype;
    ret.fanyi = filterFanyi($xml);
    // ret.moreLink = ['fanyi://' , '?' , $.param({
    //   keyword : ret.source,
    //   lang : ret.lang
    // })].join('');
  }

  return ret;
};



// Changes XML to JSON
// 转换xml文档为json
function loadXML(xmlString){
  var xmlDoc=null;
  //判断浏览器的类型
  //支持IE浏览器
  if(!window.DOMParser && window.ActiveXObject){   //window.DOMParser 判断是否是非ie浏览器
    var xmlDomVersions = ['MSXML.2.DOMDocument.6.0','MSXML.2.DOMDocument.3.0','Microsoft.XMLDOM'];
    for(var i=0;i<xmlDomVersions.length;i++){
      try{
        // xmlDoc =  new ActiveXObject(xmlDomVersions[i]);
        xmlDoc = new XMLHttpRequest();
        xmlDoc.async = false;
        xmlDoc.loadXML(xmlString); //loadXML方法载入xml字符串
        break;
      }catch(e){
        console.log(e)
      }
    }
  }
  //支持Mozilla浏览器
  else if(window.DOMParser && document.implementation && document.implementation.createDocument){
    try{
      /* DOMParser 对象解析 XML 文本并返回一个 XML Document 对象。
       * 要使用 DOMParser，使用不带参数的构造函数来实例化它，然后调用其 parseFromString() 方法
       * parseFromString(text, contentType) 参数text:要解析的 XML 标记 参数contentType文本的内容类型
       * 可能是 "text/xml" 、"application/xml" 或 "application/xhtml+xml" 中的一个。注意，不支持 "text/html"。
       */
      var domParser = new  DOMParser();
      xmlDoc = domParser.parseFromString(xmlString, 'text/xml');
    }catch(e){
      console.log(e)
    }
  }
  else{
    return null;
  }

  return xmlDoc;
}