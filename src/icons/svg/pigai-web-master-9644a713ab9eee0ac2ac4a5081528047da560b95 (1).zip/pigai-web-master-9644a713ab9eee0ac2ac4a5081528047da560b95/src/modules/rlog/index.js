/**
 * 自动捕获data-log-*的点击事件，触发rlog发送事件
 * 当data-log-xxx='true'时候，自动找到父级节点
 *
 * 如：<a href="#" data-log-action="go_channelList" data-log-location="hot_circle">全部圈子</a>
 */

export function rlog(self) {
  var $this;

  //判断是否jquery对象
  if(self.jquery){
    $this = self;
    self = self[0];
  }else{
    $this = $(self);
  }
  
  var params = {
    keyfrom : 'deskdict.main'
  };


  _.each(self.attributes , function(attr){
    var attrName = attr.name;
    if(/^data-log-/.test(attrName)){
      var val = attr.value;
      if(!val){
        return;
      }

      var key = attrName.substring(9);
      //当为true时候，自动向上查找属性
      if(val == '^'){
        var $el = $this.parents('['+attrName+']');
        // console.log($el.length , attrName);
        //找不到父级属性，跳过
        if($el.length == 0){
          attr.value = '';
          return;
        }else{
          val = $el[0].getAttribute(attrName);
          attr.value = val;
          params[key] = val;
        }
      }else{
        params[key] = val;
      }
    }
  });
  ydk.rlog(params);
}

export function init(){
  $(document).on('click', '[data-log-action]', function() {
    rlog(this);
  });
}
