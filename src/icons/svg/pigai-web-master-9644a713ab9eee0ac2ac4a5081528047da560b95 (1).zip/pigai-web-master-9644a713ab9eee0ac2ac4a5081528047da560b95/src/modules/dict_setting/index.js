import default_setting from './default_setting.js';

var store = window.localStorage;
var key = 'dict_setting';
var defaultSettingStr = JSON.stringify(default_setting);

// ydk.onSettingChange({
//   success : clearCache
// });

function clearCache(){
  store.removeItem(key);
}

function putCache(setting){
  // console.trace('put cache' , JSON.stringify(setting));
  store.setItem(key , JSON.stringify(setting));
}


export function getDefault(){
  return JSON.parse(defaultSettingStr);
}

export function get(callback , cache = true) {
  if(cache){
    var res = store.getItem(key);
    if(res){
      try{
        callback(JSON.parse(res));
        // console.trace('get from cache' , res);
        return;
      }catch(e){
        console.error(e);
      }
    }
  }

  ydk.getSetting({
    success : function(res){
      var setting = res.data;
      if(!setting){
        setting = getDefault();
      }else{
        setting = $.extend(true , getDefault() , setting);
      }
      
      //判断单词本默认分类是否在词典分组中，不在则创建。
      ydk.queryWordBookCategory({
        success(res) {
          if(_.findIndex(res.data, {'name':setting.wordbook.defaultCategory}) < 0)
          {
            ydk.addWordBookCategory({
              name: setting.wordbook.defaultCategory
            })
          }
          callback(setting);
          putCache(setting);
        }
      });
    }
  });
}

export function save(params , callback) {
  //清除缓存，使用接口返回的配置
  get((setting) => {
    setting = $.extend(true , setting , params);
    ydk.saveSetting({
      setting : setting,
      success : () => {
        callback && callback(setting);
      },
      complete : clearCache
    });
  } , false)
}

export var init = clearCache;