/**
 * 默认设置
 */
export default {
  //常规
  basic : {
    //字体大小
    fontSize: 'small',
    //开机启动
    startup : true,
    //启动后最小化到系统托盘
    start_minify : false,
    //启用主窗口总在最前
    start_front : false,  
    //窗口关闭最小化到系统托盘
    close_mini : true,
    //文档翻译
    add_contextmenu : false,      
    //打开有道词典快捷键
    dict_hotkey : 'Ctrl + Alt + X',
    //打开mini窗口快捷键
    mini_hotkey : 'Ctrl + Alt + M',
    // 添加/删除单词快捷键
    word_hotkey : 'Ctrl + Alt + S',
    //单词发音
    sound_hotkey : 'Ctrl + Alt + V',
    //截屏翻译
    screencapture_hotkey : 'Ctrl + Alt + D',
  },

  content : {
    //自动发音
    auto_pronounce : true,
    //英音uk/美音us
    pronounce_type : 'us',
    //有道指点
    dict_directions : true,
    //每日推荐
    daily_promote : true,
    //查词历史记录条数
    history_num : '20'
  },

  quci : {
    //取词开关
    enable : true,
    //快捷键
    hotkey : 'F8',
    // 取词方式:
    // mouse鼠标取词|middleMouse鼠标中键取词|
    // alt+mouse Alt+鼠标取词|ctrl+mouse Ctrl+鼠标取词|shift+mouse Shift+鼠标取词
    way : 'mouse',
    scope :{
      // 中文取词
      chinese : true,
      // 系统界面取词
      system : false,
      // 强力取词
      force : false
    },
    //在取词结果中显示百科内容
    baike : true
  },

  huaci : {
    //划词开关
    enable : true,
    // 划词方式：
    // showIcon展示划词图标|showResult直接展示结果|dobuleCtrl双击ctrl展示结果
    way : 'showIcon',
    //快捷键
    hotkey : '',
    // 复制查词
    clipboard : false
  },

  dict : {
    
  },

  network : {
    http : 'direct', //direct 不使用代理/no IE代理/custom 自定义
    custom : {
      //自定义代理参数
      host : '',      //服务器
      port : '',      //端口
      username : '',  //用户名
      password : ''   //密码
    }
  },

  about : {
    // 自动更新
    auto_update : true
  },
  
  //单词本
  wordbook : {
    // 查过的词自动加入单词本
    autoAddWB : false,
    // 在系统任务栏（系统托盘）提醒复习
    notice : true,
    // 浏览时，单词自动发音
    viewAutoVoice : false,
    // 复习时，单词自动发音
    reviewAutoVoice : false,
    // 添加单词时默认加入复习计划
    addReview : true,
    // 每日进入复习流程的新单词上限
    wordNum : '30',
    // 单词本默认分组
    defaultCategory : '未分组',
    // 单词本卡片模式播放时直接显示释义
    showParaphrase : true,
  }
}