import Vue from 'vue';
import event from 'commons/event';

var 
  $html = $('html'),
  devicePixelRatio = window.devicePixelRatio || 1;
  
export function ready (callback) {
  if(ydk.client){
    callback(ydk.client);
  }else{
    event.one('ydk.ready' , callback);
  }
}

export var autoSize = _.throttle(() => {
  Vue.nextTick(() => {
    ydk.setWinSize({
      width : Math.ceil($html.width() * devicePixelRatio),
      height : Math.ceil($html.height() * devicePixelRatio)
    })
  });
},100);

export var autoHeight = _.throttle(() => {
  Vue.nextTick(() => {
    ydk.setWinHeight({
      height : Math.ceil($html.height() * devicePixelRatio)
    })
  });
},100);