/**
 * 自定义伪协议处理器
 *
 * sw://?pid=
 * dict://?keyword=&lang=
 * fanyi://?
 */
import * as broadcaster from 'modules/broadcast';
import config from 'config';
import * as urlparams from 'modules/urlparams';

$(() => {

  var onClick = function(e){
    var $this = $(this),
      href = $this.attr('href'),
      prefix = href.match(/^(sw|dict|fanyi)\:\/\//);

    if(!prefix){
      return;
    }
    var 
      quertstring = href.substring(href.indexOf('?')),
      url , 
      target , 
      params;

    switch(prefix[1]){
      case 'dict':
        target = 'dict/result';
        params = urlparams.get(quertstring);
        break;
      case 'fanyi':
        target = 'fanyi';
        params = urlparams.get(quertstring);
        break;
      case 'sw':
        url = 'sw/pc.html';
        params = urlparams.get(quertstring);
        break;
      default:
        return;
    }

    // console.log(url , target , params);

    broadcaster.emit('open' , {
      url : url,
      target : target,
      from : config.pageId,
      params : params
    } , 'all');
    
    ydk.setTop();

    e.preventDefault();
  };

  $('body').on('click' , 'a' , onClick);
});