import jsonapi from './jsonapi.js';

var seq = 0;
var searcher = function(options){
  var self = this;
  self.options = options || {
    mode : 'all'
  };
  self.isLocal = false;
  self.isNet = false;

}

var now = () => {
  return parseInt(performance.now() , 10);
}

/**
 * 本地简明释义
 */
searcher.prototype.local = function(params){
  var self = this;
  var
    start = now(),
    duration = 0;
  var wrap = (callback) => {
    if(!callback)return null;
    var _seq = seq;
    return function(res){
      //如果网络释义已返回，则丢掉本地释义
      if(self.isNet)return;
      if(res.code == 1000){
        self.isLocal = true;
      }
      res = res || {};
      res.from = 'local';
      res.seq = _seq;
      res.duration = duration || (duration = now() - start);
      callback(res);
    }
  }

  ydk.getDictResult({
    data : {
      keyword : params.data.keyword,
      lang : params.data.lang,
      requestId : params.data.requestId
    },
    complete : wrap(params.complete),
    fail : wrap(params.fail),
    success : wrap(params.success)
  });

  return self;
};

/**
 * 本地详细释义(离线词库)
 */
searcher.prototype.ldetail = function(params){
  var self = this;
  var 
    start = now(),
    duration = 0;  
  var wrap = (callback) => {
    if(!callback)return null;
    var _seq = seq;
    return function(res){

      //如果网络释义已返回，则丢掉本地释义
      if(self.isNet)return;
      if(res.code == 1000){
        self.isLocal = true;
      }
      res = res || {};
      res.from = 'ldetail';
      res.seq = _seq;
      res.duration = duration || (duration = now() - start);
      callback(res);
    }
  }

  ydk.getDictResult({
    data : {
      keyword : params.data.keyword,
      lang : params.data.lang,
      requestId : params.data.requestId,      
      type : 'ldetail'
    },
    complete : wrap(params.complete),
    fail : wrap(params.fail),
    success : wrap(params.success)
  });

  return self;
}

/**
 * 网络释义
 */
searcher.prototype.remote = function(params){
  var self = this;
  var
    start = now(),
    duration = 0;
  var wrap = (callback) => {
    if(!callback)return null;
    var _seq = seq;
    return function(res){
      //如果本地已经返回，则丢掉该结果
      if(self.options.mode == 'any' && self.isLocal)return;
      if(res.code == 1000){
        self.isNet = true;
      }
      res = res || {};
      res.seq = _seq;
      res.from = 'net';
      res.duration = duration || (duration = now() - start);
      callback(res);
    }
  }
  //网络
  ydk.getDictResult({
    data : {
      keyword : params.data.keyword,
      lang : params.data.lang,
      requestId : params.data.requestId,      
      type : 'quick'
    },
    complete : wrap(params.complete),
    fail : wrap(params.fail),
    success : wrap(params.success)
  });
  return self;
};

/**
 * mini模式
 */
searcher.prototype.mini = function(params){
  var self = this;
  var
    start = now(),
    duration = 0;
  var wrap = (callback) => {
    if(!callback)return null;
    var _seq = seq;
    return function(res){
      //如果本地已经返回，则丢掉该结果
      if(self.options.mode == 'any' && self.isLocal)return;
      if(res.code == 1000){
        self.isNet = true;
      }
      res = res || {};
      res.seq = _seq;
      res.from = 'net';
      res.duration = duration || (duration = now() - start);
      callback(res);
    }
  }
  //网络
  ydk.getDictResult({
    data : {
      keyword : params.data.keyword,
      lang : params.data.lang,
      requestId : params.data.requestId,      
      type : 'mini',
      dicts : '{"count":4,"dicts":[["ec","ce","cj","jc","ck","kc","cf","fc" , "multle"],["web_trans"],["fanyi"],["typos"]]}'
    },
    complete : wrap(params.complete),
    fail : wrap(params.fail),
    success : wrap(params.success)
  });
  return self;
};

/**
 * 同时发起本地释义和网络释义
 */
searcher.prototype.auto = function(params){
  var self = this;
  self.local(params).remote(params);
}

/**
 * 同时发起本地释义和mini网络释义
 */
searcher.prototype.miniSearch = function(params){
  var self = this;
  self.local(params).mini(params);
}

/**
 * 先返回本地释义，然后再返回网络释义
 */
export function search(params) {
  new searcher().auto(params);
}


/**
 * 本地 或者 网络释义返回即可
 */
export function any(params) {
  new searcher({
    mode : 'any'
  }).auto(params);
}

export function ldetail(params) {
  seq++;
  new searcher().ldetail(params);
}

export function local(params) {
  seq++;
  new searcher().local(params);
}

export function remote(params) {
  seq++;
  new searcher().remote(params);
}

export function mini(params) {
  new searcher().mini(params);
}

export function detail(params){
  var _seq = seq++;  
  var wrap = (callback) => {
    if(!callback)return null;
    return function(res){
      res = res || {};
      res.seq = _seq;
      callback(res);
    }
  }

  jsonapi({
    data : {
      keyword : params.data.keyword,
      lang : params.data.lang,
      requestId : params.data.requestId,
      keyfrom : params.data.keyfrom,
      forQueryPage : params.data.forQueryPage        
    },
    complete : wrap(params.complete),
    fail : wrap(params.fail),
    success : wrap(params.success)
  });
}

/**
 * 获取ugc释义
 */
export function ugc(params){
  var _seq = seq++;
  var wrap = (callback) => {
    if(!callback)return null;
    return function(res){
      res = res || {};
      res.seq = _seq;
      callback(res);
    }
  }
  ydk.ajax({
    type : 'GET',
    url : 'http://dict.youdao.com/dictugc/ugc/json/getUgcs',
    dataType : 'jsonp',
    data : {
      word : params.data.keyword,
      lang : (params.data.lang == 'en') ? 'eng' : params.data.lang,
      offset : 0,
      len : 3
    },
    success : wrap(params.success)
  })
}