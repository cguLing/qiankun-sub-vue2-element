/**
 * @see https://dev.corp.youdao.com/outfoxwiki/Dict/Projects/DictDataServer
 */
import * as clienter from 'modules/clienter';

var now = () => {
  return parseInt(performance.now() , 10);
}

var timer = null;
var timer1 = null;

var ajax = function (params) {
  clienter.ready(() => {
    var data = params.data;
    var start = now();
    ydk.getDictResult({
      timeout : params.timeout,
      data : {
        keyword : data.keyword,
        lang : data.lang,
        type : 'detail',
        dicts : data.dicts,
        simple : data.simple,
        requestId : data.requestId,
        keyfrom : data.keyfrom,
        forQueryPage : data.forQueryPage || false
      },
      success : (res) => {
        res.duration = now() - start;
        res.dicts = params.data.dicts;
        res.requestId = params.data.requestId;
        params.compete && params.compete(res);
        params.success && params.success(res);
        timer && clearTimeout(timer);
        timer = setTimeout(function(){
          ydk.rlog({
            duration: res.duration,
            timing: 'webdict_query',
            keyfrom: 'deskdict.main',
            type: 'success',
            des: params.des,
            q: data.keyword,
            le: data.lang,
          })
        } , 1000)
      },
      fail : (res) => {
        res.duration = now() - start;
        timer1 && clearTimeout(timer1);
        timer1 = setTimeout(function(){
          ydk.rlog({
            duration : res.duration,
            timing : 'webdict_query',
            keyfrom : 'deskdict.main',
            type : 'error',
            des  : params.des,
            q : data.keyword,
            le : data.lang,
          })
        } , 1000)

        params.compete && params.compete(res);
        params.fail && params.fail(res)
      },
      complete : params.complete
    });
  })
};

/**
 * 合并查词数据
 */
var extend = (source , target) => {
  source = source ||{};
  if(!target)return source;

  Object.keys(target).forEach((key) => {
    var val = target[key];
    if(val && typeof(val) == 'object' && !source[key]){
      source[key] = val;
    }
  });
  return source;
};


/**
 * [查词]
 * @param  {[type]} params [description]
 * @return {[type]}        [description]
 */
var search = (params) => {
  var data = null;
  var lang = params.data.lang;
  var cur_dicts = window.$Vue.$store.state.dict.cur_dicts || {};
  //全部语种词典
  var all_dicts = '["oxfordAdvance","oxford","splongman","longman","webster","collins","collins_part","ec21","ce_new","hh","newcenturyjc"]'; 
  //日语语种词典
  var ja_all_dicts = '["newcenturyjc"]';  
  var first_specialty_dicts = all_dicts;
  var second_specialty_dicts = '[]';
  
  //英汉和自动语种
  if(lang == 'en' || lang == 'auto')
  { 
    //简明、例句、百科
    if (cur_dicts.concision || cur_dicts.example || cur_dicts.baike) {
      first_specialty_dicts = '[]';
      second_specialty_dicts = all_dicts;
    }
    else if(cur_dicts.oxfordAdvance){   //牛津高阶
      first_specialty_dicts = '["oxfordAdvance"]';
      second_specialty_dicts = all_dicts;
    }     
    else if(cur_dicts.oxford){   //牛津
      first_specialty_dicts = '["oxford"]';
      second_specialty_dicts = all_dicts;
    }       
    else if(cur_dicts.longman){  //朗文
      first_specialty_dicts = '["splongman","longman"]';
      second_specialty_dicts = all_dicts;
    }
    else if(cur_dicts.webster){ //韦氏
      first_specialty_dicts = '["webster"]';
      second_specialty_dicts = all_dicts;
    }    
    else if(cur_dicts.collins){  //柯林斯
      first_specialty_dicts = '["collins","collins_part"]';
      second_specialty_dicts = all_dicts;
    }
    else if(cur_dicts.ec21){  //21世纪
      first_specialty_dicts = '["ec21"]';
      second_specialty_dicts = all_dicts;
    }
    else if(cur_dicts.ce_new){  //新汉英
      first_specialty_dicts = '["ce_new"]';
      second_specialty_dicts = all_dicts;
    }
    else if (cur_dicts.hh) { //现代汉语
      first_specialty_dicts = '["hh"]';
      second_specialty_dicts = all_dicts;
    } 
    else if (cur_dicts.newcenturyjc) { //新世纪日汉双解大辞典(日语)
      first_specialty_dicts = '["newcenturyjc"]';
      second_specialty_dicts = all_dicts;
    }
  }
  //日语
  else if(lang == 'ja'){
    if (cur_dicts.newcenturyjc) { //新世纪日汉双解大辞典
      first_specialty_dicts = '["newcenturyjc"]';
      second_specialty_dicts = ja_all_dicts;
    }else{
      first_specialty_dicts = '[]';
      second_specialty_dicts = ja_all_dicts;      
    }
  }
  //其他语种
  else
  {
    first_specialty_dicts = '[]';
    second_specialty_dicts = '[]';
  }
     
  var first_dicts, 
    second_dicts; 
     
  if(first_specialty_dicts == '[]'){
    first_dicts = '{"count":14,"dicts":[["ec","ce","cj","jc","ck","kc","cf","fc","multle","related-langs","newjc","newcj","pic_dict"],["fanyi"]]}';
  }else{
    first_dicts = '{"count":20,"dicts":[["ec","ce","cj","jc","ck","kc","cf","fc","multle","related-langs","newjc","newcj","pic_dict"],'+ first_specialty_dicts +',["fanyi"]]}';
  }
  if(second_specialty_dicts == '[]'){
    second_dicts = '{"count":11,"dicts":[["web_search"],["web_trans"],["special"],["ee"],["phrs"],["syno"],["rel_word"],["etym"],["typos"],["blng_sents_part","media_sents_part","auth_sents_part"],["fanyi"]]}';
  }else{
    second_dicts = '{"count":21,"dicts":['+ second_specialty_dicts +',["web_search"],["web_trans"],["special"],["ee"],["phrs"],["syno"],["rel_word"],["etym"],["typos"],["blng_sents_part","media_sents_part","auth_sents_part"],["fanyi"]]}';
  }

  /**
   * 短查询：获取查词结果页当前视野数据，有缓存效果
   */
  ajax({
    des : 'first_dict_query',
    timeout : params.timeout,
    data : {
      dicts : first_dicts,
      keyword : params.data.keyword,
      lang : params.data.lang,
      simple : true,
      requestId : params.data.requestId,
      keyfrom : params.data.keyfrom,
      forQueryPage : params.data.forQueryPage     
    },
    complete : params.compete,
    fail : params.fail,
    success : function(res){
      if(!data){
        data = res.data;
      }else{
        res.data = data = extend(data , res.data);
      }
      res.describe = 'first_dict_query';
      params.success && params.success(res);
      console.log('第一次查询参数：', JSON.stringify(first_dicts))
    }
  })

  /**
   * 第二次查询，无缓存。
   */
  ajax({
    des : 'second_dict_query',
    data : {
      dicts : second_dicts,
      keyword : params.data.keyword,
      lang : params.data.lang,
      simple : false,
      requestId : params.data.requestId,
      keyfrom : params.data.keyfrom,
      forQueryPage : params.data.forQueryPage        
    },
    fail : params.fail,
    success : function(res){
      if(!data){
        data = res.data;
      }
      res.describe = 'second_dict_query';
      res.data = extend(data , res.data);
      params.success && params.success(res);
      console.log('第二次查询参数：', JSON.stringify(second_dicts))
    },
    complete : params.complete
  });

};

export default search;