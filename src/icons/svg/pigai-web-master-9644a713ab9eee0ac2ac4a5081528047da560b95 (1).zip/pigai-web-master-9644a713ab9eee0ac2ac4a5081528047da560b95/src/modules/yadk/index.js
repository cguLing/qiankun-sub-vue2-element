//https://gitlab.corp.youdao.com/webfront-ad/youdao_ad_sdk/tree/master
import 'libs/yadk-1.0.5-modify.js'