import * as clienter from 'modules/clienter';
import './index.scss';

var _timer;
/* istanbul ignore next */
var fadeOut = ($el) => {
  clearTimeout(_timer);
  _timer = setTimeout(() => {
    $el.fadeOut(500 , () => {
      $el.remove();
    });
  } , 5000);

};

var date;
export var start = () => {
  date = _.now();
};

/* istanbul ignore next */
export var stop = (title , start) => {
  log([title , '：<em>' , _.now() - (start || date) ,  '</em> ms']);
};


export var log = (msg , isFadeOut = true) => {
  clienter.ready((client) => {
    if(!client.debug)return;

    var $msg = $('._debug_msg');
    if($msg.length == 0){
      $msg = $('<div class="_debug_msg"></div>')
      $('body').append($msg);
    }

    $msg.append('<p>'+ (_.isArray(msg) ? msg.join('') : msg) +'</p>')

    fadeOut($msg);
  })
};

export function clear() {
  $('._debug_msg').empty();
}

/* istanbul ignore next */
$(() => {
  clienter.ready((client) => {
    if(!client.debug)return;
    $('body').on('mouseenter' , '._debug_msg' , () => {
      clearTimeout(_timer);
    }).on('mouseleave' , '._debug_msg' , function(){
      fadeOut($(this));
    })
  });
});