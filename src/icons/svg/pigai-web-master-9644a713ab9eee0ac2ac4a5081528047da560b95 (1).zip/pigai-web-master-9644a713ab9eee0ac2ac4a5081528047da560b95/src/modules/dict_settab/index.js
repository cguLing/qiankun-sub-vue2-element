import default_dict from './default_dict.js';

var store = window.localStorage;
var key = 'dict_setting_tab';
var defaultSettingStr = JSON.stringify(default_dict);

function clearCache(){
  store.removeItem(key);
}

function putCache(setting){
  store.setItem(key , JSON.stringify(setting));
}

export function getDefault(){
  return JSON.parse(defaultSettingStr);
}

export function get(callback , cache = true) {
  var res = null; 
  if(store.getItem(key)){
    res = store.getItem(key);
  }else{
    res = defaultSettingStr;
  }

  if(cache){   
    if(res){
      try{
        callback && callback(JSON.parse(res));
        return;
      }catch(e){
        console.error(e);
      }
    }    
  } 
}

export function save(params){
  putCache(params);
}