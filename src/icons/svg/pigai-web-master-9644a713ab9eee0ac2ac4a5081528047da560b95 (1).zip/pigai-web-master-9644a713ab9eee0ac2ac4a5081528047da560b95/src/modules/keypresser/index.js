/**
 * keypresser.watch(function(keys , e));
 * keypresser.watch('CTRL+B' , function(keys , e));
 * keypresser.watch($('input') , function(keys , e));
 * keypresser.watch($('input') , 'CTRL+B' , function(keys , e));
 * 
 */

const codeMap = {
  186 : ';',
  187 : '=',
  188 : ',',
  189 : '-',
  190 : '.',
  191 : '/',
  192 : '`',
  219 : '[',
  220 : '\\',
  221 : ']',
  222 : '\,'
};


const bodyWatcher = [];

var initBodyWatch = () => {
  $('body').keydown(debounce(function(e){
    var self = this;
    bodyWatcher.forEach((callback) => {
      callback.call(self , e);
    })
  } , 100))
  initBodyWatch = null;
};


var watcher = (keys , callback) => {
  if(typeof keys == 'function'){
    callback = keys;
    return function(e){
      var triggerKeys = getKeys(e);
      if(!triggerKeys)return;
      callback.call(this , triggerKeys , e);
    };
  }

  return function(e){
    var triggerKeys = getKeys(e);
    if(!triggerKeys)return;
    if(isMatchKeys(keys , triggerKeys))callback.call(this , triggerKeys , e);
  }
};

/**
 * 格式化输出
 * @return {[Array]}      ['Ctrl' , 'Alt' , 'Shift' , 'A']
 */
var formatKeys = (keys) => {
  if(!keys)return null;
  var array = [];
  if(keys.ctrl)array.push('Ctrl');
  if(keys.alt)array.push('Alt');
  if(keys.shift)array.push('Shift');
  if(keys.meta)array.push('Meta');
  if(keys.key)array.push(keys.key);
  return array;
};

/**
 * 两组按键是否等价
 */
export var isMatchKeys = (expectKeys , actualKeys) => {
  if(_.isArray(expectKeys)){
    expectKeys = expectKeys.join('+');
  }

  if(_.isArray(actualKeys)){
    actualKeys = actualKeys.join('+');
  }
  expectKeys = expectKeys.replace(/\s+/g, '').toUpperCase().split('+').sort();

  actualKeys = actualKeys.replace(/\s+/g, '').toUpperCase().split('+').sort();

  // console.debug(expectKeys.join('+') , actualKeys.join('+'))
  return expectKeys.join('+') == actualKeys.join('+');
};

/**
 * 获取按键
 */
export var getKeys = (e) => {
  //获取原始键盘事件
  e = e.originalEvent || e;
  var keyCode = e.keyCode;
  // console.debug(keyCode);

  var keys = {
    ctrl : e.ctrlKey,
    shift : e.shiftKey,
    alt : e.altKey,
    meta : e.metaKey,
    key : null
  };

  if(!e.key){
    /**
     * Chrome51以下不支持key属性
     * https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key
     * 
     * https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/keyIdentifier
     */
    if(/^U\+/.test(e.keyIdentifier)){
      e.key = String.fromCharCode(e.keyCode);
    }else{
      e.key = e.keyIdentifier;
    }
  }


  switch(e.key){
    case 'Alt':
    case 'Control':
    case 'Shift':
      return formatKeys(keys);
  }

  if(e.key.length > 1){
    keys.key = e.key;
  }else if(codeMap[keyCode]){
    keys.key = codeMap[keyCode];
  }else{  
    keys.key = String.fromCharCode(keyCode);
  }

  return formatKeys(keys);
};

/**
 * 是否系统按键
 */
export var isSystemKeys = (keys) => {
  if(keys instanceof Event){
    keys = getKeys(keys).join('+');
  }else if(_.isArray(keys)){
    keys = keys.join('+');
  }else if(typeof keys != 'string'){
    console.warn('Unsupport keys')
    return false;
  }

  const systemShortCut = [
    'Ctrl+Alt+Del',
    'Escape', 'Delete', 'Insert', 'Backspace', 'Enter',
    'ArrowUp' , 'ArrowDown' , 'ArrowLeft' , 'ArrowRight',
    'Alt+F4',
    'Ctrl+A', 'Ctrl+S', 'Ctrl+Z', 'Ctrl+C', 'Ctrl+V', 'Ctrl+X', 'Ctrl+N', 'Ctrl+O', 'Ctrl+P',
  ];

  return systemShortCut.indexOf(keys) != -1;
};

/**
 * 是否快捷键
 */
var isKeys = (keys) => {
  return typeof keys == 'string' || _.isArray(keys);
};

var isHtmlElement = (ele) => {
  return ele instanceof jQuery || ele.tagName;
}

var debounce = function(callback , ttl){
  var execute = _.debounce(callback , ttl);
  return function(e){
    //e.preventDefault();   //阻止默认行为
    //e.stopPropagation();  //阻止冒泡
    execute.call(this , e);
  }
};

export function watch(){
  var args = arguments;
  if(typeof args[0] == 'function'){//keypresser.watch(function(keys , e));
    initBodyWatch && initBodyWatch();
    bodyWatcher.push(watcher(args[0]));

  }else if(
    isKeys(args[0])
    && typeof args[1] == 'function'
  ){//keypresser.watch('CTRL+B' , function(keys , e));
    initBodyWatch && initBodyWatch();
    bodyWatcher.push(watcher(args[0] , args[1]));

  }else if(
    isHtmlElement(args[0])
    && typeof args[1] == 'function'
  ){//keypresser.watch($('input') , function(keys , e));
    $(args[0]).keydown(watcher(args[1]));

  }else if(
    isHtmlElement(args[0])
    && isKeys(args[1])
    && typeof args[2] == 'function'
  ){//keypresser.watch($('input') , 'CTRL+B' , function(keys , e));
    $(args[0]).keydown(watcher(args[1] , args[2]));
  }
};


