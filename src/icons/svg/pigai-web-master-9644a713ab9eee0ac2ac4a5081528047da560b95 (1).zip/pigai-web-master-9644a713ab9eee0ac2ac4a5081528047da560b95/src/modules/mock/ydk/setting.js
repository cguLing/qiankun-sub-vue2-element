/*eslint-disable */

/**
 * 使用indexeddb模拟保存读取操作
 */
import indexdb from 'commons/indexedDB.js';

var options =  {
  keyPath: 'key',//主键
  autoIncrement: false//是否自增长
};

var store = new indexdb('ydk_mock' , 'config' , options);

ydk.getSetting = function(params){
  setTimeout(() => {
    store.query('setting' , (data) => {
      var ret = {
        code : 1000,
        data : data ? data.value : null
      }; 
      params.success && params.success(ret);
      params.complete && params.complete(ret);
    });
  } , 100);
};

ydk.saveSetting = (params) => {
  store.save({
    key : 'setting',
    value : params.setting
  });

  var ret = {
    code : 1000,
    data : {
      success : true
    }
  };
  params.success && params.success(ret);
  params.complete && params.complete(ret);
}


ydk.getOcrModelList = (params) => {
  setTimeout(() => {
    var ret = {
      code : 1000,
      data : [{
        'hasDownload': false,
        'hasUpdate': false,
        'lang': 'de',
        'size': 13054
      },
      {
        'hasDownload': true,
        'hasUpdate': false,
        'lang': 'en',
        'size': 3470
      },
      {
        'hasDownload': false,
        'hasUpdate': false,
        'lang': 'es',
        'size': 15580
      },
      {
        'hasDownload': false,
        'hasUpdate': false,
        'lang': 'fr',
        'size': 13715
      },
      {
        'hasDownload': true,
        'hasUpdate': false,
        'lang': 'ja',
        'size': 32298
      },
      {
        'hasDownload': false,
        'hasUpdate': false,
        'lang': 'ko',
        'size': 12998
      },
      {
        'hasDownload': false,
        'hasUpdate': false,
        'lang': 'pt',
        'size': 12612
      },
      {
        'hasDownload': false,
        'hasUpdate': false,
        'lang': 'ru',
        'size': 15774
      }]
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  } , 100);
}

ydk.downloadOcrModel  = (params) => {
  var progress = 0;
  var timer = setInterval(() => {
    if(progress >= 100){
      clearInterval(timer);
      return;
    }
    progress += 10;
    top.ydk._simulateNative('onDownloadProgress' , {
      code : 1000,
      type : 'ocr',
      lang : params.lang || 'en',
      rate : progress
    } , function(res){
    })
  } , 500);
}

ydk.removeOcrModel  = (params) => {
  console.debug('removeOcrModel' , params);
}

ydk.downloadBrowserPlugin  = (params) => {
  console.debug('downloadBrowserPlugin' , params);
}

ydk.getOfflineLexiconList = (params) => {
  setTimeout(() => {
    var ret = {
      code : 1000,
      errMsg : '',
      data : [
        {
          'dict': 'colins',
          'hasDownload': false,
          'hasUpdate': false,
          'number': 13054.01,
          'size': 23.1,
          'type': 'usual', //常用下载
          'name': '电子、通信与自动控制技术',
          'isVip': true
        },
        {
          'dict': 'en_big',
          'hasDownload': true,
          'hasUpdate': false,
          'number': 13054.01,
          'size': 23.1,
          'type': 'usual', //常用下载
          'name': '英汉超大离线包',
          'isVip': false //VIP权限下载
        },
        {
          'dict': 'ja',
          'hasDownload': false,
          'hasUpdate': false,
          'number': 97339.01,
          'size': 23.1,
          'type': 'usual', //小语种
          'name': '日汉高频精选词汇',
          'isVip': true
        },
        {
          'dict': 'de',
          'hasDownload': false,
          'hasUpdate': false,
          'number': 13054.00,
          'size': 23.1,
          'type': 'usual', //专业释义
          'subtype': null, //没有不是子分组
          'name': '德汉互译',
          'isVip': false
        },
        {
          'dict': 'agriculture1',
          'hasDownload': false,
          'hasUpdate': false,
          'number': 13054.00,
          'size': 23.1,
          'type': 'specialty', //专业释义
          'subtype': null,
          'name': '农业科学',
          'isVip': false
        },
        {
          'dict': 'agriculture2',
          'hasDownload': false,
          'hasUpdate': false,
          'number': 13054.00,
          'size': 23.1,
          'type': 'specialty', //专业释义
          'subtype': null,
          'name': '农业科学',
          'isVip': false
        },
        {
          'dict': 'science1',
          'hasDownload': false,
          'hasUpdate': false,
          'number': 13054.00,
          'size': 23.1,
          'type': 'specialty', //专业释义
          'subtype': null,
          'name': '自然科学',
          'isVip': false
        },
        {
          'dict': 'science2',
          'hasDownload': false,
          'hasUpdate': false,
          'number': 13054.00,
          'size': 23.1,
          'type': 'specialty', //专业释义
          'subtype': null,
          'name': '自然科学',
          'isVip': false
        }
      ]
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  } , 100);
}
var lexiconTimer = null;
var progress = 0;
var loadingDict = null;

ydk.downloadOfflineLexicon  = (params) => {

  setTimeout(() => {
    var ret = {
      code : 1000,
      errMsg : ''
    }
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  },100)

  if(loadingDict != params.dict || progress >= 100){
    progress = 0;
    loadingDict = params.dict;
  }
  
  lexiconTimer = setInterval(() => {
    if(progress >= 100){
      clearInterval(lexiconTimer);
      return;
    }
    progress += 10;
    top.ydk._simulateNative('onLoadOfflineLexiconProgress' , {
      code : 1000,
      errMsg : '',
      module : 'OfflineDict',
      dict : params.dict,
      type : params.type,
      rate : progress
    } , function(res){
    })
  } , 500);
}

ydk.removeOfflineLexicon = (params) => {
  console.debug('removeOfflineLexicon! ' + params)
}

ydk.stopLoadOfflineLexicon = (params) => {
  loadingDict = params.dict;
  setTimeout(() => {
    var ret = {
      code : 1000,
      errMsg : ''
    };
    if(params.option == 'start'){
      ydk.downloadOfflineLexicon({
        dict : params.dict
      })
    }else{
      clearInterval(lexiconTimer);
    }
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  } , 100);
}

/*
 * 监听vip状态,
 * 该接口仅在登录的时候通知前端vip信息变化，
 * 退出登录时需要通过监听 onLoginStatusChanged 改变广告状态
 * 客户端不知道为什么不能把退出也加在这个接口里，可能不行吧
 */
ydk.onVipInfoGot = (params) => {
  setTimeout(() => {
    var ret = {
      code : 1000,
      errMsg : "",
      // 当isVip为false并且expire不为空时，则判定为过期
      isVip : false,     
      // expire : '216245400',  //到期时间
      auto : true, //自动续费
      open : true, //是否关闭自动续费
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  } , 100);
}

/**
 * 通知客户端更新vip信息
 */
ydk.refreshVipInfo = (params) => {
  setTimeout(() => {
    var ret = {
      code : 1000,
      errMsg : "",
    };
    //params.success && params.success(ret);
    //params.complete && params.complete(ret);
  } , 100);
}


/**
 *  获取用户信息   
 */
ydk.getProfile = (params) => {
  setTimeout(() => {
    var ret = {
      code : 1000,
      errMsg : "",
      profile : {
        "option_avatar": "https://oimagea7.ydstatic.com/image?id=7198242120915880724&product=dict",
        "option_birthday": "1",
        "option_birthmonth": "1",
        "option_birthyear": "2009",
        "option_education": "8",
        "option_focus": "",
        "option_gender": "1",
        "option_identity": "",
        "option_introduction": "我是来自测试",
        "option_lock": "",
        "option_lv1city": "",
        "option_occupation": "fdsfdsf",
        "option_plugins": "",
        "option_province": "",
        "option_school": "fdsfdsf",
        "user_forum_like": "0",
        "user_forum_post": "0",
        "user_forum_reply": "0",
        "user_indexdetail": "0",
        "user_indexdetail_20150129": "0",
        "user_queryword": "0",
      }    
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  } , 100);
}


/*
  获取用户名
 */
ydk.getNickname = (params) => {
  setTimeout(() => {
    var ret = {
      code : 1000,
      errMsg : "",
      nickname : "testName"    
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  } , 100);  
}
/**
 * 清楚历史记录
 */
ydk.clearHistory = (params) => {
  indexedDB.deleteDatabase('dict_history')
}

/*
  获取客户端基本信息
 */
ydk.getClientInfo = (params) => {
  setTimeout(() => {
    var ret = {
      code : 1000,
      errMsg : "",
      "abtest":"9",
      "appid":"",
      "debug":true,
      "downloadUrl":"http://cidian.youdao.com/download/YoudaoDict.exe",
      "imei":"70737aaaf9fa00af6",
      "isLastVersion":true,
      "keyfrom":"deskdict.Main",
      "mid":"6.000000.1.000000",
      "model":"",
      "productName":"dict",
      "screen":"1920.000000x1080.000000",
      "vendor":"unknown",
      "version":"7.2.0.0615"   
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  } , 100);  
}



//获取离线资源包信息
ydk.getResourceInfo = (params) => {
  setTimeout(() => {
    if(params.type == 'Dictionary') {
      params.success && params.success(require('./dicResourceInfoMock.json'));
      params.complete && params.complete(require('./dicResourceInfoMock.json'));
    }
    if(params.type == 'nmt_model'){
      params.success && params.success(require('./nmtResourceInfoMock.json'));
      params.complete && params.complete(require('./nmtResourceInfoMock.json'));      
    } 

  }, 100);
}


ydk.onDownloadResourceProgress = function(params){
  setTimeout(function(){
    var ret = {
      code : 1000,
      rate : 0,
      errMsg:'',
      id:'cp_nmt.7z',
      type: ''
    }
    params.success && params.success(ret);
    params.complete && params.complete(ret);    
  } , 100)
}