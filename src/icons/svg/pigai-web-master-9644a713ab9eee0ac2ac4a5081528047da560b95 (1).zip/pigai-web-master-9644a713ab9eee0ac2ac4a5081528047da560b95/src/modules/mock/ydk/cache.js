import indexdb from 'commons/indexedDB.js';

var options =  {
  keyPath: 'id',//主键
  autoIncrement: false,//是否自增长
  indexes : [{
    name : 'keyIndex',
    column : 'key',
    unique : false
  }]
};

var store = new indexdb('ydk_mock' , 'jsonapi' , options);



ydk.saveCache = (params) => {

  if(typeof(params.value) != 'string'){
    throw new Error('ydk.saveCache value must be String');
  }

  store.save({
    id : params.key,
    key : params.key,
    data : params.value
  })

};

ydk.getCache = (params) => {

  var callback = (ret) => {
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  };

  var ret = {
    code : 1000,
    data : {}
  };

  store.execute((_store) => {
    var index = _store.index('keyIndex');
    params.keys.forEach((k , i) => {
      index.get(k).onsuccess = function(e){
        if(e.target.result){
          ret.data[k] = e.target.result.data;
        }else{
          ret.data[k] = null;
        }
        if(Object.keys(ret.data).length == params.keys.length){
          callback(ret);
        }
      };
    })
  })
};


ydk.removeCache = (params) => {
  params.keys.forEach((key) => {
    store.remove(key);
  })
};


ydk.clearCache = (params) => {
  store.clear();
};

