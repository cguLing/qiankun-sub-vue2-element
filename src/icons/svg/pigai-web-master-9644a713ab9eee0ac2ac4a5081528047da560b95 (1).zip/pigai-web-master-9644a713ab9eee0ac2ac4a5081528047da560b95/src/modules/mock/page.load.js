var url = location.pathname.replace(/^\/build\// , '') + location.search;

/**
 * for testcase
 */
if(location.protocol == 'file:' && window.__absloute){
  var __absloute = window.__absloute;
  var pathname = location.pathname.toLowerCase();
  var p = pathname.indexOf(__absloute.toLowerCase());

  url = location.pathname.substring(p + __absloute.length)
          .replace(/\/+/g , '/')
          .replace(/^\/?/ , '')
          + location.search;
}

$(() => {
  if(window.name != 'mainFrame')return;
  top.ydk._simulateNative('onPageLoadStart' , {
    code : 1000,
    url : url
  } , function(res){
  })
});