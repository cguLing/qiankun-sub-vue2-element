window.external = {
  cppCall : function(){
    console.debug(arguments);
  }
}