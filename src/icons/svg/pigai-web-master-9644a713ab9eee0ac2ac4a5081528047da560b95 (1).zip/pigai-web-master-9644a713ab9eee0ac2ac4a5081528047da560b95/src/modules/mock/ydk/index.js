/**
 * 本地开发时候，需要模拟的接口
 */
import './dict.js';
import './fanyi.js';
import './other.js';
import './setting.js';
import './wordbook.js';
import './cache.js';
import './translate.js';

/* istanbul ignore next */
ydk.broadcast = function(params){
  var data = params.data;
  var format = 'string';
  //自动格式化数据
  if(typeof(data) == 'object'){
    data = JSON.stringify(data);
    format = 'json';
  }
  console.debug('ydk.broadcast' , params.type , format , data);
  top.ydk._simulateNative('onBroadcast' , {
    code : 1000,
    data : {
      type : params.type,
      format : format,
      data : data
    }
  } , function(res){
    params.success && params.success();
  })
};