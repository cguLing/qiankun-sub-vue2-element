import data from './tranMockData1.json';
import data1 from './viewpage.json';
//import tableData from './tranMockData2.json';
ydk.showTransResult = function(params){
  setTimeout(() => {
    var ret = {
      code: 1000,
      data: data.data,
      errMsg : '',
      key : '12434324324'
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  } , 100);  
}


ydk.loadDTResult = function(params){
  setTimeout(() => {
    var ret = {
      code: 1000,
      data: data1,
      errMsg : '',
      key : '12434324324'
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  } , 100);  
}