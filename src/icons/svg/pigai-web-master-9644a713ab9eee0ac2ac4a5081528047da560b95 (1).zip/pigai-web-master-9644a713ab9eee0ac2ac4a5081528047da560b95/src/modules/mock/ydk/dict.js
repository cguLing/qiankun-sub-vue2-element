import api from 'api';

/* istanbul ignore next */
var getDictResultLocal = (params) => {
  var success = params.success;
  params.success = (res) => {
    if(res.data && res.data.basic){
      success && success(res);
    }else{
      params.fail && params.fail(res);
    }
  };
  api(params , true);
}


/* istanbul ignore next */
ydk.getDictResult = function(params) {
  // console.trace(params)
  var keyword = params.data.keyword;
  var lang = params.data.lang;
  var type = params.data.type;
  var dicts = params.data.dicts;
  var requestId = params.data.requestId;


  var wrap = (callback) => {
    if(!callback)return null;
    return function(res){
      res.online = true;
      res.requestId = params.data.requestId;
      callback(res);
    }
  }

  
  params.url = 'http://dict.youdao.com/jsonapi?doctype=json';
  //params.url = 'http://th077x.corp.youdao.com:11227/jsonapi?doctype=json'; //测试
  
  params.success = wrap(params.success);
  params.fail = wrap(params.fail);
  params.complete = wrap(params.complete);

  params.data = {
    le : lang,
    q : keyword,
    dicts : dicts,
    requestId : requestId
  };

/*
 * mini查询结果从fsearch改为jsonapi，
 * 1. fsearch 接口没有查词提示
 * 2. 6.3版本用的search接口，服务端不建议使用，速度较慢
 * 3. 现版本使用jsonapi
 */

  switch(type){
    case 'detail':
    case 'mini':
    case 'ldetail':
      //牛津词典测试
      // params.url = 'http://odictdataserver-dev.youdao.com/jsonapi?doctype=json';

      //自动语言选择测试
      //params.url = 'http://th077x.corp.youdao.com:11227/jsonapi?keyfrom=dataserver';

      //线上查词
      params.url = 'http://dict.youdao.com/jsonapi?doctype=json';      
      api(params , true);
      return;
    case 'quick':
      //速查接口（单词本添加单词 及 卡片模式/复习模式 用到 ）
      params.url = 'http://dict.youdao.com/jsonresult?type=1&pos=-1in=YoudaoDict';
      api(params , true);
      return;
    default:
      getDictResultLocal(params);
  }

};


/**
 * 调用客户端发音
 */
/* istanbul ignore next */
ydk.playNativeVoice = function(params){
  ydk.playVoice({
    localId : params.localId,
    currentTime : 0
  });
};

/**
 * 停止客户端发音
 */
/* istanbul ignore next */
ydk.stopNativeVoice = function(){
  ydk.stopVoice({});
};
