/* istanbul ignore next */
ydk.closeSuggest = (params) => {
  console.debug('closeSuggest');
  if (top != window) {
    top.ydk.closeSuggest(params);
  }
}

/* istanbul ignore next */
ydk.showWin = (params) => {
  console.debug('showWin');
}

/* istanbul ignore next */
ydk.openOfflineDictWin = (params) => {
  console.debug('openOfflineDictWin');
}

/* istanbul ignore next */
ydk.setWinMove = (params) => {
  console.debug('setWinMove');
}

/* istanbul ignore next */
ydk.showCornerPopup = (params) => {
  console.debug('showCornerPopup');
}

/* istanbul ignore next */
ydk.setWinHeight = (params) => {
  console.debug('setWinHeight', params.height);
}

/* istanbul ignore next */
ydk.setWinSize = (params) => {
  console.debug('setWinSize', params.width, params.height);
}

/* istanbul ignore next */
ydk.checkUpdate = (params) => {
  console.debug('checkUpdate');
}

/* istanbul ignore next */
ydk.closeWin = (params) => {
  console.debug('closeWin');

}

/* istanbul ignore next */
ydk.minimizeWin = (params) => {
  console.debug('minimizeWin');
}

/* istanbul ignore next */
ydk.setDebug = (params) => {
  console.debug('setDebug', params);
}

/* istanbul ignore next */
ydk.setTop = (params) => {
  console.debug('setTop');
}

/* istanbul ignore next */
ydk.copyToClipboard = function (params) {
  console.debug('copyToClipboard', params);
}

/* istanbul ignore next */
ydk.setHasHistory = function (params) {
  console.debug('setHasHistory', params);
  if (top != window) {
    top.ydk.setHasHistory(params);
  }
}

/* istanbul ignore next */
ydk.rlog = (params) => {
  console.debug('rlog', params);
}

/* istanbul ignore next */
ydk.openWin = (params) => {
  console.debug('openWin', params);
}

/* istanbul ignore next */
ydk.setQueryFocus = (params) => {
  console.debug('setQueryFocus', params);
}

/* istanbul ignore next */
ydk.setQuerySelectAll = (params) => {
  console.debug('setQuerySelectAll', params);
}

/* istanbul ignore next */
ydk.selectLocalFile = (params) => {
  _.delay(() => {
    var ret = {
      code: 1000,
      cancel: true,
      fileName: '图片路径'
    }
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  }, 200)
}

/* istanbul ignore next */
ydk.updateWinZOrder = (params) => {
  console.debug('updateWinZOrder!');
}

/* istanbul ignore next */
ydk.getGrammarText = (params) => {
  _.delay(() => {
    var ret = {
        grammarParams: JSON.stringify({
          isModfiy: true,
          text:'I has a apple. i like it so much. \nbut i like grapes better',
          // text: "Remember when you were a careless eight year old kid riding a bike with your friends, racing each other around the neighborhood? Remember that feeling of absolute freedom as you felt the wind in your hair and the smile it put on your face? I never thought I would feel that way as a grown up,until my friends presented me a red brand-new bike. At first,I was a bit skeptical about the total idea of commuting by bike. One morning a couple of days later, I changed completely my mind.I was stuck at a traffic jam and saw in my rear mirror a man in a suit riding a classy bike with his laptop case in one hand and a handlebar in the other.\r\nI figured out it would take him about 15 minutes to get to the office while I was still sitting in my car and waiting for the cars in line ahead to move, even if just for a inch.I was always very afraid of being late for my business meetings.\r\nThat is when I decided to get on the bike.I haven’t regretted my decision so far.One of the best things about cycling is that the bike is perfect for exercising.Just cycling to and from work or to the shops every day is enough to keep you healthy and happy.Besides, its incredibly liberating to be able to get anywhere without loosing time in traffic jams.Also don’t forget about the environment benefits.\r\nCycling helps to reduce air pollution while reducing also traffic congestion and the need for gas. At some point, I realized that I started to use the bike more often, not only to get to work, but also to catch up with friends and to head out for coffee on weekends.I loved this style of traveling because it lets you really appreciate what you are seeing around you.You can stop anywhere you want and yet you can cover alot of distance.That daily distance I rode to work was no longer enough for me.I started riding to the nearest decent mountain bike trails so I could spent the day going up and down hills.I did it because it was fun.Because I enjoyed it.\r\n“I wish I could bike all the way round the world” I said to myself one day.And than I thought, “Why not ?”OK, I knew I couldn’t ride across the oceans.I came up with the idea to ride across each of the continents, from coast to coast.The more I thought about it, the more excited I became about my future plans.If I will do this, I will have to thoroughly prepare, I thought.I was also very scare.Would I be able to make it over towering mountains and across burning deserts ? \r\nWhat if I got lost somewhere and didn’t know the language ?After a few months of training, I set off.This was hard at first, but soon I realized that everywhere I went people cheered me on when they heared about my journey.\r\nThe newspaper back home reported on my progress.Once or twice I ran out of money and has to spend a couple weeks doing odd jobs before I could continue on my way.I never gave up on my idea, and a year and six month later, I found myself petaling back toward the place where it all began.my journey was over and I was home.These days, I continue exploring the world with  my bike as often as I can.Thanks to my bike, I’ve made countless friends, seen incredible sights, and had unforgettable adventures.I would have missed out on all of that if I hadn’t decide to try biking instead of driving! I guess there are an upside to traffic jams after all!"
          // text: "Our newspaper Beijing on February 19 (reporter Feng Hua) reporter learned from NASA's lunar exploration and space engineering center: the goddess of the moon lander and 4 \"yutu ii lunar rover again through 14 celestial pole test at low temperature, respectively, on February 18 February 17, 6 am 57 points and moonlit\" dormant \"end of the five to 17 points, successful independent awakened by illumination, enter the tenth of May Day working period.\r\n\r\nAccording to introducing, in response to the moonlit long-term technical problems without light and extreme low temperature environment, team will be the goddess of the moon probe surface model is divided into 4 month day working mode and sleep mode to the blue corn moon.\r\nAt present, the goddess of the moon lander and 4 \"yutu ii lunar rover are smooth state, working properly.\r\nLunar rover will move from northwest to southwest, synchronous drive the new target detection, the tenth of May Day work as planned.\r\n\r\nAs of February 19, 2020 detector has 412 days on the back of the moon, \"yutu ii lunar rover safety walk 378.45 meters.\r\nA record breaking the \"lunar rover, keep the surface of the cumulative work 10 months of world records,\" yutu ii has become the history of mankind the longest working hours in the moon rover."
          // text: '探査機は月の裏側で412日間作業を行い、「玉兎2号」月面車は累計378.45メートルを安全に走行した。これまで「月面車一号」が保持していた月面での累積勤務期間10カ月の世界記録を破り、「玉兎二号」は人類史上最も長い月面勤務期間を持つ月面車となった'
        })
    }
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  }, 100)
}
