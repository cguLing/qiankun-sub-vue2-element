/**
 * 使用indexeddb模拟保存读取操作
 */
import indexdb from 'commons/indexedDB.js';

var options = {
  keyPath: 'id', //主键
  autoIncrement: false //是否自增长
};


var getKey = (params) => {
  return [params.word, params.lang].join(':');
};

var store1 = new indexdb('ydk_mock', 'wordbook', options);

var store2 = new indexdb('ydk_mock', 'wordbook_category', {
  keyPath: 'name', //主键
});

ydk.addToWordBook = function (params) {
  params.progress = _.isNumber(params.progress) ? params.progress : -1;
  params.category = (params.category == '未分组') ? '' : params.category
  store1.save({
    id: getKey(params),
    word: params.word,
    // lang : 'en',//由于目前客户端不支持多语言单词本,因此都固定为英语
    lang: params.lang,
    trans: params.trans,
    phonetic: params.phonetic,
    category: params.category,
    progress: params.plan ? 1 : -1, // 1为加入复习还没开始复习，-1为还没加入复习，没有 0 这个状态；
    addtime: _.now(),
    mtime: _.now(), //上次复习的时间
  });
  onWordBookChanged(params, 'add');
  params.success && params.success();
  params.complete && params.complete();
}

ydk.updateToWordBook = function (params) {
  params.progress = _.isNumber(params.progress) ? params.progress : -1;
  store1.query(getKey(params), (res) => {
    var progress = res.progress;
    if (progress == -1 && params.plan) {
      progress = 0;
    } else if (!params.plan) {
      progress = -1;
    }
    store1.save({
      id: getKey(params),
      word: params.word,
      lang: params.lang,
      phonetic: params.phonetic || '',
      trans: params.trans || '',
      category: params.category || '',
      progress: progress,
      notes: params.notes || '',
    });
    onWordBookChanged(params, 'update')
  })
}

ydk.removeFromWordBook = function (params) {
  params.data.forEach((d) => {
    store1.remove(getKey(d))
    onWordBookChanged(d, 'remove');
  })
}

ydk.checkWordBook = function (params) {
  store1.query(getKey(params), (res) => {
    setTimeout(() => {
      var ret = {
        code: 1000,
        has: res != null,
        data: res
      };
      params.success && params.success(ret);
      params.complete && params.complete(ret);
    }, 100);
  })
};


ydk.syncWordBook = function (params) {
  setTimeout(() => {
    params.complete();
    params.success();
    onWordBookChanged({}, 'sync');
  }, 3000);
};

ydk.queryWordBook = function (params) {
  store1.all((data) => {
    if (params.category && params.category != '*') {
      data = _.filter(data, (d) => {
        return d.category == params.category;
      });
    } else if (!params.category) {
      data = _.filter(data, (d) => {
        return !d.category;
      });
    }
    //对order进行mock操作
    if (params.order == 'timenew') {
      data = _.sortBy(data, 'addtime').reverse();
    } else if (params.order == 'timeold') {
      data = _.sortBy(data, 'addtime');
    } else if (params.order == 'wordasc') {
      data = _.sortBy(data, 'word');
    } else if (params.order == 'worddesc') {
      data = _.sortBy(data, 'word').reverse();
    } else if (params.order == 'progressquick') {
      data = _.sortBy(data, 'progress');
    } else if (params.order == 'progressslow') {
      data = _.sortBy(data, 'progress').reverse();
    }
    var total = data.length;
    data = data.slice(params.start, Math.min(total, params.start + params.size));
    var ret = {
      code: 1000,
      data: data,
      total: total
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  });
}

ydk.importToWordBook = (params) => {
  _.delay(() => {
    var ret = {
      code: 1000,
      num: 20,
      repeat: false
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
    onWordBookChanged({}, 'import');
  }, 200);
}

ydk.exportFromWordBook = (params) => {
  _.delay(() => {
    var ret = {
      code: 1000,
      num: 20
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  }, 100);
}
ydk.cancleExportFromWordBook = (params) => {
  _.delay(() => {
    var ret = {
      code: 1000
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
    console.debug('ydk.cancleExportFromWordBook!');
  })
}

ydk.queryWordBookCategory = (params) => {
  store2.all((data) => {
    var ret = {
      code: 1000,
      data: data
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  });
}

ydk.addWordBookCategory = (params) => {
  store2.save({
    name: params.name
  });
  var ret = {
    code: 1000,
  };
  params.success && params.success(ret);
  params.complete && params.complete(ret);
  onWordBookChanged({}, 'category');
}

ydk.updateWordBookCategory = (params) => {
  store2.remove(params.name);
  store2.save({
    name: params.newname
  });
  var ret = {
    code: 1000,
  };
  params.success && params.success(ret);
  params.complete && params.complete(ret);
  onWordBookChanged({}, 'category');
}

ydk.removeWordBookCategory = (params) => {
  store2.remove(params.name);
  var ret = {
    code: 1000,
  };
  params.success && params.success(ret);
  params.complete && params.complete(ret);
  onWordBookChanged({}, 'category');
}

var shuffle = function (data) {
  var arr = data;
  for (var j, x, i = arr.length; i; j = parseInt(Math.random() * i), x = arr[--i], arr[i] = arr[j], arr[j] = x);
  return arr;
}

ydk.queryWordBookForReview = (params) => {
  console.log(params);
  store1.all((data) => {
    var array = []; // 复习的单词总数
    var has = false; //是否有单词在复习计划
    data = data || null;

    data.forEach((d) => {
      if (d.progress > -1 && d.progress < 10) {
        has = true;
        if ((_.now() - d.mtime) > 60000) {
          array.push(d);
        }
      }
    });

    // 是否排序
    if (params.disorder) {
      console.log('shuffle');
      array = shuffle(array);
    }

    // 选择分组
    var categoryData = [];
    var cat = params.category;

    if (cat.length == 0) {
      // 未分组单词
      array.forEach((d) => {
        if (d.category == '') {
          categoryData.push(d)
        }
      })
    } else if (params.category == '*') {
      // 所有分组
      categoryData = array;
    } else {
      array.forEach((d) => {
        if (d.category == params.category) {
          categoryData.push(d)
        }
      })
    }
    console.log('categoryData');
    console.log(categoryData);
    array = categoryData;
    console.log(array);


    var total = array.length;
    array = array.slice(params.start, Math.min(total, params.start + params.size));
    var ret = {
      code: 1000,
      data: array,
      has: has,
      total: total,
    };
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  });
};

ydk.setWordBookPlan = function (params) {
  params.data.forEach((d) => {
    store1.query(getKey(d), (data) => {
      if (!data) return;
      data.progress = params.plan ? 1 : -1; // 1为加入复习还没开始复习，-1为还没加入复习，没有 0 这个状态；
      data.mtime = _.now();
      store1.save(data)
      onWordBookChanged(data, 'progress')
    })
  })
};

ydk.setWordBookCategory = function (params) {
  params.data.forEach((d) => {
    store1.query(getKey(d), (data) => {
      if (!data) return;
      data.category = params.category;
      store1.save(data)
    })
    onWordBookChanged(d, 'update')
  })
};

ydk.reviewWordBook = function (params) {
  params.data.forEach((d) => {
    store1.query(getKey(d), (data) => {
      if (!data) return;
      if (params.remember) {
        data.progress = data.progress + 1;
        if (data.progress > 9) {
          data.progress = 9;
        }
        data.mtime = _.now();
      } else {
        if (data.progress < -1) {
          data.progress = -1;
        }
      }
      store1.save(data);
      onWordBookChanged(data, 'progress')
    })
  })
};


var onWordBookChanged = function (params, type) {
  top.ydk._simulateNative('onWordBookChanged', {
    code: 1000,
    type: type,
    word: params.word,
    lang: params.lang,
    trans: params.trans,
    progress: params.progress
  }, function (res) {})
}
