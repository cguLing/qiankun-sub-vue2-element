import api from 'api'

ydk.getTranslateResult = function(params){
  params.url = 'http://fanyi.youdao.com/translate_t?version=2.1&smartresult=dict&smartresult=rule';
  params.data = {
    i : params.data.keyword,
    from : params.data.from,
    to : params.data.to,
  };
  api(params);
};



ydk.getSimsentResult = function(params){
  params.url = 'http://simsent.youdao.com/search?doctype=json&appZengqiang=0';
  params.data = {
    q : params.data.keyword
  };
  api(params);
};


ydk.onTransLangChanged = function(params){
  _.delay(() => {
    var ret = {
      srcLang: 'auto',
      dstLang: ''
    }
    params.success && params.success(ret);
    params.complete && params.complete(ret);
  }, 200)
}