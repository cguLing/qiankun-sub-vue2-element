/**
 * 面板展示/隐藏控制工具
 * 常用于：下拉菜单
 *
 * 说明：
 * pannel=''，表示当点击时候，显示哪个对象
 * pannel-close，表示当点击时候，自动关闭面板
 *
 * 用法:
 * <a href='' pannel='#pannel1'>展开</a>
 *
 * <ul id='pannel1'>
 *   <li pannel-close>菜单1</li>
 *   <li pannel-close>菜单2</li>
 *   <li pannel-close>菜单3</li>
 * </ul>
 */


$(() => {

  var 
    win = window,
    $lastLinker,
    $lastPannel;

  var closeAll = function(e) {
    $lastLinker && $lastLinker.removeClass('active');
    $lastPannel && $lastPannel.hide().removeClass('active').removeAttr('onpannel').trigger('close');
    $lastLinker = null;
    $lastPannel = null;
  };

  $('body').on('click' , '[pannel]' , function(e){
    var 
      $self = $(this),
      $target = $($self.attr('pannel'));
      
    if($target.is(':visible')){
      closeAll();
    }else{
      //关闭其他窗口
      closeAll();

      /**
       * 这里使用delay，避免事件冒泡，到顶层，又被立刻关闭
       */
      _.delay(() => {
        //显示目标面板
        $target.show().attr('onpannel' , '1');
        $lastLinker = $self.addClass('active');
        $lastPannel = $target.addClass('active').trigger('open');
      })
    }
  }).on('click' , '[onpannel]' , function(e){
    e.stopPropagation();
  }).on('click' , '[pannel-close]' , function(e){
    closeAll();
  }).bind('click' , closeAll)
  .bind('mousedown' , function(e){
    //如果不是左键，则关闭
    if(e.button != 0){
      closeAll();
    }
  });

  $(win).bind('blur' , closeAll);
});