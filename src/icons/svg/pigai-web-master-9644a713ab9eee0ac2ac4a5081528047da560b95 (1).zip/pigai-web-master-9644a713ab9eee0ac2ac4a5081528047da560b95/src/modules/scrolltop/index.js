/**
 * 显示返回顶部按钮
 */
import './index.scss'; 

export default function (obj){
  if($('a#scrollTop').length > 0) return;
  var $win = $(obj);
  var $top = $('<a href="javascript:;" id="scrollTop" class="icon icon-top m-scrolltop"></a>');


  $win.append($top);

  $top.click(() => {
    $win.animate({scrollTop:0},200);
    ydk.rlog({
      action: 'back_top',
      keyfrom: 'deskdict.main'
    });      
  });

  $win.off('scroll').on('scroll' , _.debounce(() => {
    if($win.scrollTop() == 0){
      $top.css('opacity' , 0);
    }else{
      $top.css('opacity' , 1);
    }
  } , 200));
}