import event from 'event';
import config from 'config';
import utils from 'commons/utils';

export default function(){
  $('html,body').off('click').on('click', '.m-voice', _.debounce(function(e) {
    var
      self = this,
      $this = $(self),
      url = $this.attr('data-url'),
      time = $this.attr('data-time'); // 单位为秒

    if (!url) {
      console.warn('m-voice', 'url is empty');
      return;
    }
    
    var _start = _.now();

    if (e.pageX) {
      //鼠标点击触发
      event.trigger.call(self, 'modules/voice/play/click');
    } else {
      //js触发，如$('xx').click
      event.trigger.call(self, 'modules/voice/play/trigger');
    }

    if (config.platform !== 'uwp') {
      top.ydk.playNativeVoice({
        localId: url
      })

      var keyword = utils.getQueryParamsString(url , 'audio');  
      if(keyword){
        ydk.rlog({
          other: 'dict_voice_load',
          keyfrom: 'deskdict.main',
          q: keyword,
          type: 'success'
        });
      }      
    } else {    
      ydk.playVoice({
        cache: false, //禁止ydk缓存对象
        localId: url, // 音频文件的 url
        currentTime: time || 0
      });
    }
  }, 10))
}
