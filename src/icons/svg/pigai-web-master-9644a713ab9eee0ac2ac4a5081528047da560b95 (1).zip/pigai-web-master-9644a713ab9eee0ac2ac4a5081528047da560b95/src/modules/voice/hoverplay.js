/**
 * 当鼠标hover，自动播放音频
 */
$(() => {
  var _play_timer;
  $('html,body').off('mouseenter , mouseleave').on('mouseenter', '.m-voice', function() {
    var $this = $(this);
    if ($this.attr('disable-hover')) {
      return;
    }
    _play_timer = setTimeout(() => {
      $this.click();
    }, 100);
  }).on('mouseleave', '.m-voice', function() {
    clearTimeout(_play_timer);
  });
})