/**
 * 打开对话框（不含头部）
 * @param  {Object} params {
 *   url : String,
 *   width : Number,
 *   height : Number
 * }
 *
 * 打开对话框（含头部）
 * @param  {Object} params {
 *   header : {
 *     title : '标题',
 *     showClose : true
 *   },
 *   url : String,
 *   width : Number,
 *   height : Number
 * }
 */
import * as broadcaster from 'modules/broadcast';

var 
  win = window,
  $html = $('html'),
  $doc = $(document);


export function open(params) {
  broadcaster.emit('dialog.open' , params , win == top ? 'local' : 'top');
}

export function openPic(params){
  broadcaster.emit('dialog.openPic' , params , win == top ? 'local' : 'top');
}

/**
 * 关闭对话框
 */
export function close() {
  broadcaster.emit('dialog.close' , null , win == top ? 'local' : 'top');
}

/**
 * 设置对话框宽高
 * @param {Object} params {
 *   width : Number,
 *   height : Number
 * }
 */
export function setSize(params) {
  broadcaster.emit('dialog.setSize' , params , window == top ? null : 'top');
}

/**
 * alert
 * @param  {Object} params {
 *  msg : String                      
 * }
 */
export function alert(params) {
  var 
    callbackId = 'alert_' + _.now(),
    success = params.success,
    cancel = params.cancel,
    complete = params.complete;

  if(typeof(params) == 'string'){
    params = {
      msg : params
    };
  }

  params.success = undefined;
  params.cancel = undefined;
  params.complete = undefined;
  params.callbackId = callbackId;


  broadcaster.emit('dialog.alert' , params , 'top');
  broadcaster.one(callbackId , (res) => {
    if(res.type == 'success'){
      success && success();
      complete && complete();
    }else{
      cancel && cancel();
      complete && complete();
    }
  });
}

/**
 * confirm
 * @param  {Object} params {
 *  msg : String                      
 * }
 */
export function confirm(params) {
  var 
    callbackId = 'confirm_' + _.now(),
    success = params.success,
    cancel = params.cancel,
    complete = params.complete;

  if(typeof(params) == 'string'){
    params = {
      msg : params
    };
  }

  params.success = undefined;
  params.cancel = undefined;
  params.complete = undefined;
  params.callbackId = callbackId;


  broadcaster.emit('dialog.confirm' , params , 'top');
  broadcaster.one(callbackId , (res) => {
    if(res.type == 'success'){
      success && success();
      complete && complete();
    }else{
      cancel && cancel();
      complete && complete();
    }
  })
  top.focus();
}

/**
 * inform
 * @param  {Object} params {
 *  msg : String                      
 * }
 */
export function inform(params) {
  var 
    callbackId = 'inform_' + _.now(),
    success = params.success,
    cancel = params.cancel,
    complete = params.complete;

  if(typeof(params) == 'string'){
    params = {
      msg : params
    };
  }

  params.success = undefined;
  params.cancel = undefined;
  params.complete = undefined;
  params.callbackId = callbackId;


  broadcaster.emit('dialog.inform' , params , 'top');
  broadcaster.one(callbackId , (res) => {
    if(res.type == 'success'){
      success && success();
      complete && complete();
    }else{
      cancel && cancel();
      complete && complete();
    }
  })
  top.focus();
}

/**
 * 自动设置窗口大小
 *
 * 要兼顾以下情况：
 * 1、首次展示对话框（此时size:0,0）
 * 2、已经打开了对话框，调整宽高（此时size不为0,0）
 */
export function autoSize(){
  Vue.nextTick(() => {
    setSize({
      width : $doc.width(),//支持case 1,2
      height : $html.height()//支持case 2
    });
  });
}