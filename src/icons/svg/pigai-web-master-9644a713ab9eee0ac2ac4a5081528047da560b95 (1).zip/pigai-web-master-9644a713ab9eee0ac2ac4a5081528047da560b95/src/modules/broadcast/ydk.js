import event from 'event';

exports.trigger = function(type , data) {
  ydk.broadcast({
    type : type,
    data : data
  })
};

$(() => {
  ydk.onBroadcast({
    success : function(res){
      event.trigger.call(null , res.data.type , res.data.data);
    }
  })
})