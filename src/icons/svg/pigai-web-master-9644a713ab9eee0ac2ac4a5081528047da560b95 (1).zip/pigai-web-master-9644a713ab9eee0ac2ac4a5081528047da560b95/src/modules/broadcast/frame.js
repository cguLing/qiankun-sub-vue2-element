/**
 * 主框架与子页面通讯模块
 * 
 */
import event from 'event';

var win = window;
var isTop = win == top;

var _seq = new Date().getTime() + Math.random() * 100000;

var copy = (args) => {
  // avoid leaking arguments:
  // http://jsperf.com/closure-with-arguments
  var i = args.length
  var arr = new Array(i);
  while (i--) {
    arr[i] = args[i];
  }
  return arr;
}


var postToFrames = (msg) => {
  var len = win.frames.length;
  /**
   * 向子iframe窗口广播消息
   */
  for(var i = 0 ; i < len ; i++){
    try{
      win.frames[i].postMessage({
        _seq : ++_seq,
        dictbroadcast : msg
      } , '/');
    }catch(e){
      console.error(e);
    }
  }
}

export function trigger() {
  var arr = copy(arguments);
  event.trigger.apply(this , arr);

  if(isTop){
    postToFrames(JSON.stringify(arr))
  }else{
    top.postMessage({
      _seq : ++_seq,
      dictbroadcast : JSON.stringify(arr)
    } , '/');
  }
};

export function triggerTop(){
  var arr = copy(arguments);

  if(top == win)return;

  top.postMessage({
    _seq : ++_seq,
    scope : 'top',
    dictbroadcast : JSON.stringify(arr)
  } , '/');
};


win.addEventListener('message',function(e){
  if(!e.data.dictbroadcast){
    return;
  }
  var len = win.frames.length;
  if(isTop){
    var match = false;
    //保证消息来源可信
    for(var i = 0 ; i < len ; i++){
      if(e.source == win.frames[i]){
        match = true;
        break;
      }
    }
    
    if(
      !match 
      && location.protocol != e.source.location.protocol
    ){
      return;
    }
  }else{
    if(
      e.source != top
      && location.protocol != e.source.location.protocol
    ) return;
  }


  try{
    event.trigger.apply(this , JSON.parse(e.data.dictbroadcast));
  }catch(e){
    console.error(e);
  }

  if(e.data.scope != 'top'){
    postToFrames(e.data.dictbroadcast);
  }

},false);

