/**
 * 统一消息通讯组件
 *
 * 支持：
 * 1、当前页面消息广播 local
 * 2、当前父页面和子页面消息广播 frame
 * 3、所有cef窗口消息广播 all
 */

import event from 'event';
import * as framer from './frame.js';
import * as ydker from './ydk.js';

/**
 *
 * broadcast(type , data , scope(local，frame , all))
 * 
 */
export function emit (type , data , scope = 'local') {
  switch(scope){
    case 'local':
      event.trigger('modules/broadcast/' + type , data);
      break;
    case 'frame':
      framer.trigger('modules/broadcast/' + type , data);
      break;
    case 'top':
      framer.triggerTop('modules/broadcast/' + type , data);
      break;
    case 'all':
      ydker.trigger('modules/broadcast/' + type , data);
      break;
  }
}




export function on(type , callback){
  event.bind('modules/broadcast/' + type , callback)
}

export function one(type , callback){
  event.one('modules/broadcast/' + type , callback)
}