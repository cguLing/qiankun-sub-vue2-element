<!-- 首页内容渲染 -->
<template>
  <div id="doc">
    <Debug v-if="isDebugger"></Debug>
    <div id="main">
      <div id="right">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<script>
import 'global';
import Mock from 'global';
import LeftTab from 'global';
// import * as broadcaster from "modules/broadcast";

//懒加载模块
const Debug = () =>
  import(/* webpackChunkName: "Debug" */ 'components/debug/index.vue');

export default {
  computed: {
    isDebugger: function () {
      return this.$store.state.common.isDebugger;
    },
  },
  components: {
    LeftTab,
    Mock,
    Debug,
  },
  created() {
    //在页面加载时读取sessionStorage里的状态信息
    // if (sessionStorage.getItem("store")) {
    //   this.$store.replaceState(
    //     Object.assign(
    //       {},
    //       this.$store.state,
    //       JSON.parse(sessionStorage.getItem("store"))
    //     )
    //   );
    // }

    //在页面刷新时将vuex里的信息保存到sessionStorage里
    // window.addEventListener("beforeunload", () => {
    //   sessionStorage.setItem("store", JSON.stringify(this.$store.state));
    // });
  },
};
</script>


<style lang="scss">
@import "assets/sass/base/global.scss";
@import "assets/sass/base/index.scss";
</style>
