import Server from './server';
import Config from 'config';

class API extends Server {
  /**
   * 用途：英文作文批改
   * @url /pigai/action_json
   * @method POST
   * @return {promise}
   */

  async getPigaiEnglish(params = {}) {
    try {
      let _result = await this.axios(Config.pigaiUrl, 'POST', '/pigai/action_json', params);
      let result = _result.data;

      if (result && result.error_code === 0) {
        return result || {};
      } else {
        let err = {
          tip: '英文作文批改接口失败',
          response: result,
          data: params,
        }
        params.fail && params.fail(err)
        console.error(err);
      }
    } catch (err) {
      params.fail && params.fail(err)
      console.error(err);
    }
  }

}

export default new API();
