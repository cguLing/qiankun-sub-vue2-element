import axios from 'axios';

/**
 * 主要params参数
 * @params baseURL {string} 请求地址统一前缀 ***需要提前指定***  例如：http://cidian.youdao.com
 * @params method {string} 方法名
 * @params url {string} 请求地址  例如：/login 配合baseURL组成完整请求地址
 * @params timeout {number} 请求超时时间 默认 30000
 * @params params {object}  get方式传参key值
 * @params headers {string} 指定请求头信息
 * @params withCredentials {boolean} 请求是否携带本地cookies信息默认开启
 * @params validateStatus {func} 默认判断请求成功的范围 200 - 300
 * @return {Promise}
 * 其他更多拓展参看axios文档后 自行拓展
 * 注意：params中的数据会覆盖method url 参数，所以如果指定了这2个参数则不需要在params中带入
 * 取消axios请求参考：https://www.cnblogs.com/timmer/p/8615397.html
 */


const req = axios.create({
  timeout: 30000,
});


let pending = []; //声明一个数组用于存储每个ajax请求的取消函数和ajax标识
let cancelToken = axios.CancelToken;
let removePending = (config) => {
  for (let p in pending) {
    if (pending[p].u === config.url + '&' + config.method) { //当当前请求在数组中存在时执行函数体
      pending[p].f(); //执行取消操作
      pending.splice(p, 1); //把这条记录从数组中移除
    }
  }
}


//添加请求拦截器
req.interceptors.request.use(config => {
  //console.log('config==', config)
  removePending(config); //在一个ajax发送前执行一下取消操作
  config.cancelToken = new cancelToken((c) => {
    // 这里的ajax标识我是用请求地址&请求方式拼接的字符串，当然你可以选择其他的一些方式
    pending.push({
      u: config.url + '&' + config.method,
      f: c
    });
  });
  return config;
}, error => {
  return Promise.reject(error);
});


//添加响应拦截器
req.interceptors.response.use(response => {
  //console.log('response==', response.config)
  removePending(response.config); //在一个ajax响应后再执行一下取消操作，把已经完成的请求从pending中移除
  return response;
}, error => {
  return {
    data: {}
  }; //返回一个空对象，主要是防止控制台报错
});



export default class Server {
  axios(baseURL, method, url, params) {
    return new Promise((resolve, reject) => {
      if (typeof params !== 'object') params = {};
      let _option = params;
      _option = {
        method,
        url,
        baseURL,
        timeout: 30000,
        params: null,
        data: null,
        headers: null,
        withCredentials: true, //是否携带cookies发起请求
        validateStatus: (status) => {
          return status >= 200 && status < 300;
        },
        ...params,
      }
      req.request(_option).then(res => {
        resolve(res);
      }, error => {
        if (error.response) {
          reject(error.response.data);
        } else {
          reject(error);
        }
      })
    })
  }
}
