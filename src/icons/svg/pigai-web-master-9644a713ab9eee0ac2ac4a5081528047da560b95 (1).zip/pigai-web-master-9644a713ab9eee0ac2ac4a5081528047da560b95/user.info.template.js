module.exports = {
  username:'[username]',
  password:'[password]'
}
