/*eslint-disable */
var path = require('path');
var gulp = require('gulp');
var fs = require('fs');
var replace = require('gulp-replace');
var gutil = require('gulp-util');
var rename = require("gulp-rename");
var config = require(path.resolve(__dirname , '../config/index.js'));

// 创建时间戳，已作为文件夹开头名字，备份使用
function nowdir() {
  return __moment.format('YYYYMMDDHHmmss');
}


// 生成上线配置
gulp.task('build.config', function (cb) {
  gutil.log('[BUILD] 生成配置');

  if(!fs.existsSync('./src/config/config.template.js')){
    cb();
    return;
  }
  
  var props = config['build'];
  var stream = gulp.src('./src/config/config.template.js')
      .pipe(rename('config.js'))
      .pipe(replace('@now@' , new Date().getTime()))
      .pipe(replace('@versionPath@', nowdir())); 
  
  for (var k in props){
    stream = stream.pipe(replace('@' + k + '@' , props[k]));
  }
  
  return stream.pipe(gulp.dest('./src/config/'));
});

// 生成上线配置
gulp.task('release.config', function (cb) {
  gutil.log('[BUILD] 生成配置');

  if (!fs.existsSync('./src/config/config.template.js')) {
    cb();
    return;
  }

  var props = config['release'];
  var stream = gulp.src('./src/config/config.template.js')
    .pipe(rename('config.js'))
    .pipe(replace('@now@', new Date().getTime()))
    .pipe(replace('@versionPath@', nowdir()));

  for (var k in props) {
    stream = stream.pipe(replace('@' + k + '@', props[k]));
  }

  return stream.pipe(gulp.dest('./src/config/'));
});


// 开发配置
gulp.task('dev.config', function (cb) {
  gutil.log('[BUILD] 生成配置');

  if(!fs.existsSync('./src/config/config.template.js')){
    cb();
    return;
  }
  
  var props = config['dev'];
  var stream = gulp.src('./src/config/config.template.js')
      .pipe(rename('config.js'))
      .pipe(replace('@now@' , new Date().getTime())); 
  
  for (var k in props){
    stream = stream.pipe(replace('@' + k + '@' , props[k]));
  }
  
  return stream.pipe(gulp.dest('./src/config/'));
});

// 生成cms配置
gulp.task('cms.config', function (cb) {
  gutil.log('[BUILD] 生成配置');

  if (!fs.existsSync('./src/config/config.template.js')) {
    cb();
    return;
  }

  var props = config['cms'];
  var stream = gulp.src('./src/config/config.template.js')
    .pipe(rename('config.js'))
    .pipe(replace('@now@', new Date().getTime()));

  for (var k in props) {
    stream = stream.pipe(replace('@' + k + '@', props[k]));
  }

  return stream.pipe(gulp.dest('./src/config/'));
});
