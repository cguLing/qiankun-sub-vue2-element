// 打包流程中将静态资源上传svn
// 创建一个以时间戳为名的文件目录，存放每次build的静态资源js/css/image/fonts、和备份的html文件，统一使用脚本方式上传到cdn
// 1. 新建svn,backup目录
// 2. 准备静态资源
// 3. 上传静态资源和备份html到svn

var gulp = require('gulp');
var path = require('path');
var fs = require('fs');
var gulpSequence = require('gulp-sequence');
var find = require("../libs/find");
var child_process = require('child_process');
var propsDir = require('../config')
var config = require('../src/config/config.js');
var spawn = child_process.execSync;
var gutil = require('gulp-util');
var userInfo = {};
var props;

var MODE_MAP = [
  {
    name: 'inner',
    props: propsDir['build'],
    releaseValue: false,
    resourceSvnPublicPath: 'https://corp.youdao.com/svn/ydstatic/dict/pigai/build/', // svn目录前缀
  },
  {
    name: 'release',
    props: propsDir['release'],
    releaseValue: true,
    resourceSvnPublicPath: 'https://corp.youdao.com/svn/ydstatic/dict/pigai/release/', // svn目录前缀
  }
];

function getConfigProps() {
  for (var i = 0; i < MODE_MAP.length; i = i + 1) {
    if (config.release == MODE_MAP[i].releaseValue) {
      props = MODE_MAP[i]['props'];
    }
  }
}

// 根据模式获取配置
getConfigProps();


// 刷新CDN
gulp.task('refresh.cdn.dir', function (cb) {
  fs.exists("user.info.js", function (exists) {
    if (exists) {
      userInfo = require('../user.info.js');
      gulpSequence('refresh.cdn.shared', 'simplify.dist', cb)
    } else {
      gutil.log(gutil.colors.red('user.info.js不存在，请按user.info.template.js格式手动创建！！！'));
    }
  });
});

// 自动到http://corp.youdao.com/IT/updateshared/刷新dict文件，代替之前手动的操作
gulp.task('refresh.cdn.shared', function (cb) {
  gutil.log('开始刷新shared...');
  child_process.exec(`curl -u ${userInfo['username']}:${userInfo['password']} -d "request_log=dict&request_submit==%E6%8F%90%20%20%E4%BA%A4" -i http://corp.youdao.com/IT/updateshared/ | grep HTTP/1.1 | awk '{print $2}'`,
    function (error, stdout, stderr) {
      if (error !== null && stdout == 302) {
        gutil.log(gutil.colors.red('刷新[CDN-shared]出错: ' + error));
      } else {
        gutil.log(`点击链接 ${'http://corp.youdao.com/IT/updateshared/'} 查看是否有你红色ldap提交记录，如果没有，手动选择dict文件夹提交。 上传cdn到结束需要约5分钟左右：`.green);   
        cb();
      }
    });
});


// 创建svn目录
gulp.task('build.svnFolder', function () {
  var now = config.versionPath;
  var cdnpath = props['resourcePublicPath'];
  var dir = 'svn_' + now;

  // 当前build好的本地文件在dist文件夹
  var distDir = path.resolve('./dist');

  // 删除原来的目录
  spawn(['rm ', '-rf', 'svn_*'].join(' '), { cwd: distDir, encoding: 'utf-8' });

  // 创建新的目录
  spawn('mkdir ' + dir, { cwd: distDir, encoding: 'utf-8' });

  gutil.log('创建svn文件完成');


});


// 上传静态资源文件到CDN
gulp.task('svn.publish.resource', function () {

  var spawn = child_process.execSync;
  var distDir = path.resolve('./dist');

  var impor = function (file) {
    var dir = path.basename(file);
    var version = dir.replace(/^svn_/, '');

    // 1. 将dist/rs/* 复制到 svn_*/
    spawn('cp -rf rs/* svn_*/', { cwd: distDir });

    // 2. 自动push到svn, 修改CDN资源路径，每次在cdn目录后创建一个以时间戳命名的文件
    gutil.log('[SVN进度] 正在提交到：' + props['resourceSvnPublicPath'] + version)
    spawn('svn import -m "pigai import" ' +  dir + ' ' +props['resourceSvnPublicPath'] + version, { cwd: distDir });
    gutil.log('[SVN进度] 提交完成');
    
    // 3. 提交完成后，自动刷新cdn
    gulp.start('refresh.cdn.dir', function(){
      gutil.log(`如果该文件能访问，代表上传完成:  https:${props['resourcePublicPath']}${version}/html/index.html`.yellow);
      // 4. 提示push代码
      if(config.release) {
        gutil.log(`当前打包是正式服，必须等到上面文件能访问后才能push代码！`.red);
      }
    });
  };


  return gulp.start('build.svnFolder', function (cb) {
    gulp.src([distDir + '/svn_*'])
      .pipe(find(impor));
    cb && cb();
  });

});


// 将dist文件的rs/html/index.html复制到根目录，删除 rs/* svn_*文件夹，然后push代码
gulp.task('simplify.dist', function (cb) {
  var spawn = child_process.execSync;
  var distDir = path.resolve('./dist');

  // 1. 将dist/rs/* 复制到 svn_*/
  spawn('cp -rf rs/html/index.html ./', { cwd: distDir });

  // 2. 删除文件夹
  spawn(['rm ', '-rf', 'svn_*'].join(' '), { cwd: distDir, encoding: 'utf-8' });
  spawn(['rm ', '-rf', 'rs*'].join(' '), { cwd: distDir, encoding: 'utf-8' });

  cb && cb();
});



// 检查目标的配置文件是否与当前一致
MODE_MAP.forEach(function (item) {
  gulp.task('is.' + item.name, function (cb) {
    if (config.release != item.releaseValue) {
      gutil.log('[错误]编译配置与当前配置不一致');
      return;
    }
    cb();
  });
});


// 打包到测试服or正式服
MODE_MAP.forEach(function (item) {
  gulp.task('publish.' + item.name, ['is.' + item.name], function () {
    gulp.start('svn.publish.resource', function () {
      gutil.log('打包静态资源到cdn完成，可以当前未被修改的代码push到gitlab');
    });
  });
});
