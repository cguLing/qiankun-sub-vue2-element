var gulp = require('gulp');
var config = require('../config/index.js');
var props = config['cms'];
var cms = require('../libs/cms.js');

gulp.task('publish.cms', function (cb) {
  cms('./dist/cms', cb);
});