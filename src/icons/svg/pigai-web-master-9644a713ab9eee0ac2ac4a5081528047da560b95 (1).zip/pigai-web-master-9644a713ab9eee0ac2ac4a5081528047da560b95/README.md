# 批改web端

```
gulp help
```

## 目录结构
```
|- src 程序源文件
    |- assets 页面基础静态资源
    |- commons 公共JS、CSS
    |- components 公共的模块
    |- config  配置项
    |- modules 模块
    |- filter  全局filter方法
    |- api     接口请求
    |- router  路由控制
    |- store   状态存放
    |- pages   各个页面入口
    |- App.vue 总入口
|- build 开发环境和生产环境打包设置
    |- build   无压缩
    |- build.release  生产环境压缩
    |- dev-server   开发环境
|- config 开发环境和生产环境打包配置
    |- config.base   基本配置
    |- config.build  上线配置
    |- config.dev    开发配置
|- dist 打包之后文件所在位置
|- doc 说明文档
    |- attention
    |- dev
    |- api
```


## 开发帮助

[开发帮助](./doc/dev.md)

[接口文档](./doc/api.md)

[技术文档](./doc/attention.md)
