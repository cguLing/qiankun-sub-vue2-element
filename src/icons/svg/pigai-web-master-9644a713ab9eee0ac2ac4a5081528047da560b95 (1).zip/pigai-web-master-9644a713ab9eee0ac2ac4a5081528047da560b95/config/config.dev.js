/*eslint-disable */
var path = require('path')
var _ = require('lodash');
var baseConfig = _.cloneDeep(require('./config.base.js'));

module.exports = _.extend(baseConfig , {
    env: {
        NODE_ENV: '"development"'
    },
    isProduction : false,
    isDevelopment : true,    
    version : new Date().getTime(),
    debug : true,
    mock : true,
    release : false,
    port: 80,
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',
    context: [ //代理路径

    ],
    proxypath: '',
    cssSourceMap: false,
    favicon: './favicon.ico',
    weblibs : [
        './src/assets/js/libs/jquery-3.1.0.min.js',
        './src/assets/js/libs/underscore.js',
        './src/assets/js/libs/ydk-1.4.8.js',
        './src/assets/js/libs/web.jsb-1.4.8.js',
        './src/assets/js/libs/native.pc.jsb-1.4.8.js',
        './src/assets/js/libs/extends.js'
    ], 
    pigaiHost: 'pigai_test.inner.youdao.com'
})