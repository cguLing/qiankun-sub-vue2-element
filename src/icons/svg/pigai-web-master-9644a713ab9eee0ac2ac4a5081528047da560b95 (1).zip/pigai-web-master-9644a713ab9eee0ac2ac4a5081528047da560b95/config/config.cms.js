/*eslint-disable */
var path = require('path')
var _ = require('lodash');
var baseConfig = _.cloneDeep(require('./config.base.js'));

module.exports = _.extend(baseConfig, {
  env: {
    NODE_ENV: '"production"'
  },
  isProduction: true,
  isDevelopment: false,
  version: new Date().getTime(),
  debug: false,
  mock: false,
  index: path.resolve(__dirname, '../dist/cms/html/index.html'),
  assetsPath: path.resolve(__dirname, '../dist/cms'),
  assetsPublicPath: '../',
  // assetsPublicPath: '//shared.ydstatic.com/dict/writecorrect/',   //线上CDN路径
  imageCdnPath: '//shared.ydstatic.com/dict/writecorrect/',   // 图片绝对位置
  assetsSubDirectory: '',
  productionSourceMap: true,
  productionGzip: false,
  productionGzipExtensions: ['js', 'css'],
  dll: './dll/vendor.dll.js',
  inject: './src/modules/inject/inject_getword.js',
  weblibs: [
    './src/assets/js/libs/jquery-3.1.0.min.js',
    './src/assets/js/libs/underscore.js',
    './src/assets/js/libs/ydk-1.4.8.js',
    './src/assets/js/libs/native.pc.jsb-1.4.8.js',
    './src/assets/js/libs/extends.js'
  ],
  pigaiHost: 'pigai_test.inner.youdao.com',
  "cms.remote.dir": '/test/lijw/pigai/'
  // "cms.remote.dir": '/test/lijw/pigai/ie11/'
})