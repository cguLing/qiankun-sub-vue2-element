/*eslint-disable */
var path = require('path')
var _ = require('lodash');
var baseConfig = _.cloneDeep(require('./config.base.js'));

module.exports = _.extend(baseConfig , {
	env: {
	    NODE_ENV: '"production"'
	},
	isProduction : true,
	isDevelopment : false,
	version : new Date().getTime(),
	debug : false,
	mock : false,	
	// index: path.resolve(__dirname, '../dist/html/index.html'),
	// assetsPath: path.resolve(__dirname, '../dist/'),
	index: path.resolve(__dirname, '../dist/rs/html/index.html'),
	assetsPath: path.resolve(__dirname, '../dist/rs'),
	assetsPublicPath: '../',
	imageCdnPath: '../',   // 图片绝对位置
	// assetsPublicPath: '//shared.ydstatic.com/dict/pigai/inner/',   //线上CDN路径
	assetsSubDirectory: '',
	productionSourceMap: true,
	productionGzip: false,
	productionGzipExtensions: ['js', 'css'],
	dll : './dll/vendor.dll.js',
	inject : './src/modules/inject/inject_getword.js',
	weblibs : [
	    './src/assets/js/libs/jquery-3.1.0.min.js',
	    './src/assets/js/libs/underscore.js',
	    './src/assets/js/libs/ydk-1.4.8.js',
	    './src/assets/js/libs/native.pc.jsb-1.4.8.js',
	    './src/assets/js/libs/extends.js'
		],  
	pigaiHost:'pigai.youdao.com',
	release: false,
	resourcePublicPath: '//shared.ydstatic.com/dict/pigai/inner/', // cdn的文件目录前缀
	resourceSvnPublicPath: 'https://corp.youdao.com/svn/ydstatic/dict/pigai/inner/', // svn目录前缀
})