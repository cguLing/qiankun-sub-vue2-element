/*eslint-disable */
var path = require('path');

module.exports = {
  platform: 'win',
  weblibs: [
    './src/assets/js/libs/jquery-3.1.0.min.js',
    './src/assets/js/libs/underscore.js',
    './src/assets/js/libs/ydk-1.4.8.js',
    './src/assets/js/libs/web.jsb-1.4.8.js',
    './src/assets/js/libs/native.pc.jsb-1.4.8.js',
    './src/assets/js/libs/extends.js'
  ]
}
