/*eslint-disable */
var path = require('path')

module.exports = { 
  build: require('./config.build.js'),
  release: require('./config.release.js'),
  dev: require('./config.dev.js'),
  test : require('./config.test.js'),
  mock : require('./config.mock.js'), 
  cms: require('./config.cms.js'),
}