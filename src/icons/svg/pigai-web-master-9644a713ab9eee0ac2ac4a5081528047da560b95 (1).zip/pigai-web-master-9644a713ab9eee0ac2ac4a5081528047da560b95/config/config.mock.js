/*eslint-disable */
var path = require('path')

module.exports = { 
  mock_components : {
      // 'mock_input$': 'components/null/index',
      // 'mock_leftTab$': 'components/null/index',   
      // 'mock_wordbook$': 'components/null/index',   
      'mock_input$' : process.env.NODE_ENV === 'production' ? 'components/null/index' : 'components/mock_input/index.vue',
      'mock_leftTab$' : process.env.NODE_ENV === 'production' ? 'components/null/index' : 'components/mock_lefttab/index.vue',
      'mock_wordbook$' : process.env.NODE_ENV === 'production' ? 'components/null/index' : 'components/mock_wordbook/index.vue'    
   },   
}