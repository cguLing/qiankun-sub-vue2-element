/*eslint-disable */
var path = require('path')
var _ = require('lodash');
var buildConifg = _.cloneDeep(require('./config.build.js'));

module.exports = _.extend(buildConifg, {
  release: true,
  resourcePublicPath: '//shared.ydstatic.com/dict/pigai/release/', // cdn的文件目录前缀
  resourceSvnPublicPath: 'https://corp.youdao.com/svn/ydstatic/dict/pigai/release/', // svn目录前缀
})