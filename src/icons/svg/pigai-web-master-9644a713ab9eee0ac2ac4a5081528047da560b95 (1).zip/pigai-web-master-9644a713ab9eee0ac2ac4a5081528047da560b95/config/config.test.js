/*eslint-disable */
var path = require('path')
var _ = require('lodash');
var baseConfig = _.cloneDeep(require('./config.base.js'));

module.exports = _.extend(baseConfig , {
  env: {
    NODE_ENV: 'testing'
  }, 
})